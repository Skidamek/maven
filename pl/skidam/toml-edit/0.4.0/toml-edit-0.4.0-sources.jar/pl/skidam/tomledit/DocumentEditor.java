package pl.skidam.tomledit;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * High-level document operations: {@code reconcile}, additive {@code materialize}, {@code ensure},
 * {@code rename}, and {@code remove}, composed over {@link CstNavigator}, {@link CstEntryEditor},
 * {@link CstSectionEditor}, {@link CstInlineTableEditor}, and {@link CstArrayEditor}.
 */
final class DocumentEditor {
	private DocumentEditor() {}

	static void reconcile(Cst.Doc doc, TomlValue.Table model, ReconcilePolicy policy) {
		reconcile(doc, Cst.toTable(doc), model, policy);
	}

	static void reconcile(Cst.Doc doc, TomlValue.Table current, TomlValue.Table model, ReconcilePolicy policy) {
		reconcileTable(doc, ConfigPath.root(), current, model, policy);
	}

	static void reconcileTable(Cst.Doc doc, ConfigPath path, TomlValue.Table current, TomlValue.Table model, ReconcilePolicy policy) {
		for (Map.Entry<String, TomlValue> entry : current.members().entrySet()) {
			String key = entry.getKey();
			TomlValue modelVal = model.get(key);
			if (modelVal == null) continue; // unknown/stale keys in document stay untouched
			TomlValue docVal = entry.getValue();
			if (docVal.equals(modelVal)) continue;

			ConfigPath childPath = path.appended(key);
			if (docVal instanceof TomlValue.Table docTbl && modelVal instanceof TomlValue.Table modelTbl) {
				reconcileTable(doc, childPath, docTbl, modelTbl, policy);
			} else if (docVal instanceof TomlValue.Array docArr && modelVal instanceof TomlValue.Array modelArr) {
				reconcileArrayAtPath(doc, childPath, docArr, modelArr, policy);
			} else {
				CstEntryEditor.set(doc, childPath, modelVal);
			}
		}
	}

	private static void reconcileArrayAtPath(Cst.Doc doc, ConfigPath path, TomlValue.Array docArr, TomlValue.Array modelArr, ReconcilePolicy policy) {
		CstNavigator.Target target = CstNavigator.resolve(doc, path);
		if (target == null) return;
		byte[] docNl = CstEntryEditor.detectDocNewline(doc);
		Cst.Arr arr = target.asArray();
		if (arr != null) {
			CstArrayEditor.reconcile(arr, modelArr, docNl, policy);
			return;
		}
		if (target instanceof CstNavigator.ArrayOfTablesTarget) {
			CstSectionEditor.reconcileArrayOfTables(doc, path, docArr, modelArr, policy);
			return;
		}
		CstEntryEditor.set(doc, path, modelArr);
	}

	static void ensure(Cst.Doc doc, ConfigPath path, TomlValue defaultValue, String comment) {
		String key = requireMemberPath(path);
		if (CstNavigator.resolve(doc, path) != null) return;
		Comments comments = comment == null ? Comments.NONE : Comments.of(null, Map.of(path, comment));
		materialize(doc, path.parent(), TomlValue.table().put(key, defaultValue), comments);
	}

	/**
	 * Additively materializes {@code additions} under {@code absPrefix}, attaching any comments from
	 * {@code comments} onto newly created entries and section headers. Existing entries and sections
	 * are never overwritten or given retrofitted comments; missing ancestors are materialized as one
	 * section tree without empty intermediate headers unless documented by {@code comments}.
	 */
	static void materialize(Cst.Doc doc, ConfigPath absPrefix, TomlValue.Table additions, Comments comments) {
		if (additions.isEmpty()) return;
		CstNavigator.Target target = CstNavigator.resolve(doc, absPrefix);
		if (target == null) {
			insertAtMissingPrefix(doc, absPrefix, additions, comments);
			return;
		}
		if (!target.isTableLike()) {
			throw new TomlEditException("ancestor is not a table: " + absPrefix, absPrefix);
		}
		materializeIntoExisting(doc, absPrefix, additions, comments);
	}

	private static void materializeIntoExisting(Cst.Doc doc, ConfigPath absPrefix, TomlValue.Table additions, Comments comments) {
		for (Map.Entry<String, TomlValue> entry : additions.members().entrySet()) {
			String key = entry.getKey();
			TomlValue value = entry.getValue();
			ConfigPath abs = absPrefix.appended(key);
			CstNavigator.Target existing = CstNavigator.resolve(doc, abs);
			if (existing == null) {
				CstEntryEditor.insertMember(doc, absPrefix, key, value, comments);
			} else if (value instanceof TomlValue.Table table) {
				if (!existing.isTableLike()) {
					throw new TomlEditException("ancestor is not a table: " + abs, abs);
				}
				materializeIntoExisting(doc, abs, table, comments);
			}
		}
	}

	private static void insertAtMissingPrefix(Cst.Doc doc, ConfigPath absPrefix, TomlValue.Table additions, Comments comments) {
		List<ConfigPath.Segment> segs = absPrefix.segments();
		int lastIndex = -1;
		for (int i = 0; i < segs.size(); i++) {
			if (segs.get(i) instanceof ConfigPath.Segment.Index) lastIndex = i;
		}
		int startDepth = 0;
		if (lastIndex >= 0) {
			ConfigPath indexedPrefix = prefix(absPrefix, lastIndex + 1);
			ensureAncestors(doc, indexedPrefix);
			startDepth = lastIndex + 1;
		}
		int existing = existingKeyPrefixDepth(doc, absPrefix, startDepth);
		if (existing == segs.size()) {
			materializeIntoExisting(doc, absPrefix, additions, comments);
			return;
		}
		String baseKey = ((ConfigPath.Segment.Key) segs.get(existing)).name();
		TomlValue.Table wrapped = additions;
		for (int i = segs.size() - 1; i > existing; i--) {
			String nestedKey = ((ConfigPath.Segment.Key) segs.get(i)).name();
			wrapped = TomlValue.table().put(nestedKey, wrapped);
		}
		CstEntryEditor.insertMember(doc, prefix(absPrefix, existing), baseKey, wrapped, comments);
	}

	private static int existingKeyPrefixDepth(Cst.Doc doc, ConfigPath path, int startDepth) {
		List<ConfigPath.Segment> segs = path.segments();
		ConfigPath current = prefix(path, startDepth);
		int depth = startDepth;
		for (int i = startDepth; i < segs.size(); i++) {
			current = current.appended(((ConfigPath.Segment.Key) segs.get(i)).name());
			CstNavigator.Target target = CstNavigator.resolve(doc, current);
			if (target == null) break;
			if (!target.isTableLike()) {
				throw new TomlEditException("ancestor is not a table: " + current, current);
			}
			depth = i + 1;
		}
		return depth;
	}

	private static ConfigPath prefix(ConfigPath path, int size) {
		return size == 0 ? ConfigPath.root() : new ConfigPath(path.segments().subList(0, size));
	}

	static void rename(Cst.Doc doc, ConfigPath from, ConfigPath to) {
		requireMemberPath(from);
		String toKey = requireMemberPath(to);
		if (from.equals(to)) return;
		if (to.startsWith(from) || from.startsWith(to)) {
			throw new TomlEditException("rename source and destination cannot overlap: " + from + " -> " + to, to);
		}
		CstNavigator.Target fromTarget = CstNavigator.resolve(doc, from);
		if (fromTarget == null) return; // absent source: no-op

		validateDestinationAncestors(doc, to.parent());

		if (CstNavigator.resolve(doc, to) != null) {
			// Destination already present: drop source, leave destination untouched
			CstEntryEditor.removeMember(doc, from);
			return;
		}

		// Case 1: Same-parent Entry rename -> rename final key token in place (preserves order, value CST, comments)
		if (from.parent().equals(to.parent()) && fromTarget instanceof CstNavigator.EntryTarget et) {
			CstEntryEditor.replaceKeySegmentAt(et.entry().key, et.entry().key.keys.size() - 1, toKey);
			return;
		}

		// Case 2: Same-parent InlineEntry rename -> rename final key token in place
		if (from.parent().equals(to.parent()) && fromTarget instanceof CstNavigator.InlineEntryTarget iet) {
			CstEntryEditor.replaceKeySegmentAt(iet.entry().key, iet.entry().key.keys.size() - 1, toKey);
			return;
		}

		// Case 3: Same-parent VirtualInlineTableTarget rename -> rewrite dotted prefix in place
		if (from.parent().equals(to.parent()) && fromTarget instanceof CstNavigator.VirtualInlineTableTarget vit) {
			CstInlineTableEditor.renameVirtualTablePrefix(vit, toKey);
			return;
		}

		CstNavigator.Target destParent = CstNavigator.resolve(doc, to.parent());
		boolean destIsInline = destParent != null && destParent.isInlineTableTarget();

		// Case 4: Section, [[array-of-tables]], or VirtualTableTarget -> rewrite headers & dotted entries losslessly
		if (!destIsInline && (fromTarget instanceof CstNavigator.SectionTarget
				|| fromTarget instanceof CstNavigator.ArrayOfTablesTarget
				|| fromTarget instanceof CstNavigator.VirtualTableTarget)) {
			CstSectionEditor.renameSubtree(doc, from, to);
			return;
		}

		// Case 5: Cross-parent Entry move -> carry Cst.Val verbatim when destination is not inline
		TomlValue carried = Cst.toTable(doc).get(from);
		Optional<String> carriedComment = CstEntryEditor.attachedComment(doc, from);
		String trailingNote = (fromTarget instanceof CstNavigator.EntryTarget et)
				? CstEntryEditor.extractTrailingNote(et.entry()) : null;
		Cst.Val preservedVal = (!destIsInline && fromTarget instanceof CstNavigator.EntryTarget et)
				? et.entry().value : null;

		CstEntryEditor.removeMember(doc, from);
		ensureAncestors(doc, to.parent());
		Comments comments = carriedComment.map(c -> Comments.of(null, Map.of(to, c))).orElse(Comments.NONE);
		CstEntryEditor.insertMemberValue(doc, to.parent(), toKey, carried, preservedVal, comments, trailingNote);
	}

	static void remove(Cst.Doc doc, ConfigPath path) {
		requireMemberPath(path);
		if (CstNavigator.resolve(doc, path) == null) return;
		CstEntryEditor.removeMember(doc, path);
	}

	static void ensureAncestors(Cst.Doc doc, ConfigPath prefix) {
		walkAncestors(doc, prefix, true);
	}

	private static void validateDestinationAncestors(Cst.Doc doc, ConfigPath prefix) {
		walkAncestors(doc, prefix, false);
	}

	private static void walkAncestors(Cst.Doc doc, ConfigPath prefix, boolean createMissing) {
		List<ConfigPath.Segment> segs = prefix.segments();
		ConfigPath cur = ConfigPath.root();
		for (int i = 0; i < segs.size(); i++) {
			ConfigPath.Segment seg = segs.get(i);
			boolean nextIsIndex = (i + 1 < segs.size()) && (segs.get(i + 1) instanceof ConfigPath.Segment.Index);
			if (seg instanceof ConfigPath.Segment.Index idx) {
				ConfigPath next = cur.appended(idx.index());
				CstNavigator.Target t = CstNavigator.resolve(doc, next);
				if (t == null) {
					throw new TomlEditException((createMissing ? "cannot materialize missing array element: " : "destination array element does not exist: ") + next, next);
				}
				if (!nextIsIndex && !t.isTableLike()) {
					throw new TomlEditException((createMissing ? "ancestor is not a table: " : "destination ancestor is not a table: ") + next, next);
				}
				cur = next;
			} else if (seg instanceof ConfigPath.Segment.Key k) {
				ConfigPath next = cur.appended(k.name());
				CstNavigator.Target t = CstNavigator.resolve(doc, next);
				if (t == null) {
					if (nextIsIndex) {
						throw new TomlEditException((createMissing ? "cannot materialize missing array: " : "destination array does not exist: ") + next, next);
					}
					if (createMissing) {
						CstEntryEditor.insertMember(doc, cur, k.name(), TomlValue.table(), null, null);
					}
				} else if (!nextIsIndex && !t.isTableLike()) {
					throw new TomlEditException((createMissing ? "ancestor is not a table: " : "destination ancestor is not a table: ") + next, next);
				} else if (nextIsIndex && !t.isArrayLike()) {
					throw new TomlEditException((createMissing ? "ancestor is not an array: " : "destination ancestor is not an array: ") + next, next);
				}
				cur = next;
			}
		}
	}

	private static String requireMemberPath(ConfigPath path) {
		if (path.isRoot() || !(path.last() instanceof ConfigPath.Segment.Key key)) {
			throw new TomlEditException("operation addresses table members, not root or array elements: " + path, path);
		}
		return key.name();
	}
}
