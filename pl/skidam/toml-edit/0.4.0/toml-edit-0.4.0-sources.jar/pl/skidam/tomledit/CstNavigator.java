package pl.skidam.tomledit;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Resolves {@link ConfigPath}s against a {@link Cst.Doc} across root entries, {@code [table]} and
 * {@code [[array-table]]} sections, dotted keys, inline tables, and arrays.
 */
final class CstNavigator {
	private CstNavigator() {}

	sealed interface Target
			permits RootTarget, ValueTarget, SectionTarget, ArrayOfTablesTarget, VirtualTableTarget, VirtualInlineTableTarget {
		default boolean isTableLike() {
			return this instanceof RootTarget || this instanceof SectionTarget
					|| this instanceof VirtualTableTarget || this instanceof VirtualInlineTableTarget
					|| (this instanceof ValueTarget vt && vt.value() instanceof Cst.InlineTable);
		}

		default boolean isArrayLike() {
			return this instanceof ArrayOfTablesTarget
					|| (this instanceof ValueTarget vt && vt.value() instanceof Cst.Arr);
		}

		default boolean isInlineTableTarget() {
			return this instanceof VirtualInlineTableTarget
					|| (this instanceof ValueTarget vt && vt.value() instanceof Cst.InlineTable);
		}

		default Cst.InlineTable asInlineTable() {
			return (this instanceof ValueTarget vt && vt.value() instanceof Cst.InlineTable tbl) ? tbl : null;
		}

		default Cst.Arr asArray() {
			return (this instanceof ValueTarget vt && vt.value() instanceof Cst.Arr arr) ? arr : null;
		}
	}

	/** A CST slot holding a mutable {@link Cst.Val} (entry, inline entry, or array element). */
	sealed interface ValueTarget extends Target permits EntryTarget, InlineEntryTarget, ArrayElemTarget {
		Cst.Val value();

		void setValue(Cst.Val val);
	}

	static final class RootTarget implements Target {
		static final RootTarget INSTANCE = new RootTarget();

		private RootTarget() {}
	}

	static final class EntryTarget implements ValueTarget {
		final List<Cst.Item> ownerItems;
		final Cst.Entry entry;
		final Cst.Section ownerSection;
		final ConfigPath fullPath;

		EntryTarget(List<Cst.Item> ownerItems, Cst.Entry entry, Cst.Section ownerSection, ConfigPath fullPath) {
			this.ownerItems = ownerItems;
			this.entry = entry;
			this.ownerSection = ownerSection;
			this.fullPath = fullPath;
		}

		List<Cst.Item> ownerItems() {
			return ownerItems;
		}

		Cst.Entry entry() {
			return entry;
		}

		Cst.Section ownerSection() {
			return ownerSection;
		}

		ConfigPath fullPath() {
			return fullPath;
		}

		@Override
		public Cst.Val value() {
			return entry.value;
		}

		@Override
		public void setValue(Cst.Val val) {
			entry.value = val;
		}
	}

	static final class InlineEntryTarget implements ValueTarget {
		final Cst.InlineTable ownerTable;
		final Cst.InlineEntry entry;
		final ConfigPath fullPath;

		InlineEntryTarget(Cst.InlineTable ownerTable, Cst.InlineEntry entry, ConfigPath fullPath) {
			this.ownerTable = ownerTable;
			this.entry = entry;
			this.fullPath = fullPath;
		}

		Cst.InlineTable ownerTable() {
			return ownerTable;
		}

		Cst.InlineEntry entry() {
			return entry;
		}

		ConfigPath fullPath() {
			return fullPath;
		}

		@Override
		public Cst.Val value() {
			return entry.value;
		}

		@Override
		public void setValue(Cst.Val val) {
			entry.value = val;
		}
	}

	static final class ArrayElemTarget implements ValueTarget {
		final Cst.Arr ownerArray;
		final int index;
		final Cst.ArrayItem item;
		final ConfigPath fullPath;

		ArrayElemTarget(Cst.Arr ownerArray, int index, Cst.ArrayItem item, ConfigPath fullPath) {
			this.ownerArray = ownerArray;
			this.index = index;
			this.item = item;
			this.fullPath = fullPath;
		}

		Cst.Arr ownerArray() {
			return ownerArray;
		}

		int index() {
			return index;
		}

		Cst.ArrayItem item() {
			return item;
		}

		ConfigPath fullPath() {
			return fullPath;
		}

		@Override
		public Cst.Val value() {
			return item.value;
		}

		@Override
		public void setValue(Cst.Val val) {
			item.value = val;
		}
	}

	static final class SectionTarget implements Target {
		final Cst.Section section;
		final ConfigPath sectionPath;

		SectionTarget(Cst.Section section, ConfigPath sectionPath) {
			this.section = section;
			this.sectionPath = sectionPath;
		}

		Cst.Section section() {
			return section;
		}

		ConfigPath sectionPath() {
			return sectionPath;
		}
	}

	static final class ArrayOfTablesTarget implements Target {
		final List<Cst.Section> sections;
		final ConfigPath path;

		ArrayOfTablesTarget(List<Cst.Section> sections, ConfigPath path) {
			this.sections = sections;
			this.path = path;
		}

		List<Cst.Section> sections() {
			return sections;
		}

		ConfigPath path() {
			return path;
		}
	}

	/**
	 * An implicit table created either as a super-table of {@code [section]} headers (where
	 * {@code dottedOwnerItems == null} and a {@code [path]} header may be materialized), or by
	 * dotted keys inside an existing item list (where new entries must also be dotted keys in
	 * {@code dottedOwnerItems} to avoid TOML's REDEFINED_TABLE rule).
	 */
	static final class VirtualTableTarget implements Target {
		final ConfigPath path;
		final List<Cst.Item> dottedOwnerItems;
		final ConfigPath dottedOwnerBase;

		VirtualTableTarget(ConfigPath path, List<Cst.Item> dottedOwnerItems, ConfigPath dottedOwnerBase) {
			this.path = path;
			this.dottedOwnerItems = dottedOwnerItems;
			this.dottedOwnerBase = dottedOwnerBase;
		}

		ConfigPath path() {
			return path;
		}

		List<Cst.Item> dottedOwnerItems() {
			return dottedOwnerItems;
		}

		ConfigPath dottedOwnerBase() {
			return dottedOwnerBase;
		}
	}

	/** An implicit table created by dotted keys inside an inline table (e.g. {@code b} in {@code { b.c = 1 }}). */
	static final class VirtualInlineTableTarget implements Target {
		final Cst.InlineTable ownerTable;
		final ConfigPath fullPath;
		final List<String> prefixKeys;

		VirtualInlineTableTarget(Cst.InlineTable ownerTable, ConfigPath fullPath, List<String> prefixKeys) {
			this.ownerTable = ownerTable;
			this.fullPath = fullPath;
			this.prefixKeys = prefixKeys;
		}

		Cst.InlineTable ownerTable() {
			return ownerTable;
		}

		ConfigPath fullPath() {
			return fullPath;
		}

		List<String> prefixKeys() {
			return prefixKeys;
		}
	}

	/** Forward and reverse index of all {@code [table]} and {@code [[array-table]]} sections in a document. */
	static final class SectionIndex {
		final Map<ConfigPath, Cst.Section> byPath;
		final IdentityHashMap<Cst.Section, ConfigPath> pathOf;
		final Map<ConfigPath, List<Cst.Section>> aotByPath;

		SectionIndex(Map<ConfigPath, Cst.Section> byPath, IdentityHashMap<Cst.Section, ConfigPath> pathOf,
				Map<ConfigPath, List<Cst.Section>> aotByPath) {
			this.byPath = byPath;
			this.pathOf = pathOf;
			this.aotByPath = aotByPath;
		}

		Map<ConfigPath, Cst.Section> byPath() {
			return byPath;
		}

		IdentityHashMap<Cst.Section, ConfigPath> pathOf() {
			return pathOf;
		}

		Map<ConfigPath, List<Cst.Section>> aotByPath() {
			return aotByPath;
		}

		static SectionIndex of(Cst.Doc doc) {
			if (doc.sectionIndex != null) return doc.sectionIndex;
			Map<ConfigPath, Cst.Section> byPath = new LinkedHashMap<>();
			IdentityHashMap<Cst.Section, ConfigPath> pathOf = new IdentityHashMap<>(doc.sections.size());
			Map<ConfigPath, List<Cst.Section>> aotByPath = new LinkedHashMap<>();
			Map<ConfigPath, Integer> aotCounts = new LinkedHashMap<>();
			for (Cst.Section section : doc.sections) {
				List<String> keys = section.headerKey.keys;
				ConfigPath current = ConfigPath.root();
				for (int i = 0; i < keys.size() - 1; i++) {
					current = current.appended(keys.get(i));
					Integer count = aotCounts.get(current);
					if (count != null) {
						current = current.appended(count - 1);
					}
				}
				ConfigPath headerBase = current.appended(keys.get(keys.size() - 1));
				if (section.arrayTable) {
					int idx = aotCounts.getOrDefault(headerBase, 0);
					aotCounts.put(headerBase, idx + 1);
					ConfigPath elemPath = headerBase.appended(idx);
					byPath.put(elemPath, section);
					pathOf.put(section, elemPath);
					aotByPath.computeIfAbsent(headerBase, k -> new ArrayList<>()).add(section);
				} else {
					byPath.put(headerBase, section);
					pathOf.put(section, headerBase);
				}
			}
			SectionIndex built = new SectionIndex(byPath, pathOf, aotByPath);
			doc.sectionIndex = built;
			return built;
		}
	}

	/** Resolves {@code path} in {@code doc}, or returns {@code null} when absent. */
	static Target resolve(Cst.Doc doc, ConfigPath path) {
		if (path.isRoot()) return RootTarget.INSTANCE;

		List<ConfigPath.Segment> segs = path.segments();

		// 1. Check direct entry or inline traversal from root items before indexing sections
		Target rootHit = resolveInItems(doc.rootItems, null, ConfigPath.root(), segs, 0);
		if (rootHit != null) return rootHit;

		if (doc.sections.isEmpty()) {
			return hasDottedDescendant(doc.rootItems, ConfigPath.root(), path)
					? new VirtualTableTarget(path, doc.rootItems, ConfigPath.root())
					: null;
		}

		SectionIndex index = SectionIndex.of(doc);

		// 2. Check exact match on an array-of-tables path
		List<Cst.Section> aot = index.aotByPath().get(path);
		if (aot != null) return new ArrayOfTablesTarget(aot, path);

		// 3. Check exact match on a section header
		Cst.Section exactSection = index.byPath().get(path);
		if (exactSection != null) return new SectionTarget(exactSection, path);

		// 4. Find the longest matching section prefix and resolve remaining segments inside its items
		for (int prefixLen = segs.size() - 1; prefixLen >= 1; prefixLen--) {
			ConfigPath prefix = prefixOf(path, prefixLen);
			Cst.Section sec = index.byPath().get(prefix);
			if (sec != null) {
				Target hit = resolveInItems(sec.items, sec, prefix, segs, prefixLen);
				if (hit != null) return hit;
			}
		}

		// 5. Check if path is an implicit/virtual table (super-table of a section or dotted entry)
		return resolveVirtualTable(doc, index.byPath(), path);
	}

	static Target requireTarget(Cst.Doc doc, ConfigPath path) {
		Target t = resolve(doc, path);
		if (t == null) throw new TomlEditException("path does not exist: " + path, path);
		return t;
	}

	private static Target resolveInItems(List<Cst.Item> items, Cst.Section ownerSection, ConfigPath basePath,
			List<ConfigPath.Segment> targetSegs, int offset) {
		for (Cst.Item item : items) {
			if (!(item instanceof Cst.Entry entry)) continue;
			int match = matchKeyPrefix(entry.key.keys, targetSegs, offset);
			if (match < 0) continue;
			ConfigPath entryPath = appendKeys(basePath, entry.key.keys);
			if (match == targetSegs.size()) {
				return new EntryTarget(items, entry, ownerSection, entryPath);
			}
			// Descend into inline table or array value
			Target nested = resolveInVal(entry.value, entryPath, targetSegs, match);
			if (nested != null) return nested;
		}
		return null;
	}

	private static Target resolveInVal(Cst.Val val, ConfigPath valPath, List<ConfigPath.Segment> targetSegs, int offset) {
		if (offset >= targetSegs.size()) return null;
		ConfigPath.Segment next = targetSegs.get(offset);
		if (val instanceof Cst.Arr arr && next instanceof ConfigPath.Segment.Index idx) {
			if (idx.index() < 0 || idx.index() >= arr.items.size()) return null;
			Cst.ArrayItem item = arr.items.get(idx.index());
			ConfigPath elemPath = valPath.appended(idx.index());
			if (offset + 1 == targetSegs.size()) {
				return new ArrayElemTarget(arr, idx.index(), item, elemPath);
			}
			return resolveInVal(item.value, elemPath, targetSegs, offset + 1);
		}
		if (val instanceof Cst.InlineTable tbl) {
			for (Cst.InlineEntry entry : tbl.entries) {
				int match = matchKeyPrefix(entry.key.keys, targetSegs, offset);
				if (match >= 0) {
					ConfigPath entryPath = appendKeys(valPath, entry.key.keys);
					if (match == targetSegs.size()) {
						return new InlineEntryTarget(tbl, entry, entryPath);
					}
					Target nested = resolveInVal(entry.value, entryPath, targetSegs, match);
					if (nested != null) return nested;
				}
				// Check if remaining targetSegs is a strict prefix of this dotted inline entry's keys
				int remaining = targetSegs.size() - offset;
				if (remaining > 0 && remaining < entry.key.keys.size() && matchesPrefix(entry.key.keys, targetSegs, offset, remaining)) {
					List<String> prefixKeys = new ArrayList<>(entry.key.keys.subList(0, remaining));
					return new VirtualInlineTableTarget(tbl, appendKeys(valPath, prefixKeys), prefixKeys);
				}
			}
		}
		return null;
	}

	private static boolean matchesPrefix(List<String> keys, List<ConfigPath.Segment> targetSegs, int offset, int count) {
		for (int i = 0; i < count; i++) {
			if (!(targetSegs.get(offset + i) instanceof ConfigPath.Segment.Key k) || !k.name().equals(keys.get(i))) {
				return false;
			}
		}
		return true;
	}

	/** Matches all keys of a (possibly dotted) key against targetSegs starting at offset. Returns new offset or -1. */
	private static int matchKeyPrefix(List<String> keys, List<ConfigPath.Segment> targetSegs, int offset) {
		if (offset + keys.size() > targetSegs.size()) return -1;
		for (int i = 0; i < keys.size(); i++) {
			if (!(targetSegs.get(offset + i) instanceof ConfigPath.Segment.Key k) || !k.name().equals(keys.get(i))) {
				return -1;
			}
		}
		return offset + keys.size();
	}

	private static VirtualTableTarget resolveVirtualTable(Cst.Doc doc, Map<ConfigPath, Cst.Section> sectionByPath, ConfigPath path) {
		// Dotted-key owner takes precedence: if a dotted key already defined `path` in root or a section,
		// TOML forbids reopening `[path]` as a header, so new keys must be added as dotted keys there.
		if (hasDottedDescendant(doc.rootItems, ConfigPath.root(), path)) {
			return new VirtualTableTarget(path, doc.rootItems, ConfigPath.root());
		}
		for (Map.Entry<ConfigPath, Cst.Section> e : sectionByPath.entrySet()) {
			if (path.startsWith(e.getKey()) && hasDottedDescendant(e.getValue().items, e.getKey(), path)) {
				return new VirtualTableTarget(path, e.getValue().items, e.getKey());
			}
		}
		for (ConfigPath secPath : sectionByPath.keySet()) {
			if (secPath.size() > path.size() && secPath.startsWith(path)) {
				return new VirtualTableTarget(path, null, null);
			}
		}
		return null;
	}

	private static boolean hasDottedDescendant(List<Cst.Item> items, ConfigPath basePath, ConfigPath target) {
		for (Cst.Item item : items) {
			if (!(item instanceof Cst.Entry entry)) continue;
			ConfigPath full = appendKeys(basePath, entry.key.keys);
			if (full.size() > target.size() && full.startsWith(target)) return true;
		}
		return false;
	}

	static ConfigPath prefixOf(ConfigPath path, int len) {
		if (len == 0) return ConfigPath.root();
		return new ConfigPath(path.segments().subList(0, len));
	}

	static ConfigPath appendKeys(ConfigPath base, List<String> keys) {
		ConfigPath cur = base;
		for (String k : keys) cur = cur.appended(k);
		return cur;
	}
}
