package pl.skidam.tomledit;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Recursive-descent TOML 1.1.0 parser building a lossless {@link Cst.Doc} while enforcing all
 * TOML 1.1.0 structural and table-redefinition rules in a single pass.
 */
final class TomlParser {
	static final int MAX_DEPTH = 255;

	private final TomlLexer lex;
	private int depth;

	// Semantic validation tree tracking how each table/array/value was defined
	private static final int TABLE_EXPLICIT = 0;
	private static final int TABLE_IMPLICIT_SUPER = 1;
	private static final int TABLE_DOTTED_IMPLICIT = 2;
	private static final int TABLE_INLINE = 3;

	private final TableNode rootScope = new TableNode(TABLE_EXPLICIT);
	private TableNode currentScope = rootScope;
	private int sectionId = 0;

	private sealed interface ScopeNode permits TableNode, ArrayOfTablesNode, LeafNode {}

	private static final class TableNode implements ScopeNode {
		int kind;
		int ownerSectionId;
		final Map<String, ScopeNode> children = new HashMap<>();

		TableNode(int kind) {
			this(kind, 0);
		}

		TableNode(int kind, int ownerSectionId) {
			this.kind = kind;
			this.ownerSectionId = ownerSectionId;
		}
	}

	private static final class ArrayOfTablesNode implements ScopeNode {
		final List<TableNode> elements = new ArrayList<>();
	}

	private static final class LeafNode implements ScopeNode {
		static final LeafNode INSTANCE = new LeafNode();
	}

	private TomlParser(byte[] bytes) {
		this.lex = new TomlLexer(bytes);
	}

	static Cst.Doc parse(byte[] bytes) {
		int invalid = Utf8.firstInvalidOffset(bytes);
		if (invalid >= 0) {
			int[] lc = TomlLexer.computeLineCol(bytes, invalid);
			throw new ParseFailure(ErrorKind.INVALID_UTF8, "input is not valid UTF-8", lc[0], lc[1], invalid);
		}
		return new TomlParser(bytes).parseDoc();
	}

	/** Parses a freshly rendered canonical inline value into a {@link Cst.Val}. */
	static Cst.Val parseValueFragment(byte[] bytes) {
		int invalid = Utf8.firstInvalidOffset(bytes);
		if (invalid >= 0) {
			throw new IllegalStateException("writer emitted invalid UTF-8 value fragment");
		}
		TomlParser parser = new TomlParser(bytes);
		Cst.Val val = parser.parseValue();
		if (!parser.lex.eof()) {
			throw new IllegalStateException("writer emitted trailing bytes in value fragment");
		}
		return val;
	}

	private Cst.Doc parseDoc() {
		Cst.Doc doc = new Cst.Doc();
		if (lex.b.length >= 3 && lex.b[0] == (byte) 0xEF && lex.b[1] == (byte) 0xBB && lex.b[2] == (byte) 0xBF) {
			doc.bom = new Cst.Tok(Cst.TokKind.BOM, lex.slice(0, 3));
			lex.pos = 3;
		}

		Cst.Section currentSection = null;
		while (!lex.eof()) {
			List<Cst.Tok> leadingWs = new ArrayList<>();
			Cst.Tok ws = lex.readWs();
			if (ws != null) leadingWs.add(ws);

			if (lex.eof()) {
				if (!leadingWs.isEmpty()) addItem(doc, currentSection, new Cst.TriviaLine(leadingWs));
				break;
			}
			int c = lex.peek();
			if (c == '\n' || c == '\r' || c == '#') {
				List<Cst.Tok> trivia = new ArrayList<>(leadingWs);
				Cst.Tok comment = lex.readComment();
				if (comment != null) trivia.add(comment);
				Cst.Tok nl = lex.readNewline();
				if (nl != null) trivia.add(nl);
				addItem(doc, currentSection, new Cst.TriviaLine(trivia));
				continue;
			}
			List<Cst.TriviaLine> attachedComments = popLeadingComments(doc, currentSection);
			if (c == '[') {
				currentSection = parseSectionHeader(attachedComments, leadingWs);
				doc.addSection(doc.sections.size(), currentSection);
				continue;
			}
			Cst.Entry entry = parseEntry(attachedComments, leadingWs);
			addItem(doc, currentSection, entry);
		}
		return doc;
	}

	private static List<Cst.TriviaLine> popLeadingComments(Cst.Doc doc, Cst.Section currentSection) {
		List<Cst.Item> list = currentSection == null ? doc.rootItems : currentSection.items;
		int idx = list.size();
		while (idx > 0 && list.get(idx - 1) instanceof Cst.TriviaLine tl && tl.hasComment()) {
			idx--;
		}
		if (idx == list.size()) return List.of();
		List<Cst.TriviaLine> out = new ArrayList<>(list.size() - idx);
		for (int i = idx; i < list.size(); i++) out.add((Cst.TriviaLine) list.get(i));
		list.subList(idx, list.size()).clear();
		return out;
	}

	private static void addItem(Cst.Doc doc, Cst.Section currentSection, Cst.Item item) {
		if (currentSection == null) doc.rootItems.add(item);
		else currentSection.items.add(item);
	}

	private Cst.Section parseSectionHeader(List<Cst.TriviaLine> leadingComments, List<Cst.Tok> leadingWs) {
		int startLine = lex.line, startCol = lex.col, startPos = lex.pos;
		boolean arrayTable = lex.peek(1) == '[';
		Cst.Tok open;
		if (arrayTable) {
			int s = lex.pos;
			lex.advanceAscii();
			lex.advanceAscii();
			open = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(s, lex.pos));
		} else {
			int s = lex.pos;
			lex.advanceAscii();
			open = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(s, lex.pos));
		}
		List<Cst.Tok> preKeyWs = new ArrayList<>();
		Cst.Tok w1 = lex.readWs();
		if (w1 != null) preKeyWs.add(w1);

		Cst.KeyPath keyPath = parseKeyPath();

		List<Cst.Tok> postKeyWs = new ArrayList<>();
		Cst.Tok w2 = lex.readWs();
		if (w2 != null) postKeyWs.add(w2);

		Cst.Tok close;
		if (arrayTable) {
			if (lex.peek() != ']' || lex.peek(1) != ']') {
				throw lex.fail(ErrorKind.UNTERMINATED_CONTAINER, "expected ']]' to close array-of-tables header");
			}
			int s = lex.pos;
			lex.advanceAscii();
			lex.advanceAscii();
			close = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(s, lex.pos));
		} else {
			if (lex.peek() != ']') {
				throw lex.fail(ErrorKind.UNTERMINATED_CONTAINER, "expected ']' to close table header");
			}
			int s = lex.pos;
			lex.advanceAscii();
			close = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(s, lex.pos));
		}

		List<Cst.Tok> trailing = readEndOfStatement();
		sectionId++;
		currentScope = openSectionScope(keyPath.keys, arrayTable, startLine, startCol, startPos);

		return new Cst.Section(arrayTable, leadingComments, leadingWs, open, preKeyWs, keyPath, postKeyWs, close, trailing);
	}

	private Cst.Entry parseEntry(List<Cst.TriviaLine> leadingComments, List<Cst.Tok> leadingWs) {
		int keyLine = lex.line, keyCol = lex.col, keyPos = lex.pos;
		Cst.KeyPath keyPath = parseKeyPath();
		List<Cst.Tok> eqTrivia = readEquals();
		Cst.Val val = parseValue();
		List<Cst.Tok> trailing = readEndOfStatement();
		defineKeyInScope(currentScope, keyPath.keys, val, sectionId, false, keyLine, keyCol, keyPos);
		return new Cst.Entry(leadingComments, leadingWs, keyPath, eqTrivia, val, trailing);
	}

	private List<Cst.Tok> readEquals() {
		List<Cst.Tok> eqTrivia = new ArrayList<>();
		Cst.Tok w1 = lex.readWs();
		if (w1 != null) eqTrivia.add(w1);
		if (lex.peek() != '=') {
			throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "expected '=' after key");
		}
		int s = lex.pos;
		lex.advanceAscii();
		eqTrivia.add(new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(s, lex.pos)));
		Cst.Tok w2 = lex.readWs();
		if (w2 != null) eqTrivia.add(w2);
		return eqTrivia;
	}

	private List<Cst.Tok> readEndOfStatement() {
		List<Cst.Tok> trailing = new ArrayList<>();
		Cst.Tok w = lex.readWs();
		if (w != null) trailing.add(w);
		Cst.Tok comment = lex.readComment();
		if (comment != null) trailing.add(comment);
		if (!lex.eof()) {
			Cst.Tok nl = lex.readNewline();
			if (nl == null) {
				throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "expected newline or end of file");
			}
			trailing.add(nl);
		}
		return trailing;
	}

	private Cst.KeyPath parseKeyPath() {
		List<Cst.Tok> tokens = new ArrayList<>();
		List<String> keys = new ArrayList<>();
		readSingleKey(tokens, keys);
		while (true) {
			int savedPos = lex.pos, savedLine = lex.line, savedCol = lex.col;
			Cst.Tok wsBefore = lex.readWs();
			if (lex.peek() == '.') {
				if (wsBefore != null) tokens.add(wsBefore);
				int dotStart = lex.pos;
				lex.advanceAscii();
				tokens.add(new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(dotStart, lex.pos)));
				Cst.Tok wsAfter = lex.readWs();
				if (wsAfter != null) tokens.add(wsAfter);
				readSingleKey(tokens, keys);
				if (keys.size() > MAX_DEPTH) {
					throw lex.fail(ErrorKind.NESTING_OVERFLOW, "key nesting exceeds " + MAX_DEPTH);
				}
			} else {
				lex.pos = savedPos;
				lex.line = savedLine;
				lex.col = savedCol;
				break;
			}
		}
		return new Cst.KeyPath(tokens, keys);
	}

	private void readSingleKey(List<Cst.Tok> tokens, List<String> keys) {
		if (lex.eof()) throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "expected a key");
		int c = lex.peek();
		if (c == '"') {
			if (lex.peek(1) == '"' && lex.peek(2) == '"') {
				throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "multiline strings cannot be used as keys");
			}
			TomlLexer.StringTok st = lex.readBasicString();
			tokens.add(st.token());
			keys.add(st.decoded());
		} else if (c == '\'') {
			if (lex.peek(1) == '\'' && lex.peek(2) == '\'') {
				throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "multiline literal strings cannot be used as keys");
			}
			TomlLexer.StringTok st = lex.readLiteralString();
			tokens.add(st.token());
			keys.add(st.decoded());
		} else if (TomlLexer.isBareKeyByte(c)) {
			Cst.Tok tok = lex.readBareKey();
			tokens.add(tok);
			keys.add(new String(tok.bytes(), StandardCharsets.UTF_8));
		} else {
			throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "expected a key");
		}
	}

	private Cst.Val parseValue() {
		if (lex.eof()) throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "expected a value");
		int c = lex.peek();
		if (c == '"') {
			TomlLexer.StringTok st = (lex.peek(1) == '"' && lex.peek(2) == '"')
					? lex.readMultilineBasicString()
					: lex.readBasicString();
			return new Cst.Scalar(st.token(), TomlValue.str(st.decoded()));
		}
		if (c == '\'') {
			TomlLexer.StringTok st = (lex.peek(1) == '\'' && lex.peek(2) == '\'')
					? lex.readMultilineLiteralString()
					: lex.readLiteralString();
			return new Cst.Scalar(st.token(), TomlValue.str(st.decoded()));
		}
		if (c == '[') return parseArray();
		if (c == '{') return parseInlineTable();
		return lex.readBareValue();
	}

	private Cst.Arr parseArray() {
		enterContainer();
		int startLine = lex.line, startCol = lex.col, startPos = lex.pos;
		int openStart = lex.pos;
		lex.advanceAscii();
		Cst.Tok open = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(openStart, lex.pos));

		List<Cst.ArrayItem> items = new ArrayList<>();
		List<Cst.Tok> pendingTrivia = readMultilineTrivia();
		while (true) {
			if (lex.eof()) {
				throw lex.failAt(ErrorKind.UNTERMINATED_CONTAINER, "unterminated array", startLine, startCol, startPos);
			}
			if (lex.peek() == ']') {
				int closeStart = lex.pos;
				lex.advanceAscii();
				Cst.Tok close = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(closeStart, lex.pos));
				Cst.Arr arr = new Cst.Arr(open, close);
				arr.items.addAll(items);
				arr.trailingTrivia.addAll(pendingTrivia);
				depth--;
				return arr;
			}
			Cst.Val elem = parseValue();
			List<Cst.Tok> postValTrivia = readMultilineTrivia();
			if (lex.eof()) {
				throw lex.failAt(ErrorKind.UNTERMINATED_CONTAINER, "unterminated array", startLine, startCol, startPos);
			}
			int next = lex.peek();
			if (next == ',') {
				int commaStart = lex.pos;
				lex.advanceAscii();
				Cst.Tok comma = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(commaStart, lex.pos));
				List<Cst.Tok> sameLine = readSameLineTrivia();
				items.add(new Cst.ArrayItem(pendingTrivia, elem, postValTrivia, comma, sameLine));
				pendingTrivia = readMultilineTrivia();
			} else if (next == ']') {
				items.add(new Cst.ArrayItem(pendingTrivia, elem, postValTrivia, null, List.of()));
				pendingTrivia = new ArrayList<>();
			} else {
				throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "expected ',' or ']' in array");
			}
		}
	}

	/** TOML 1.1.0 inline table: supports newlines, comments, and optional trailing comma. */
	private Cst.InlineTable parseInlineTable() {
		enterContainer();
		int startLine = lex.line, startCol = lex.col, startPos = lex.pos;
		int openStart = lex.pos;
		lex.advanceAscii();
		Cst.Tok open = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(openStart, lex.pos));

		TableNode inlineScope = new TableNode(TABLE_INLINE);
		List<Cst.InlineEntry> entries = new ArrayList<>();
		List<Cst.Tok> pendingTrivia = readMultilineTrivia();
		while (true) {
			if (lex.eof()) {
				throw lex.failAt(ErrorKind.UNTERMINATED_CONTAINER, "unterminated inline table", startLine, startCol, startPos);
			}
			if (lex.peek() == '}') {
				int closeStart = lex.pos;
				lex.advanceAscii();
				Cst.Tok close = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(closeStart, lex.pos));
				Cst.InlineTable tbl = new Cst.InlineTable(open, close);
				tbl.entries.addAll(entries);
				tbl.trailingTrivia.addAll(pendingTrivia);
				depth--;
				return tbl;
			}
			int keyLine = lex.line, keyCol = lex.col, keyPos = lex.pos;
			Cst.KeyPath keyPath = parseKeyPath();
			List<Cst.Tok> eqTrivia = readEquals();
			Cst.Val val = parseValue();
			defineKeyInScope(inlineScope, keyPath.keys, val, -1, true, keyLine, keyCol, keyPos);

			List<Cst.Tok> postValTrivia = readMultilineTrivia();
			if (lex.eof()) {
				throw lex.failAt(ErrorKind.UNTERMINATED_CONTAINER, "unterminated inline table", startLine, startCol, startPos);
			}
			int next = lex.peek();
			if (next == ',') {
				int commaStart = lex.pos;
				lex.advanceAscii();
				Cst.Tok comma = new Cst.Tok(Cst.TokKind.PUNCT, lex.slice(commaStart, lex.pos));
				List<Cst.Tok> sameLine = readSameLineTrivia();
				entries.add(new Cst.InlineEntry(pendingTrivia, keyPath, eqTrivia, val, postValTrivia, comma, sameLine));
				pendingTrivia = readMultilineTrivia();
			} else if (next == '}') {
				entries.add(new Cst.InlineEntry(pendingTrivia, keyPath, eqTrivia, val, postValTrivia, null, List.of()));
				pendingTrivia = new ArrayList<>();
			} else {
				throw lex.fail(ErrorKind.UNEXPECTED_TOKEN, "expected ',' or '}' in inline table");
			}
		}
	}

	/** Consumes same-line WS, optional trailing comment, and optional newline (if a comment/NL is present). */
	private List<Cst.Tok> readSameLineTrivia() {
		List<Cst.Tok> out = new ArrayList<>();
		int savedPos = lex.pos, savedLine = lex.line, savedCol = lex.col;
		Cst.Tok ws = lex.readWs();
		int next = lex.peek();
		if (next == '#' || next == '\n' || next == '\r') {
			if (ws != null) out.add(ws);
			Cst.Tok comment = lex.readComment();
			if (comment != null) out.add(comment);
			Cst.Tok nl = lex.readNewline();
			if (nl != null) out.add(nl);
		} else {
			lex.pos = savedPos;
			lex.line = savedLine;
			lex.col = savedCol;
		}
		return out;
	}

	private List<Cst.Tok> readMultilineTrivia() {
		List<Cst.Tok> out = new ArrayList<>();
		while (!lex.eof()) {
			Cst.Tok ws = lex.readWs();
			if (ws != null) {
				out.add(ws);
				continue;
			}
			Cst.Tok comment = lex.readComment();
			if (comment != null) {
				out.add(comment);
				continue;
			}
			Cst.Tok nl = lex.readNewline();
			if (nl != null) {
				out.add(nl);
				continue;
			}
			break;
		}
		return out;
	}

	private void enterContainer() {
		depth++;
		if (depth > MAX_DEPTH) {
			throw lex.fail(ErrorKind.NESTING_OVERFLOW, "container nesting exceeds " + MAX_DEPTH);
		}
	}

	// ------------------------------------------------------------------ TOML 1.1.0 scope validation

	private TableNode openSectionScope(List<String> keys, boolean arrayTable, int l, int c, int p) {
		TableNode current = rootScope;
		for (int i = 0; i < keys.size() - 1; i++) {
			String seg = keys.get(i);
			ScopeNode existing = current.children.get(seg);
			if (existing == null) {
				TableNode next = new TableNode(TABLE_IMPLICIT_SUPER, sectionId);
				current.children.put(seg, next);
				current = next;
			} else if (existing instanceof TableNode tbl) {
				if (tbl.kind == TABLE_INLINE) {
					throw lex.failAt(ErrorKind.REDEFINED_TABLE, "cannot extend inline table '" + seg + "'", l, c, p);
				}
				current = tbl;
			} else if (existing instanceof ArrayOfTablesNode aot) {
				current = aot.elements.get(aot.elements.size() - 1);
			} else {
				throw lex.failAt(ErrorKind.REDEFINED_TABLE, "key '" + seg + "' is already defined as a non-table value", l, c, p);
			}
		}
		String last = keys.get(keys.size() - 1);
		ScopeNode existing = current.children.get(last);
		if (arrayTable) {
			if (existing == null) {
				ArrayOfTablesNode aot = new ArrayOfTablesNode();
				TableNode elem = new TableNode(TABLE_EXPLICIT, sectionId);
				aot.elements.add(elem);
				current.children.put(last, aot);
				return elem;
			}
			if (existing instanceof ArrayOfTablesNode aot) {
				TableNode elem = new TableNode(TABLE_EXPLICIT, sectionId);
				aot.elements.add(elem);
				return elem;
			}
			throw lex.failAt(ErrorKind.REDEFINED_TABLE, "cannot redefine '" + last + "' as an array of tables", l, c, p);
		}
		// Standard [table] header
		if (existing == null) {
			TableNode created = new TableNode(TABLE_EXPLICIT, sectionId);
			current.children.put(last, created);
			return created;
		}
		if (existing instanceof TableNode tbl && tbl.kind == TABLE_IMPLICIT_SUPER) {
			tbl.kind = TABLE_EXPLICIT;
			tbl.ownerSectionId = sectionId;
			return tbl;
		}
		throw lex.failAt(ErrorKind.REDEFINED_TABLE, "table '" + last + "' is already defined", l, c, p);
	}

	private void defineKeyInScope(TableNode scope, List<String> keys, Cst.Val val, int activeSectionId, boolean insideInline, int l, int c, int p) {
		TableNode current = scope;
		for (int i = 0; i < keys.size() - 1; i++) {
			String seg = keys.get(i);
			ScopeNode existing = current.children.get(seg);
			if (existing == null) {
				TableNode next = new TableNode(TABLE_DOTTED_IMPLICIT, activeSectionId);
				current.children.put(seg, next);
				current = next;
			} else if (existing instanceof TableNode tbl) {
				if (tbl.kind == TABLE_INLINE) {
					throw lex.failAt(ErrorKind.REDEFINED_TABLE, "cannot add keys to inline table '" + seg + "'", l, c, p);
				}
				if (tbl.kind == TABLE_EXPLICIT) {
					throw lex.failAt(ErrorKind.REDEFINED_TABLE, "cannot add dotted keys to explicitly defined table '" + seg + "'", l, c, p);
				}
				if (tbl.kind == TABLE_IMPLICIT_SUPER) {
					throw lex.failAt(ErrorKind.REDEFINED_TABLE, "cannot add dotted keys to super-table '" + seg + "' defined by a header", l, c, p);
				}
				if (!insideInline && tbl.ownerSectionId != activeSectionId) {
					throw lex.failAt(ErrorKind.REDEFINED_TABLE, "cannot reopen dotted table '" + seg + "' from another section", l, c, p);
				}
				current = tbl;
			} else {
				throw lex.failAt(ErrorKind.DUPLICATE_KEY, "key '" + seg + "' is already defined as a non-table value", l, c, p);
			}
		}
		String last = keys.get(keys.size() - 1);
		if (current.children.containsKey(last)) {
			throw lex.failAt(ErrorKind.DUPLICATE_KEY, "duplicate key '" + last + "'", l, c, p);
		}
		if (val instanceof Cst.InlineTable) {
			current.children.put(last, new TableNode(TABLE_INLINE, activeSectionId));
		} else {
			current.children.put(last, LeafNode.INSTANCE);
		}
	}
}
