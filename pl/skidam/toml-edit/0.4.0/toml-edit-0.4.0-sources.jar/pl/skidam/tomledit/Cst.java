package pl.skidam.tomledit;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Structured concrete syntax tree for TOML 1.1.0.
 *
 * <p>Every byte of the input lives in a {@link Tok}. Walking a {@link Doc} and concatenating
 * every token's bytes reproduces the source byte-for-byte.
 */
final class Cst {
	private Cst() {}

	enum TokKind {
		BOM, WS, NL, COMMENT,
		BARE_KEY, BASIC_STR, ML_BASIC_STR, LITERAL_STR, ML_LITERAL_STR,
		INT, FLOAT, BOOL,
		OFFSET_DATETIME, LOCAL_DATETIME, LOCAL_DATE, LOCAL_TIME,
		PUNCT
	}

	static final class Tok {
		final TokKind kind;
		final byte[] bytes;

		Tok(TokKind kind, byte[] bytes) {
			this.kind = kind;
			this.bytes = bytes;
		}

		TokKind kind() {
			return kind;
		}

		byte[] bytes() {
			return bytes;
		}
	}

	/** A dotted or single key preserving exact token spelling and whitespace around dots. */
	static final class KeyPath {
		final List<Tok> tokens;
		final List<String> keys;

		KeyPath(List<Tok> tokens, List<String> keys) {
			this.tokens = new ArrayList<>(tokens);
			this.keys = new ArrayList<>(keys);
		}
	}

	sealed interface Item permits TriviaLine, Entry {}

	/** Standalone blank line or comment line (optional WS, optional COMMENT, optional NL). */
	static final class TriviaLine implements Item {
		final List<Tok> tokens;

		TriviaLine(List<Tok> tokens) {
			this.tokens = new ArrayList<>(tokens);
		}

		boolean hasComment() {
			for (Tok tok : tokens) if (tok.kind() == TokKind.COMMENT) return true;
			return false;
		}
	}

	/** A key = value line inside root or a section, owning its attached leading comment lines. */
	static final class Entry implements Item {
		final List<TriviaLine> leadingComments;
		final List<Tok> leadingWs;
		final KeyPath key;
		final List<Tok> eqTrivia;
		Val value;
		final List<Tok> trailingTrivia;

		Entry(List<TriviaLine> leadingComments, List<Tok> leadingWs, KeyPath key, List<Tok> eqTrivia, Val value, List<Tok> trailingTrivia) {
			this.leadingComments = new ArrayList<>(leadingComments);
			this.leadingWs = new ArrayList<>(leadingWs);
			this.key = key;
			this.eqTrivia = new ArrayList<>(eqTrivia);
			this.value = value;
			this.trailingTrivia = new ArrayList<>(trailingTrivia);
		}
	}

	/** A [table] or [[array-table]] header and its owned items, plus its attached leading comment lines. */
	static final class Section {
		final boolean arrayTable;
		final List<TriviaLine> leadingComments;
		final List<Tok> leadingWs;
		final Tok openBracket;
		final List<Tok> preKeyWs;
		final KeyPath headerKey;
		final List<Tok> postKeyWs;
		final Tok closeBracket;
		final List<Tok> trailingTrivia;
		final List<Item> items = new ArrayList<>();

		Section(boolean arrayTable, List<TriviaLine> leadingComments, List<Tok> leadingWs, Tok openBracket, List<Tok> preKeyWs,
				KeyPath headerKey, List<Tok> postKeyWs, Tok closeBracket, List<Tok> trailingTrivia) {
			this.arrayTable = arrayTable;
			this.leadingComments = new ArrayList<>(leadingComments);
			this.leadingWs = new ArrayList<>(leadingWs);
			this.openBracket = openBracket;
			this.preKeyWs = new ArrayList<>(preKeyWs);
			this.headerKey = headerKey;
			this.postKeyWs = new ArrayList<>(postKeyWs);
			this.closeBracket = closeBracket;
			this.trailingTrivia = new ArrayList<>(trailingTrivia);
		}
	}

	/** Top-level document: optional BOM, root items, and [table]/[[array-table]] sections. */
	static final class Doc {
		Tok bom;
		final List<Item> rootItems = new ArrayList<>();
		final List<Section> sections = new ArrayList<>();
		CstNavigator.SectionIndex sectionIndex;

		void addSection(int index, Section section) {
			sections.add(index, section);
			sectionIndex = null;
		}

		void removeSections(Predicate<Section> filter) {
			if (sections.removeIf(filter)) {
				sectionIndex = null;
			}
		}

		void removeAllSections(List<Section> toRemove) {
			if (sections.removeAll(toRemove)) {
				sectionIndex = null;
			}
		}

		void invalidateSectionIndex() {
			sectionIndex = null;
		}
	}

	sealed interface Val permits Scalar, Arr, InlineTable {}

	static final class Scalar implements Val {
		final Tok token;
		final TomlValue value;

		Scalar(Tok token, TomlValue value) {
			this.token = token;
			this.value = value;
		}
	}

	static final class ArrayItem {
		final List<Tok> leadingTrivia;
		Val value;
		final List<Tok> postValueTrivia;
		Tok comma; // nullable
		final List<Tok> trailingSameLineTrivia;

		ArrayItem(List<Tok> leadingTrivia, Val value, List<Tok> postValueTrivia, Tok comma, List<Tok> trailingSameLineTrivia) {
			this.leadingTrivia = new ArrayList<>(leadingTrivia);
			this.value = value;
			this.postValueTrivia = new ArrayList<>(postValueTrivia);
			this.comma = comma;
			this.trailingSameLineTrivia = new ArrayList<>(trailingSameLineTrivia);
		}
	}

	static final class Arr implements Val {
		final Tok openBracket;
		final List<ArrayItem> items = new ArrayList<>();
		final List<Tok> trailingTrivia = new ArrayList<>();
		final Tok closeBracket;

		Arr(Tok openBracket, Tok closeBracket) {
			this.openBracket = openBracket;
			this.closeBracket = closeBracket;
		}
	}

	static final class InlineEntry {
		final List<Tok> leadingTrivia;
		final KeyPath key;
		final List<Tok> eqTrivia;
		Val value;
		final List<Tok> postValueTrivia;
		Tok comma; // nullable
		final List<Tok> trailingSameLineTrivia;

		InlineEntry(List<Tok> leadingTrivia, KeyPath key, List<Tok> eqTrivia, Val value, List<Tok> postValueTrivia, Tok comma, List<Tok> trailingSameLineTrivia) {
			this.leadingTrivia = new ArrayList<>(leadingTrivia);
			this.key = key;
			this.eqTrivia = new ArrayList<>(eqTrivia);
			this.value = value;
			this.postValueTrivia = new ArrayList<>(postValueTrivia);
			this.comma = comma;
			this.trailingSameLineTrivia = new ArrayList<>(trailingSameLineTrivia);
		}
	}

	static final class InlineTable implements Val {
		final Tok openBrace;
		final List<InlineEntry> entries = new ArrayList<>();
		final List<Tok> trailingTrivia = new ArrayList<>();
		final Tok closeBrace;

		InlineTable(Tok openBrace, Tok closeBrace) {
			this.openBrace = openBrace;
			this.closeBrace = closeBrace;
		}
	}

	// ------------------------------------------------------------------ shared CST primitives

	static Val parseInlineVal(TomlValue value) {
		String rendered = CanonicalWriter.formatInline(value);
		return TomlParser.parseValueFragment(rendered.getBytes(StandardCharsets.UTF_8));
	}

	static List<Tok> eqTrivia() {
		return List.of(
				new Tok(TokKind.WS, new byte[] {' '}),
				new Tok(TokKind.PUNCT, new byte[] {'='}),
				new Tok(TokKind.WS, new byte[] {' '}));
	}

	static boolean hasNewline(List<Tok> toks) {
		for (Tok tok : toks) if (tok.kind() == TokKind.NL) return true;
		return false;
	}

	static boolean endsWithNewline(List<Tok> toks) {
		return !toks.isEmpty() && toks.get(toks.size() - 1).kind() == TokKind.NL;
	}

	static List<Tok> extractSameLineFromTrivia(List<Tok> postValueTrivia, List<Tok> containerTrailing) {
		if (postValueTrivia.isEmpty()) return List.of();
		List<Tok> sameLine = new ArrayList<>();
		int split = postValueTrivia.size();
		for (int i = 0; i < postValueTrivia.size(); i++) {
			Tok tok = postValueTrivia.get(i);
			sameLine.add(tok);
			if (tok.kind() == TokKind.NL) {
				split = i + 1;
				break;
			}
		}
		if (split < postValueTrivia.size()) {
			containerTrailing.addAll(0, postValueTrivia.subList(split, postValueTrivia.size()));
		}
		postValueTrivia.clear();
		return sameLine;
	}

	static boolean isArrayOfTables(TomlValue.Array arr) {
		if (arr.isEmpty()) return false;
		for (int i = 0; i < arr.size(); i++) {
			if (!(arr.get(i) instanceof TomlValue.Table)) return false;
		}
		return true;
	}

	// ------------------------------------------------------------------ rendering

	private static final class ByteSink {
		byte[] out;
		int offset;

		void accept(Tok tok) {
			byte[] bytes = tok.bytes;
			if (out != null) {
				System.arraycopy(bytes, 0, out, offset, bytes.length);
			}
			offset += bytes.length;
		}
	}

	static byte[] render(Doc doc) {
		ByteSink sink = new ByteSink();
		walkDoc(doc, sink);
		sink.out = new byte[sink.offset];
		sink.offset = 0;
		walkDoc(doc, sink);
		return sink.out;
	}

	private static void walkDoc(Doc doc, ByteSink sink) {
		if (doc.bom != null) sink.accept(doc.bom);
		for (Item item : doc.rootItems) walkItem(item, sink);
		for (Section section : doc.sections) walkSection(section, sink);
	}

	private static void walkSection(Section section, ByteSink sink) {
		for (TriviaLine comment : section.leadingComments) walkToks(comment.tokens, sink);
		walkToks(section.leadingWs, sink);
		sink.accept(section.openBracket);
		walkToks(section.preKeyWs, sink);
		walkToks(section.headerKey.tokens, sink);
		walkToks(section.postKeyWs, sink);
		sink.accept(section.closeBracket);
		walkToks(section.trailingTrivia, sink);
		for (Item item : section.items) walkItem(item, sink);
	}

	private static void walkItem(Item item, ByteSink sink) {
		if (item instanceof TriviaLine trivia) {
			walkToks(trivia.tokens, sink);
			return;
		}
		Entry entry = (Entry) item;
		for (TriviaLine comment : entry.leadingComments) walkToks(comment.tokens, sink);
		walkToks(entry.leadingWs, sink);
		walkToks(entry.key.tokens, sink);
		walkToks(entry.eqTrivia, sink);
		walkVal(entry.value, sink);
		walkToks(entry.trailingTrivia, sink);
	}

	private static void walkVal(Val val, ByteSink sink) {
		if (val instanceof Scalar scalar) {
			sink.accept(scalar.token);
			return;
		}
		if (val instanceof Arr arr) {
			sink.accept(arr.openBracket);
			for (ArrayItem item : arr.items) {
				walkToks(item.leadingTrivia, sink);
				walkVal(item.value, sink);
				walkToks(item.postValueTrivia, sink);
				if (item.comma != null) sink.accept(item.comma);
				walkToks(item.trailingSameLineTrivia, sink);
			}
			walkToks(arr.trailingTrivia, sink);
			sink.accept(arr.closeBracket);
			return;
		}
		InlineTable tbl = (InlineTable) val;
		sink.accept(tbl.openBrace);
		for (InlineEntry entry : tbl.entries) {
			walkToks(entry.leadingTrivia, sink);
			walkToks(entry.key.tokens, sink);
			walkToks(entry.eqTrivia, sink);
			walkVal(entry.value, sink);
			walkToks(entry.postValueTrivia, sink);
			if (entry.comma != null) sink.accept(entry.comma);
			walkToks(entry.trailingSameLineTrivia, sink);
		}
		walkToks(tbl.trailingTrivia, sink);
		sink.accept(tbl.closeBrace);
	}

	private static void walkToks(List<Tok> toks, ByteSink sink) {
		for (Tok tok : toks) sink.accept(tok);
	}

	// ------------------------------------------------------------------ depth validation

	/**
	 * Verifies that container nesting and dotted-key depths stay within {@code maxDepth} so every
	 * mutated CST remains parseable by {@link TomlParser} (INV-6).
	 */
	static void validateDepth(Doc doc, int maxDepth) {
		for (Item item : doc.rootItems) {
			if (item instanceof Entry entry) validateEntryDepth(entry, maxDepth);
		}
		for (Section section : doc.sections) {
			if (section.headerKey.keys.size() > maxDepth) {
				throw new TomlEditException("TOML key nesting exceeds " + maxDepth);
			}
			for (Item item : section.items) {
				if (item instanceof Entry entry) validateEntryDepth(entry, maxDepth);
			}
		}
	}

	private static void validateEntryDepth(Entry entry, int maxDepth) {
		if (entry.key.keys.size() > maxDepth) {
			throw new TomlEditException("TOML key nesting exceeds " + maxDepth);
		}
		validateValDepth(entry.value, 0, maxDepth);
	}

	private static void validateValDepth(Val val, int depth, int maxDepth) {
		if (val instanceof Arr arr) {
			int next = depth + 1;
			if (next > maxDepth) {
				throw new TomlEditException("TOML container nesting exceeds " + maxDepth);
			}
			for (ArrayItem item : arr.items) {
				validateValDepth(item.value, next, maxDepth);
			}
		} else if (val instanceof InlineTable tbl) {
			int next = depth + 1;
			if (next > maxDepth) {
				throw new TomlEditException("TOML container nesting exceeds " + maxDepth);
			}
			for (InlineEntry entry : tbl.entries) {
				if (entry.key.keys.size() > maxDepth) {
					throw new TomlEditException("TOML key nesting exceeds " + maxDepth);
				}
				validateValDepth(entry.value, next, maxDepth);
			}
		}
	}

	// ------------------------------------------------------------------ semantic derivation

	/** Derives the semantic {@link TomlValue.Table} directly from a validated CST without re-parsing. */
	static TomlValue.Table toTable(Doc doc) {
		TomlValue.Table root = TomlValue.table();
		for (Item item : doc.rootItems) {
			if (item instanceof Entry entry) insertDotted(root, entry.key.keys, toValue(entry.value));
		}
		for (Section section : doc.sections) {
			TomlValue.Table target = resolveSectionTarget(root, section.headerKey.keys, section.arrayTable);
			for (Item item : section.items) {
				if (item instanceof Entry entry) insertDotted(target, entry.key.keys, toValue(entry.value));
			}
		}
		return root;
	}

	static TomlValue toValue(Val val) {
		if (val instanceof Scalar s) return s.value;
		if (val instanceof Arr a) {
			TomlValue.Array out = TomlValue.array();
			for (ArrayItem item : a.items) out.add(toValue(item.value));
			return out;
		}
		InlineTable t = (InlineTable) val;
		TomlValue.Table out = TomlValue.table();
		for (InlineEntry entry : t.entries) insertDotted(out, entry.key.keys, toValue(entry.value));
		return out;
	}

	private static TomlValue.Table resolveSectionTarget(TomlValue.Table root, List<String> keys, boolean arrayTable) {
		TomlValue.Table current = root;
		for (int i = 0; i < keys.size() - 1; i++) {
			String seg = keys.get(i);
			TomlValue existing = current.get(seg);
			if (existing == null) {
				TomlValue.Table next = TomlValue.table();
				current.put(seg, next);
				current = next;
			} else if (existing instanceof TomlValue.Table tbl) {
				current = tbl;
			} else if (existing instanceof TomlValue.Array arr) {
				current = (TomlValue.Table) arr.get(arr.size() - 1);
			} else {
				throw new IllegalStateException("validated CST contains non-table parent: " + seg);
			}
		}
		String last = keys.get(keys.size() - 1);
		if (arrayTable) {
			TomlValue existing = current.get(last);
			TomlValue.Array arr;
			if (existing == null) {
				arr = TomlValue.array();
				current.put(last, arr);
			} else {
				arr = (TomlValue.Array) existing;
			}
			TomlValue.Table elem = TomlValue.table();
			arr.add(elem);
			return elem;
		}
		TomlValue existing = current.get(last);
		if (existing == null) {
			TomlValue.Table created = TomlValue.table();
			current.put(last, created);
			return created;
		}
		return (TomlValue.Table) existing;
	}

	private static void insertDotted(TomlValue.Table target, List<String> keys, TomlValue value) {
		TomlValue.Table current = target;
		for (int i = 0; i < keys.size() - 1; i++) {
			String seg = keys.get(i);
			TomlValue existing = current.get(seg);
			if (existing == null) {
				TomlValue.Table next = TomlValue.table();
				current.put(seg, next);
				current = next;
			} else {
				current = (TomlValue.Table) existing;
			}
		}
		String last = keys.get(keys.size() - 1);
		if (current.containsKey(last)) {
			throw new IllegalStateException("corrupted CST: duplicate key '" + last + "'");
		}
		current.put(last, value);
	}
}
