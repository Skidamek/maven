package pl.skidam.tomledit;

import java.nio.charset.StandardCharsets;
import java.util.Objects;

/** Public entry point for parsing and canonical TOML writing. */
public final class TomlEdit {
	private TomlEdit() {}

	/**
	 * Parses a UTF-8 TOML 1.1.0 document. Fail-fast; returns either a {@link Document} or a {@link ParseError}.
	 *
	 * @param bytes raw UTF-8 TOML bytes
	 * @return a {@link Document} on success or a positioned {@link ParseError} on syntax/UTF-8 failure
	 */
	public static ParseResult parse(byte[] bytes) {
		Objects.requireNonNull(bytes, "bytes");
		return parseOwned(bytes.clone());
	}

	/**
	 * Parses a TOML 1.1.0 document from a Java {@link String}. Rejects unpaired UTF-16 surrogates as
	 * {@link ErrorKind#INVALID_UTF8} rather than silently replacing them.
	 *
	 * @param text TOML source text
	 * @return a {@link Document} on success or a positioned {@link ParseError} on syntax/UTF-8 failure
	 */
	public static ParseResult parse(String text) {
		Objects.requireNonNull(text, "text");
		int bad = Utf8.firstUnpairedSurrogate(text);
		if (bad >= 0) {
			return unpairedSurrogateError(text, bad);
		}
		return parseOwned(text.getBytes(StandardCharsets.UTF_8));
	}

	/**
	 * Canonical TOML serialization (1.0.0-compatible subset, UTF-8, no BOM, LF).
	 *
	 * @param root root table to serialize
	 * @return UTF-8 canonical TOML bytes
	 */
	public static byte[] canonical(TomlValue.Table root) {
		return CanonicalWriter.write(root, Comments.NONE);
	}

	/**
	 * Canonical TOML serialization with banner and per-path comments at any depth.
	 *
	 * @param root root table to serialize
	 * @param comments banner and per-path comment declarations
	 * @return UTF-8 canonical TOML bytes
	 */
	public static byte[] canonical(TomlValue.Table root, Comments comments) {
		return CanonicalWriter.write(root, comments);
	}

	/**
	 * Canonical TOML serialization as a {@link String} (1.0.0-compatible subset, LF).
	 *
	 * @param root root table to serialize
	 * @return canonical TOML text
	 */
	public static String canonicalString(TomlValue.Table root) {
		return CanonicalWriter.writeString(root, Comments.NONE);
	}

	/**
	 * Canonical TOML serialization as a {@link String} with banner and per-path comments at any depth.
	 *
	 * @param root root table to serialize
	 * @param comments banner and per-path comment declarations
	 * @return canonical TOML text
	 */
	public static String canonicalString(TomlValue.Table root, Comments comments) {
		return CanonicalWriter.writeString(root, comments);
	}

	private static ParseResult parseOwned(byte[] owned) {
		try {
			Cst.Doc doc = TomlParser.parse(owned);
			return new Document(doc, owned);
		} catch (ParseFailure failure) {
			return failure.toParseError();
		}
	}

	private static ParseError unpairedSurrogateError(String text, int badIndex) {
		int line = 1;
		int col = 1;
		int byteOffset = 0;
		int i = 0;
		while (i < badIndex) {
			char c = text.charAt(i);
			if (Character.isHighSurrogate(c)) {
				i += 2;
				col++;
				byteOffset += 4;
				continue;
			}
			if (c == '\n') {
				line++;
				col = 1;
				byteOffset++;
				i++;
			} else if (c == '\r') {
				line++;
				col = 1;
				if (i + 1 < badIndex && text.charAt(i + 1) == '\n') {
					byteOffset += 2;
					i += 2;
				} else {
					byteOffset++;
					i++;
				}
			} else {
				col++;
				byteOffset += c < 0x80 ? 1 : (c < 0x800 ? 2 : 3);
				i++;
			}
		}
		return new ParseError(ErrorKind.INVALID_UTF8, "input contains an unpaired UTF-16 surrogate", line, col, byteOffset);
	}
}
