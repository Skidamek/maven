package pl.skidam.tomledit;

import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Shared validation and deep-copy helpers over {@link TomlValue} trees.
 *
 * <p>Validation is enforced at public input boundaries (builder declarations, document edits,
 * schema application, and public {@link TomlValue#copy()}); internal copies operate on
 * already-validated trees without re-allocating cycle-tracking maps.
 */
final class TomlTrees {
	private TomlTrees() {}

	/**
	 * Validates {@code value} for cycles and TOML nesting depth when placed at {@code baseTableDepth},
	 * throwing {@link TomlEditException} on failure.
	 *
	 * <p>Pass {@code baseTableDepth = 0} for a document root table, or {@code path.size()} for a
	 * value placed at a table member path.
	 */
	static void validateForEdit(TomlValue value, int baseTableDepth) {
		validate(value, baseTableDepth, true);
	}

	/**
	 * Validates {@code value} for cycles and TOML nesting depth when declared in a schema builder at
	 * {@code baseTableDepth}, throwing {@link IllegalArgumentException} on failure.
	 */
	static void validateForBuilder(TomlValue value, int baseTableDepth) {
		validate(value, baseTableDepth, false);
	}

	/**
	 * Plain deep copy for already-validated acyclic {@link TomlValue} trees. Scalars are immutable
	 * and returned directly.
	 */
	static TomlValue deepCopy(TomlValue value) {
		if (value instanceof TomlValue.Table table) {
			TomlValue.Table copy = TomlValue.table();
			for (Map.Entry<String, TomlValue> entry : table.members().entrySet()) {
				copy.put(entry.getKey(), deepCopy(entry.getValue()));
			}
			return copy;
		}
		if (value instanceof TomlValue.Array array) {
			TomlValue.Array copy = TomlValue.array();
			for (TomlValue element : array.elements()) {
				copy.add(deepCopy(element));
			}
			return copy;
		}
		return value;
	}

	private static void validate(TomlValue value, int baseTableDepth, boolean editException) {
		IdentityHashMap<TomlValue, Boolean> active = new IdentityHashMap<>();
		if (value instanceof TomlValue.Table table) {
			if (baseTableDepth > TomlParser.MAX_DEPTH) {
				throw depthFailure("TOML key nesting exceeds " + TomlParser.MAX_DEPTH, editException);
			}
			validateTable(table, baseTableDepth, 0, active, editException);
		} else if (value instanceof TomlValue.Array array) {
			if (Cst.isArrayOfTables(array)) {
				if (baseTableDepth > TomlParser.MAX_DEPTH) {
					throw depthFailure("TOML key nesting exceeds " + TomlParser.MAX_DEPTH, editException);
				}
				validateArrayOfTables(array, baseTableDepth, active, editException);
			} else {
				validateValue(array, baseTableDepth, 0, active, editException);
			}
		}
	}

	private static void validateValue(TomlValue value, int tableDepth, int inlineDepth,
			IdentityHashMap<TomlValue, Boolean> active, boolean editException) {
		if (value instanceof TomlValue.Table table) {
			if (inlineDepth > 0) {
				int nextInline = inlineDepth + 1;
				if (nextInline > TomlParser.MAX_DEPTH) {
					throw depthFailure("TOML container nesting exceeds " + TomlParser.MAX_DEPTH, editException);
				}
				validateTable(table, tableDepth, nextInline, active, editException);
			} else {
				int nextTable = tableDepth + 1;
				if (nextTable > TomlParser.MAX_DEPTH) {
					throw depthFailure("TOML key nesting exceeds " + TomlParser.MAX_DEPTH, editException);
				}
				validateTable(table, nextTable, 0, active, editException);
			}
		} else if (value instanceof TomlValue.Array array) {
			if (inlineDepth == 0 && Cst.isArrayOfTables(array)) {
				int nextTable = tableDepth + 1;
				if (nextTable > TomlParser.MAX_DEPTH) {
					throw depthFailure("TOML key nesting exceeds " + TomlParser.MAX_DEPTH, editException);
				}
				validateArrayOfTables(array, nextTable, active, editException);
			} else {
				int nextInline = inlineDepth + 1;
				if (nextInline > TomlParser.MAX_DEPTH) {
					throw depthFailure("TOML container nesting exceeds " + TomlParser.MAX_DEPTH, editException);
				}
				enterActive(array, active, editException);
				try {
					for (TomlValue element : array.elements()) {
						validateValue(element, tableDepth, nextInline, active, editException);
					}
				} finally {
					active.remove(array);
				}
			}
		}
	}

	private static void validateArrayOfTables(TomlValue.Array array, int tableDepth,
			IdentityHashMap<TomlValue, Boolean> active, boolean editException) {
		enterActive(array, active, editException);
		try {
			for (TomlValue element : array.elements()) {
				validateTable((TomlValue.Table) element, tableDepth, 0, active, editException);
			}
		} finally {
			active.remove(array);
		}
	}

	private static void validateTable(TomlValue.Table table, int tableDepth, int inlineDepth,
			IdentityHashMap<TomlValue, Boolean> active, boolean editException) {
		enterActive(table, active, editException);
		try {
			for (TomlValue member : table.members().values()) {
				validateValue(member, tableDepth, inlineDepth, active, editException);
			}
		} finally {
			active.remove(table);
		}
	}

	private static void enterActive(TomlValue container, IdentityHashMap<TomlValue, Boolean> active, boolean editException) {
		if (active.put(container, Boolean.TRUE) != null) {
			throw cycleFailure(editException);
		}
	}

	private static RuntimeException depthFailure(String message, boolean editException) {
		return editException ? new TomlEditException(message) : new IllegalArgumentException(message);
	}

	private static RuntimeException cycleFailure(boolean editException) {
		String message = "cyclic TOML values are not supported";
		return editException ? new TomlEditException(message) : new IllegalArgumentException(message);
	}
}
