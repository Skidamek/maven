package pl.skidam.tomledit;

import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;

/**
 * Parsed TOML 1.1.0 document holding the lossless concrete syntax tree.
 *
 * <p>Every mutating operation is atomic: if an invalid argument or path throws
 * {@link TomlEditException}, the document's bytes and tree remain unchanged. Multiple operations
 * can be grouped into one atomic transaction with {@link #atomic(Consumer)}. Not thread-safe.
 */
public final class Document implements ParseResult {
	private Cst.Doc cst;
	private byte[] textCache;
	private boolean inTransaction;

	Document(Cst.Doc cst, byte[] originalBytes) {
		this.cst = cst;
		this.textCache = originalBytes;
	}

	/**
	 * Creates a new empty TOML document.
	 *
	 * @return empty {@link Document}
	 */
	public static Document empty() {
		return new Document(new Cst.Doc(), new byte[0]);
	}

	@Override
	public boolean isOk() {
		return true;
	}

	@Override
	public Document document() {
		return this;
	}

	@Override
	public ParseError error() {
		throw new IllegalStateException("this document parsed successfully");
	}

	/**
	 * Returns the current document bytes, exact.
	 *
	 * @return UTF-8 document bytes
	 */
	public byte[] text() {
		if (textCache == null) textCache = Cst.render(cst);
		return textCache.clone();
	}

	/**
	 * Returns the current document decoded as a UTF-8 {@link String}.
	 *
	 * @return exact document text
	 */
	public String textString() {
		if (textCache == null) textCache = Cst.render(cst);
		return new String(textCache, StandardCharsets.UTF_8);
	}

	/**
	 * Returns the semantic TOML table derived directly from the CST. Returns a fresh copy so caller
	 * mutations cannot desync the CST.
	 *
	 * @return semantic root {@link TomlValue.Table}
	 */
	public TomlValue.Table tree() {
		return Cst.toTable(cst);
	}

	/**
	 * Returns a typed {@link TableReader} over a fresh semantic snapshot of this document.
	 *
	 * @return root {@link TableReader}
	 */
	public TableReader reader() {
		return TableReader.of(tree());
	}

	/**
	 * Returns {@code true} if {@code path} resolves to an existing entry, table, section, or array
	 * element in this document.
	 *
	 * @param path target path
	 * @return {@code true} when present
	 */
	public boolean has(ConfigPath path) {
		Objects.requireNonNull(path, "path");
		return CstNavigator.resolve(cst, path) != null;
	}

	/**
	 * Executes multiple edits against this document as a single atomic transaction. If {@code edits}
	 * throws any {@link RuntimeException} or {@link Error}, all changes made within the block are
	 * rolled back so the document stays byte-for-byte unchanged. Grouping sequential edits also
	 * avoids intermediate snapshots.
	 *
	 * <p>Let exceptions propagate out of {@code edits} to trigger rollback; catching a failed edit
	 * inside the block does not roll back that individual step.
	 *
	 * @param edits batch of document mutations
	 */
	public void atomic(Consumer<Document> edits) {
		Objects.requireNonNull(edits, "edits");
		atomicEdit(() -> edits.accept(this));
	}

	Cst.Doc cst() {
		return cst;
	}

	// ------------------------------------------------------------------ surgical edits

	/**
	 * Replaces the value at {@code path}. Preserves surrounding formatting and trailing comments.
	 *
	 * @param path existing target path (non-root)
	 * @param value replacement value
	 */
	public void set(ConfigPath path, TomlValue value) {
		Objects.requireNonNull(path, "path");
		Objects.requireNonNull(value, "value");
		TomlTrees.validateForEdit(value, keyDepth(path));
		atomicEdit(() -> CstEntryEditor.set(cst, path, value));
	}

	/**
	 * Inserts {@code value} into the array (or {@code [[array-of-tables]]}) at {@code path} before
	 * {@code index} ({@code index == size} appends).
	 *
	 * @param path path to an existing array or array-of-tables
	 * @param index insertion index in {@code [0, size]}
	 * @param value element to insert
	 */
	public void arrayInsert(ConfigPath path, int index, TomlValue value) {
		Objects.requireNonNull(path, "path");
		Objects.requireNonNull(value, "value");
		TomlTrees.validateForEdit(value, keyDepth(path));
		atomicEdit(() -> {
			CstNavigator.Target target = CstNavigator.requireTarget(cst, path);
			if (target instanceof CstNavigator.ArrayOfTablesTarget aot) {
				CstSectionEditor.arrayOfTablesInsert(cst, aot, index, value);
				return;
			}
			Cst.Arr arr = asArray(target, path);
			CstArrayEditor.arrayInsert(arr, index, value, CstEntryEditor.detectDocNewline(cst), path);
		});
	}

	/**
	 * Removes the element at {@code index} from the array (or {@code [[array-of-tables]]}) at {@code path}.
	 *
	 * @param path path to an existing array or array-of-tables
	 * @param index element index in {@code [0, size)}
	 */
	public void arrayRemove(ConfigPath path, int index) {
		Objects.requireNonNull(path, "path");
		atomicEdit(() -> {
			CstNavigator.Target target = CstNavigator.requireTarget(cst, path);
			if (target instanceof CstNavigator.ArrayOfTablesTarget aot) {
				CstSectionEditor.arrayOfTablesRemove(cst, aot, index);
				return;
			}
			Cst.Arr arr = asArray(target, path);
			CstArrayEditor.arrayRemove(arr, index, path);
		});
	}

	/**
	 * Reads the contiguous attached comment lines above an entry, section header, array-of-tables,
	 * inline entry, or array element. Returns empty when {@code path} is absent or has no attached
	 * comment.
	 *
	 * @param path target path
	 * @return optional comment text (stripped of leading {@code #} markers)
	 */
	public Optional<String> attachedComment(ConfigPath path) {
		Objects.requireNonNull(path, "path");
		return CstEntryEditor.attachedComment(cst, path);
	}

	/**
	 * Sets or removes ({@code comment == null}) the attached comment block above an entry, table
	 * header, or array-of-tables.
	 *
	 * @param path existing target path
	 * @param comment new comment text, or {@code null} to remove
	 */
	public void setComment(ConfigPath path, String comment) {
		Objects.requireNonNull(path, "path");
		atomicEdit(() -> CstEntryEditor.setComment(cst, path, comment));
	}

	/**
	 * Inserts a new member into {@code parentPath} with an optional attached comment.
	 * When {@code parentPath} targets a single-line inline table, {@code comment} is omitted to
	 * preserve TOML 1.0.0 compatibility.
	 *
	 * @param parentPath path to an existing table (or {@link ConfigPath#root()})
	 * @param key member key name
	 * @param value member value
	 * @param comment optional attached comment text, or {@code null}
	 */
	public void insertMember(ConfigPath parentPath, String key, TomlValue value, String comment) {
		Objects.requireNonNull(parentPath, "parentPath");
		Objects.requireNonNull(key, "key");
		Objects.requireNonNull(value, "value");
		TomlTrees.validateForEdit(value, keyDepth(parentPath) + 1);
		atomicEdit(() -> CstEntryEditor.insertMember(cst, parentPath, key, value, comment, null));
	}

	/**
	 * Removes an existing table member or section at {@code path}.
	 *
	 * @param path existing member or section path
	 */
	public void removeMember(ConfigPath path) {
		Objects.requireNonNull(path, "path");
		atomicEdit(() -> CstEntryEditor.removeMember(cst, path));
	}

	// ------------------------------------------------------------------ reconcile & migration verbs

	/**
	 * Aligns existing document members with {@code model}. Unknown keys stay untouched; absent keys
	 * are not added.
	 *
	 * @param model target semantic table
	 * @param policy array reconciliation strategy
	 */
	public void reconcile(TomlValue.Table model, ReconcilePolicy policy) {
		Objects.requireNonNull(model, "model");
		Objects.requireNonNull(policy, "policy");
		TomlTrees.validateForEdit(model, 0);
		atomicEdit(() -> DocumentEditor.reconcile(cst, model, policy));
	}

	/**
	 * Materializes {@code path} with {@code defaultValue} and optional {@code comment} if absent;
	 * no-op if present.
	 *
	 * @param path target member path
	 * @param defaultValue value to insert when absent
	 * @param comment optional attached comment text, or {@code null}
	 */
	public void ensure(ConfigPath path, TomlValue defaultValue, String comment) {
		Objects.requireNonNull(path, "path");
		Objects.requireNonNull(defaultValue, "defaultValue");
		TomlTrees.validateForEdit(defaultValue, keyDepth(path));
		atomicEdit(() -> DocumentEditor.ensure(cst, path, defaultValue, comment));
	}

	/**
	 * Moves or renames a member or table subtree from {@code from} to {@code to}, preserving its
	 * CST layout, comments, and trailing notes.
	 *
	 * @param from source member path (no-op if absent)
	 * @param to destination member path (if already present, drops {@code from} and keeps {@code to})
	 */
	public void rename(ConfigPath from, ConfigPath to) {
		Objects.requireNonNull(from, "from");
		Objects.requireNonNull(to, "to");
		atomicEdit(() -> DocumentEditor.rename(cst, from, to));
	}

	/**
	 * Idempotent removal of a member or section at {@code path}; no-op if absent.
	 *
	 * @param path target member path
	 */
	public void remove(ConfigPath path) {
		Objects.requireNonNull(path, "path");
		atomicEdit(() -> DocumentEditor.remove(cst, path));
	}

	// ------------------------------------------------------------------ atomicity & helpers

	void atomicEdit(Runnable action) {
		if (inTransaction) {
			try {
				action.run();
			} finally {
				textCache = null;
			}
			return;
		}
		byte[] snapshot = textCache != null ? textCache : Cst.render(cst);
		inTransaction = true;
		try {
			action.run();
			Cst.validateDepth(cst, TomlParser.MAX_DEPTH);
			textCache = null;
		} catch (RuntimeException | Error e) {
			this.cst = TomlParser.parse(snapshot);
			this.textCache = snapshot;
			throw e;
		} finally {
			inTransaction = false;
		}
	}

	private static int keyDepth(ConfigPath path) {
		int depth = 0;
		for (ConfigPath.Segment seg : path.segments()) {
			if (seg instanceof ConfigPath.Segment.Key) depth++;
		}
		return depth;
	}

	private static Cst.Arr asArray(CstNavigator.Target target, ConfigPath path) {
		Cst.Arr arr = target.asArray();
		if (arr != null) return arr;
		throw new TomlEditException("path is not an array: " + path, path);
	}
}
