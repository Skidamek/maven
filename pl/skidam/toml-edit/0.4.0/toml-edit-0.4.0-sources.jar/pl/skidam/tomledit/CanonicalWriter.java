package pl.skidam.tomledit;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Canonical TOML writer emitting the TOML 1.0.0-compatible subset (UTF-8, no BOM, LF).
 *
 * <p>Always formats from semantic values (never raw {@code literal} provenance). Emits root
 * scalar/array entries before any {@code [table]} header, uses single-quoted literal strings for
 * globs and Windows paths where legal, and attaches {@link Comments} at any path depth.
 */
final class CanonicalWriter {
	private static final int MAX_DEPTH = TomlParser.MAX_DEPTH;

	private final StringBuilder out = new StringBuilder();
	private final Comments comments;
	private final IdentityHashMap<Object, Boolean> active = new IdentityHashMap<>();
	private int sectionDepth;
	private int inlineDepth;
	private boolean hasOutput;

	private CanonicalWriter(Comments comments) {
		this.comments = comments;
	}

	static byte[] write(TomlValue.Table root, Comments comments) {
		return writeString(root, comments).getBytes(StandardCharsets.UTF_8);
	}

	static String writeString(TomlValue.Table root, Comments comments) {
		Objects.requireNonNull(root, "root");
		Objects.requireNonNull(comments, "comments");
		CanonicalWriter writer = new CanonicalWriter(comments);
		writer.writeDocument(root);
		String rendered = writer.out.toString();
		Utf8.validateUtf16(rendered);
		return rendered;
	}

	/** Formats a single value in inline TOML 1.0.0 form with strict UTF-8 / cycle / depth validation. */
	static String formatInline(TomlValue value) {
		Objects.requireNonNull(value, "value");
		CanonicalWriter writer = new CanonicalWriter(Comments.NONE);
		writer.writeInlineValue(value);
		String rendered = writer.out.toString();
		Utf8.validateUtf16(rendered);
		return rendered;
	}

	private void writeDocument(TomlValue.Table root) {
		String banner = comments.banner();
		if (banner != null && !banner.isEmpty()) {
			writeCommentBlock(banner);
			hasOutput = true;
		}
		active.put(root, Boolean.TRUE);
		try {
			writeTableBody(root, ConfigPath.root(), true);
		} finally {
			active.remove(root);
		}
	}

	private void writeTableBody(TomlValue.Table table, ConfigPath path, boolean isRoot) {
		List<Map.Entry<String, TomlValue>> direct = new ArrayList<>();
		List<Map.Entry<String, TomlValue>> sections = new ArrayList<>();

		for (Map.Entry<String, TomlValue> entry : table.members().entrySet()) {
			TomlValue val = entry.getValue();
			if (val instanceof TomlValue.Table || (val instanceof TomlValue.Array arr && Cst.isArrayOfTables(arr))) {
				sections.add(entry);
			} else {
				direct.add(entry);
			}
		}

		if (isRoot && hasOutput && !direct.isEmpty()) {
			out.append('\n');
		}
		for (Map.Entry<String, TomlValue> entry : direct) {
			ConfigPath entryPath = path.appended(entry.getKey());
			comments.get(entryPath).ifPresent(this::writeCommentBlock);
			writeKey(entry.getKey());
			out.append(" = ");
			writeInlineValue(entry.getValue());
			out.append('\n');
			hasOutput = true;
		}

		for (Map.Entry<String, TomlValue> entry : sections) {
			ConfigPath subPath = path.appended(entry.getKey());
			if (entry.getValue() instanceof TomlValue.Table sub) {
				writeSubTable(sub, subPath);
			} else {
				writeArrayOfTables((TomlValue.Array) entry.getValue(), subPath);
			}
		}
	}

	private void writeSubTable(TomlValue.Table table, ConfigPath path) {
		enterSection(table);
		try {
			boolean hasDirect = false;
			boolean hasNestedSection = false;
			for (TomlValue val : table.members().values()) {
				if (val instanceof TomlValue.Table || (val instanceof TomlValue.Array arr && Cst.isArrayOfTables(arr))) {
					hasNestedSection = true;
				} else {
					hasDirect = true;
				}
			}
			boolean hasComment = comments.get(path).isPresent();
			// Skip redundant empty intermediate headers (e.g. [modpack.General] when [modpack.General.main] follows)
			boolean emitHeader = hasDirect || hasComment || !hasNestedSection;
			if (emitHeader) {
				if (hasOutput) out.append('\n');
				comments.get(path).ifPresent(this::writeCommentBlock);
				out.append('[');
				writeDottedKey(path);
				out.append("]\n");
				hasOutput = true;
			}
			writeTableBody(table, path, false);
		} finally {
			leaveSection(table);
		}
	}

	private void writeArrayOfTables(TomlValue.Array array, ConfigPath path) {
		enterSection(array);
		try {
			for (int i = 0; i < array.size(); i++) {
				TomlValue.Table elem = (TomlValue.Table) array.get(i);
				enterCycleOnly(elem);
				try {
					if (hasOutput) out.append('\n');
					if (i == 0) {
						comments.get(path).ifPresent(this::writeCommentBlock);
					}
					ConfigPath elemPath = path.appended(i);
					comments.get(elemPath).ifPresent(this::writeCommentBlock);
					out.append("[[");
					writeDottedKey(path);
					out.append("]]\n");
					hasOutput = true;
					writeTableBody(elem, elemPath, false);
				} finally {
					leaveCycleOnly(elem);
				}
			}
		} finally {
			leaveSection(array);
		}
	}

	private void writeInlineValue(TomlValue value) {
		if (value instanceof TomlValue.Str s) {
			writeString(s.value());
		} else if (value instanceof TomlValue.Int i) {
			out.append(i.value());
		} else if (value instanceof TomlValue.Float f) {
			out.append(TomlValue.Float.formatCanonical(f.value()));
		} else if (value instanceof TomlValue.Bool b) {
			out.append(b.value() ? "true" : "false");
		} else if (value instanceof TomlValue.OffsetDateTimeVal dt) {
			out.append(formatOffsetDateTime(dt.value()));
		} else if (value instanceof TomlValue.LocalDateTimeVal dt) {
			out.append(formatLocalDateTime(dt.value()));
		} else if (value instanceof TomlValue.LocalDateVal d) {
			out.append(formatLocalDate(d.value()));
		} else if (value instanceof TomlValue.LocalTimeVal t) {
			out.append(formatLocalTime(t.value()));
		} else if (value instanceof TomlValue.Array arr) {
			enterInline(arr);
			try {
				out.append('[');
				for (int i = 0; i < arr.size(); i++) {
					if (i > 0) out.append(", ");
					writeInlineValue(arr.get(i));
				}
				out.append(']');
			} finally {
				leaveInline(arr);
			}
		} else if (value instanceof TomlValue.Table tbl) {
			enterInline(tbl);
			try {
				if (tbl.isEmpty()) {
					out.append("{}");
					return;
				}
				out.append("{ ");
				boolean first = true;
				for (Map.Entry<String, TomlValue> entry : tbl.members().entrySet()) {
					if (!first) out.append(", ");
					first = false;
					writeKey(entry.getKey());
					out.append(" = ");
					writeInlineValue(entry.getValue());
				}
				out.append(" }");
			} finally {
				leaveInline(tbl);
			}
		}
	}

	private void writeDottedKey(ConfigPath path) {
		boolean first = true;
		for (ConfigPath.Segment seg : path.segments()) {
			if (seg instanceof ConfigPath.Segment.Key key) {
				if (!first) out.append('.');
				first = false;
				writeKey(key.name());
			}
		}
	}

	static String formatKey(String key) {
		if (!key.isEmpty() && isBareKey(key)) return key;
		return formatBasicString(key);
	}

	private void writeKey(String key) {
		out.append(formatKey(key));
	}

	static String formatString(String s) {
		if (preferLiteralString(s)) {
			return "'" + s + "'";
		}
		return formatBasicString(s);
	}

	private void writeString(String s) {
		out.append(formatString(s));
	}

	/** Uses single-quoted literal strings when the string contains \ or " and is legal in TOML literal strings. */
	private static boolean preferLiteralString(String s) {
		boolean hasBackslashOrQuote = false;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '\'' || c == '\n' || c == '\r' || (c < 0x20 && c != '\t') || c == 0x7F) {
				return false;
			}
			if (c == '\\' || c == '"') hasBackslashOrQuote = true;
		}
		return hasBackslashOrQuote;
	}

	static String formatBasicString(String s) {
		StringBuilder sb = new StringBuilder(s.length() + 2);
		sb.append('"');
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			switch (c) {
				case '"' -> sb.append("\\\"");
				case '\\' -> sb.append("\\\\");
				case '\b' -> sb.append("\\b");
				case '\t' -> sb.append("\\t");
				case '\n' -> sb.append("\\n");
				case '\f' -> sb.append("\\f");
				case '\r' -> sb.append("\\r");
				default -> {
					if (c < 0x20 || c == 0x7F) {
						sb.append(String.format(java.util.Locale.ROOT, "\\u%04x", (int) c));
					} else {
						sb.append(c);
					}
				}
			}
		}
		sb.append('"');
		return sb.toString();
	}

	private static boolean isBareKey(String key) {
		for (int i = 0; i < key.length(); i++) {
			if (!TomlLexer.isBareKeyByte(key.charAt(i))) return false;
		}
		return true;
	}

	private void writeCommentBlock(String comment) {
		String[] lines = comment.split("\r\n|\n|\r", -1);
		for (String line : lines) {
			String clean = sanitizeCommentLine(line);
			if (clean.isEmpty()) out.append("#\n");
			else out.append("# ").append(clean).append('\n');
		}
	}

	/** Strips illegal TOML comment control characters (keeps tab and printable Unicode). */
	static String sanitizeCommentLine(String line) {
		StringBuilder sb = null;
		for (int i = 0; i < line.length(); i++) {
			char c = line.charAt(i);
			if (TomlLexer.isIllegalControlChar(c)) {
				if (sb == null) {
					sb = new StringBuilder(line.length());
					sb.append(line, 0, i);
				}
			} else if (sb != null) {
				sb.append(c);
			}
		}
		return sb == null ? line : sb.toString();
	}

	private void enterSection(Object container) {
		if (sectionDepth >= MAX_DEPTH) {
			throw new TomlEditException("TOML key nesting exceeds " + MAX_DEPTH);
		}
		enterCycleOnly(container);
		sectionDepth++;
	}

	private void leaveSection(Object container) {
		sectionDepth--;
		leaveCycleOnly(container);
	}

	private void enterInline(Object container) {
		if (inlineDepth >= MAX_DEPTH) {
			throw new TomlEditException("TOML container nesting exceeds " + MAX_DEPTH);
		}
		enterCycleOnly(container);
		inlineDepth++;
	}

	private void leaveInline(Object container) {
		inlineDepth--;
		leaveCycleOnly(container);
	}

	private void enterCycleOnly(Object container) {
		if (active.put(container, Boolean.TRUE) != null) {
			throw new TomlEditException("cyclic TomlValue cannot be serialized");
		}
	}

	private void leaveCycleOnly(Object container) {
		active.remove(container);
	}

	/** Formats a LocalTime with explicit seconds (TOML 1.0.0 compatible). */
	static String formatLocalTime(java.time.LocalTime t) {
		StringBuilder sb = new StringBuilder(18);
		append2(sb, t.getHour());
		sb.append(':');
		append2(sb, t.getMinute());
		sb.append(':');
		append2(sb, t.getSecond());
		int nano = t.getNano();
		if (nano != 0) {
			sb.append('.');
			String frac = String.format(java.util.Locale.ROOT, "%09d", nano);
			int end = frac.length();
			while (end > 1 && frac.charAt(end - 1) == '0') end--;
			sb.append(frac, 0, end);
		}
		return sb.toString();
	}

	static void validateYear(int year) {
		if (year < 0 || year > 9999) {
			throw new TomlEditException("TOML dates require 4-digit year 0000..9999, got: " + year);
		}
	}

	static void validateOffset(java.time.ZoneOffset off) {
		if (off.getTotalSeconds() % 60 != 0) {
			throw new TomlEditException("TOML timezone offsets cannot include seconds, got: " + off);
		}
	}

	static String formatLocalDate(java.time.LocalDate d) {
		int year = d.getYear();
		validateYear(year);
		return String.format(java.util.Locale.ROOT, "%04d-%02d-%02d", year, d.getMonthValue(), d.getDayOfMonth());
	}

	static String formatLocalDateTime(java.time.LocalDateTime dt) {
		return formatLocalDate(dt.toLocalDate()) + "T" + formatLocalTime(dt.toLocalTime());
	}

	static String formatOffsetDateTime(java.time.OffsetDateTime odt) {
		java.time.ZoneOffset off = odt.getOffset();
		validateOffset(off);
		String offStr = off.getTotalSeconds() == 0 ? "Z" : off.getId();
		return formatLocalDate(odt.toLocalDate()) + "T" + formatLocalTime(odt.toLocalTime()) + offStr;
	}

	private static void append2(StringBuilder sb, int v) {
		sb.append((char) ('0' + (v / 10))).append((char) ('0' + (v % 10)));
	}
}
