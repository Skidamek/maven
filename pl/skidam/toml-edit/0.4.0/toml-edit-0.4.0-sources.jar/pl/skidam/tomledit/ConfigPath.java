package pl.skidam.tomledit;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Immutable path into a TOML document tree: {@link Segment.Key} table keys interleaved with
 * non-negative {@link Segment.Index} array indices. Dots in key segments are literal characters,
 * never split.
 *
 * @param segments ordered list of typed {@link Segment}s
 */
public record ConfigPath(List<Segment> segments) {
	private static final ConfigPath ROOT = new ConfigPath(List.of());

	/** Typed view of a single {@link ConfigPath} segment. */
	public sealed interface Segment permits Segment.Key, Segment.Index {
		/**
		 * Table key segment.
		 *
		 * @param name literal key name
		 */
		record Key(String name) implements Segment {
			/**
			 * Validates that {@code name} is non-null.
			 *
			 * @param name literal key name
			 */
			public Key {
				Objects.requireNonNull(name, "name");
			}
		}

		/**
		 * Array index segment.
		 *
		 * @param index non-negative element index
		 */
		record Index(int index) implements Segment {
			/**
			 * Validates that {@code index} is non-negative.
			 *
			 * @param index non-negative element index
			 */
			public Index {
				if (index < 0) throw new IllegalArgumentException("array index must be non-negative: " + index);
			}
		}
	}

	/**
	 * Validates and defensively copies {@code segments}.
	 *
	 * @param segments ordered list of non-null {@link Segment}s
	 */
	public ConfigPath {
		Objects.requireNonNull(segments, "segments");
		for (Segment segment : segments) {
			Objects.requireNonNull(segment, "segment");
		}
		segments = List.copyOf(segments);
	}

	/**
	 * Returns the empty root path.
	 *
	 * @return root path
	 */
	public static ConfigPath root() {
		return ROOT;
	}

	/**
	 * Creates a non-empty path from {@link String} keys, non-negative {@link Integer} indices, or
	 * {@link Segment} instances.
	 *
	 * @param segments one or more path segments
	 * @return constructed {@link ConfigPath}
	 */
	public static ConfigPath of(Object... segments) {
		Objects.requireNonNull(segments, "segments");
		if (segments.length == 0) throw new IllegalArgumentException("empty path");
		List<Segment> list = new ArrayList<>(segments.length);
		for (Object segment : segments) list.add(toSegment(segment));
		return new ConfigPath(list);
	}

	/**
	 * Returns {@code true} if this path represents the document root.
	 *
	 * @return {@code true} when empty
	 */
	public boolean isRoot() {
		return segments.isEmpty();
	}

	/**
	 * Returns the number of segments in this path.
	 *
	 * @return segment count
	 */
	public int size() {
		return segments.size();
	}

	/**
	 * Returns the parent path (all segments except the last).
	 *
	 * @return parent {@link ConfigPath}
	 * @throws IllegalArgumentException if this is the root path
	 */
	public ConfigPath parent() {
		if (segments.isEmpty()) throw new IllegalArgumentException("root path has no parent");
		return new ConfigPath(segments.subList(0, segments.size() - 1));
	}

	/**
	 * Returns the final {@link Segment}.
	 *
	 * @return final segment
	 * @throws IllegalArgumentException if this is the root path
	 */
	public Segment last() {
		if (segments.isEmpty()) throw new IllegalArgumentException("root path has no last segment");
		return segments.get(segments.size() - 1);
	}

	/**
	 * Returns a new path with {@code segment} appended.
	 *
	 * @param segment {@link String} key, non-negative {@link Integer} index, or {@link Segment}
	 * @return extended {@link ConfigPath}
	 */
	public ConfigPath appended(Object segment) {
		List<Segment> next = new ArrayList<>(segments.size() + 1);
		next.addAll(segments);
		next.add(toSegment(segment));
		return new ConfigPath(next);
	}

	/**
	 * Concatenates {@code other} onto the end of this path.
	 *
	 * @param other suffix path
	 * @return combined {@link ConfigPath}
	 */
	public ConfigPath concat(ConfigPath other) {
		Objects.requireNonNull(other, "other");
		List<Segment> next = new ArrayList<>(segments.size() + other.segments.size());
		next.addAll(segments);
		next.addAll(other.segments);
		return new ConfigPath(next);
	}

	/**
	 * Returns {@code true} if this path begins with all segments of {@code prefix}.
	 *
	 * @param prefix candidate prefix path
	 * @return {@code true} if {@code prefix} is a prefix of this path
	 */
	public boolean startsWith(ConfigPath prefix) {
		Objects.requireNonNull(prefix, "prefix");
		if (prefix.segments.size() > segments.size()) return false;
		return segments.subList(0, prefix.segments.size()).equals(prefix.segments);
	}

	@Override
	public String toString() {
		StringBuilder out = new StringBuilder("$");
		for (Segment segment : segments) {
			if (segment instanceof Segment.Index idx) out.append('[').append(idx.index()).append(']');
			else if (segment instanceof Segment.Key key) out.append('.').append(CanonicalWriter.formatKey(key.name()));
		}
		return out.toString();
	}

	private static Segment toSegment(Object segment) {
		Objects.requireNonNull(segment, "segment");
		if (segment instanceof Segment s) return s;
		if (segment instanceof String k) return new Segment.Key(k);
		if (segment instanceof Integer idx) return new Segment.Index(idx);
		throw new IllegalArgumentException("path segments must be String keys, non-negative Integer indices, or Segment: " + segment);
	}
}
