package pl.skidam.tomledit;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Surgical editor for {@code [table]} and {@code [[array-of-tables]]} sections in {@link Cst.Doc}:
 * section insertion/materialization, subtree removal and lossless renaming, {@code [[array-table]]}
 * element CRUD, and LCS reconciliation.
 */
final class CstSectionEditor {
	private CstSectionEditor() {}

	static void replaceSectionBody(Cst.Doc doc, Cst.Section section, ConfigPath sectionPath, TomlValue.Table newTbl) {
		byte[] nl = CstEntryEditor.detectSectionNewline(section, CstEntryEditor.detectDocNewline(doc));
		CstNavigator.SectionIndex index = CstNavigator.SectionIndex.of(doc);
		doc.removeSections(s -> {
			if (s == section) return false;
			ConfigPath sp = index.pathOf().get(s);
			return sp != null && sp.size() > sectionPath.size() && sp.startsWith(sectionPath);
		});
		section.items.clear();
		if (!newTbl.isEmpty() && !Cst.endsWithNewline(section.trailingTrivia)) {
			section.trailingTrivia.add(new Cst.Tok(Cst.TokKind.NL, nl));
		}
		int subInsert = doc.sections.indexOf(section) + 1;
		populateSectionMembers(doc, section, sectionPath, subInsert, newTbl, Comments.NONE, nl);
	}

	static void removeSubtree(Cst.Doc doc, ConfigPath path) {
		CstNavigator.SectionIndex index = CstNavigator.SectionIndex.of(doc);
		doc.removeSections(s -> {
			ConfigPath sp = index.pathOf().get(s);
			return sp != null && sp.startsWith(path);
		});
		removeDottedMatching(doc.rootItems, ConfigPath.root(), path);
		for (Cst.Section s : doc.sections) {
			ConfigPath sp = index.pathOf().get(s);
			if (sp != null && path.startsWith(sp)) {
				removeDottedMatching(s.items, sp, path);
			}
		}
	}

	/**
	 * Finds the section index immediately after {@code parentPath} (or its deepest ancestor section)
	 * and any existing sub-sections under it. Walking up ancestors prevents attaching sub-tables of
	 * dotted tables inside non-last {@code [[array-table]]} elements to the wrong element at EOF.
	 */
	static int findSectionInsertIndex(Cst.Doc doc, ConfigPath parentPath) {
		if (parentPath.isRoot()) return doc.sections.size();
		CstNavigator.SectionIndex index = CstNavigator.SectionIndex.of(doc);
		for (int len = parentPath.size(); len >= 1; len--) {
			ConfigPath ancestor = CstNavigator.prefixOf(parentPath, len);
			int lastIdx = -1;
			for (int i = 0; i < doc.sections.size(); i++) {
				ConfigPath sp = index.pathOf().get(doc.sections.get(i));
				if (sp != null && sp.startsWith(ancestor)) {
					lastIdx = i;
				}
			}
			if (lastIdx >= 0) return lastIdx + 1;
		}
		return doc.sections.size();
	}

	static int appendTableSection(Cst.Doc doc, int insertIdx, ConfigPath path, TomlValue.Table tbl, Comments comments, byte[] nl) {
		ensureEndsWithNewlineBefore(doc, insertIdx, nl);
		boolean hasDirect = false;
		boolean hasSubSection = false;
		for (TomlValue v : tbl.members().values()) {
			if (v instanceof TomlValue.Table || (v instanceof TomlValue.Array arr && Cst.isArrayOfTables(arr))) hasSubSection = true;
			else hasDirect = true;
		}
		String comment = comments.get(path).orElse(null);
		boolean emitHeader = hasDirect || comment != null || !hasSubSection;
		Cst.Section sec = null;
		int nextIdx = insertIdx;
		if (emitHeader) {
			sec = createAndInsertSection(doc, nextIdx, false, path, comment, nl);
			nextIdx++;
		}
		return populateSectionMembers(doc, sec, path, nextIdx, tbl, comments, nl);
	}

	static int appendArrayOfTablesSections(Cst.Doc doc, int insertIdx, ConfigPath path, TomlValue.Array arr, Comments comments, byte[] nl) {
		int nextIdx = insertIdx;
		for (int i = 0; i < arr.size(); i++) {
			TomlValue.Table elem = (TomlValue.Table) arr.get(i);
			String arrayComment = i == 0 ? comments.get(path).orElse(null) : null;
			String elemComment = comments.get(path.appended(i)).orElse(null);
			String headerComment = joinComments(arrayComment, elemComment);
			nextIdx = appendSingleArrayTableElement(doc, nextIdx, path, i, elem, headerComment, comments, nl);
		}
		return nextIdx;
	}

	private static String joinComments(String first, String second) {
		if (first == null) return second;
		if (second == null) return first;
		return first + "\n" + second;
	}

	static Cst.Section materializeSectionHeader(Cst.Doc doc, ConfigPath path, String comment, byte[] nl) {
		CstNavigator.SectionIndex index = CstNavigator.SectionIndex.of(doc);
		int insertIdx = doc.sections.size();
		for (int i = 0; i < doc.sections.size(); i++) {
			ConfigPath sp = index.pathOf().get(doc.sections.get(i));
			if (sp != null && sp.startsWith(path)) {
				insertIdx = i;
				break;
			}
		}
		ensureEndsWithNewlineBefore(doc, insertIdx, nl);
		return createAndInsertSection(doc, insertIdx, false, path, comment, nl);
	}

	// ------------------------------------------------------------------ [[array-of-tables]] CRUD & reconcile

	static void arrayOfTablesInsert(Cst.Doc doc, CstNavigator.ArrayOfTablesTarget aot, int index, TomlValue value) {
		int size = aot.sections().size();
		if (index < 0 || index > size) {
			throw new TomlEditException("array index " + index + " out of range (size " + size + ")", aot.path());
		}
		if (!(value instanceof TomlValue.Table tbl)) {
			TomlValue.Array existing = (TomlValue.Array) Cst.toTable(doc).get(aot.path());
			TomlValue.Array updated = TomlValue.array();
			for (int i = 0; i < index; i++) updated.add(existing.get(i));
			updated.add(value);
			for (int i = index; i < existing.size(); i++) updated.add(existing.get(i));
			CstEntryEditor.set(doc, aot.path(), updated);
			return;
		}
		byte[] nl = CstEntryEditor.detectSectionNewline(aot.sections().get(0), CstEntryEditor.detectDocNewline(doc));
		int insertIdx = index < size
				? doc.sections.indexOf(aot.sections().get(index))
				: findSectionInsertIndex(doc, aot.path().appended(size - 1));
		appendSingleArrayTableElement(doc, insertIdx, aot.path(), index, tbl, null, Comments.NONE, nl);
	}

	static void arrayOfTablesRemove(Cst.Doc doc, CstNavigator.ArrayOfTablesTarget aot, int index) {
		int size = aot.sections().size();
		if (index < 0 || index >= size) {
			throw new TomlEditException("array index " + index + " out of range (size " + size + ")", aot.path());
		}
		if (size == 1) {
			String key = CstEntryEditor.requireKeySegment(aot.path().last(), aot.path());
			Optional<String> comment = CstEntryEditor.formatLeadingComments(aot.sections().get(0).leadingComments);
			removeSubtree(doc, aot.path());
			DocumentEditor.ensureAncestors(doc, aot.path().parent());
			CstEntryEditor.insertMember(doc, aot.path().parent(), key, TomlValue.array(), comment.orElse(null), null);
			return;
		}
		removeSubtree(doc, aot.path().appended(index));
	}

	static void reconcileArrayOfTables(Cst.Doc doc, ConfigPath path, TomlValue.Array docArr, TomlValue.Array modelArr, ReconcilePolicy policy) {
		if (modelArr.isEmpty()) {
			if (policy == ReconcilePolicy.SYNC) CstEntryEditor.set(doc, path, modelArr);
			return;
		}
		if (!Cst.isArrayOfTables(modelArr)) {
			if (policy == ReconcilePolicy.SYNC) {
				CstEntryEditor.set(doc, path, modelArr);
			} else {
				TomlValue.Array merged = mergeInsertOnly(docArr.elements(), modelArr.elements());
				if (!merged.equals(docArr)) CstEntryEditor.set(doc, path, merged);
			}
			return;
		}

		List<TomlValue> docElems = docArr.elements();
		List<TomlValue> modelElems = modelArr.elements();
		List<int[]> matches = Lcs.matches(docElems, modelElems);
		if (matches == null) {
			if (policy == ReconcilePolicy.SYNC) {
				CstEntryEditor.set(doc, path, modelArr);
			} else {
				Set<TomlValue> existing = new HashSet<>(docElems);
				for (TomlValue elem : modelElems) {
					if (existing.add(elem)) {
						CstNavigator.ArrayOfTablesTarget aot = requireAot(doc, path);
						arrayOfTablesInsert(doc, aot, aot.sections().size(), elem);
					}
				}
			}
			return;
		}

		if (policy == ReconcilePolicy.INSERT_ONLY) {
			int inserted = 0;
			int prevModel = -1;
			for (int[] pair : matches) {
				int docPos = pair[0] + inserted;
				for (int j = prevModel + 1; j < pair[1]; j++) {
					arrayOfTablesInsert(doc, requireAot(doc, path), docPos++, modelElems.get(j));
					inserted++;
				}
				prevModel = pair[1];
			}
			for (int j = prevModel + 1; j < modelElems.size(); j++) {
				CstNavigator.ArrayOfTablesTarget aot = requireAot(doc, path);
				arrayOfTablesInsert(doc, aot, aot.sections().size(), modelElems.get(j));
			}
			return;
		}

		// SYNC: reconcile paired elements in place and insert/remove excess right-to-left
		List<int[]> anchors = new ArrayList<>(matches.size() + 2);
		anchors.add(new int[] {-1, -1});
		anchors.addAll(matches);
		anchors.add(new int[] {docElems.size(), modelElems.size()});

		for (int g = anchors.size() - 1; g >= 1; g--) {
			int dStart = anchors.get(g - 1)[0] + 1;
			int dEnd = anchors.get(g)[0];
			int mStart = anchors.get(g - 1)[1] + 1;
			int mEnd = anchors.get(g)[1];
			int dLen = dEnd - dStart;
			int mLen = mEnd - mStart;
			int paired = Math.min(dLen, mLen);

			for (int k = 0; k < paired; k++) {
				TomlValue.Table dt = (TomlValue.Table) docElems.get(dStart + k);
				TomlValue.Table mt = (TomlValue.Table) modelElems.get(mStart + k);
				ConfigPath elemPath = path.appended(dStart + k);
				if (canConvergeInPlace(dt, mt)) {
					DocumentEditor.reconcileTable(doc, elemPath, dt, mt, policy);
				} else {
					replaceSectionBody(doc, requireAot(doc, path).sections().get(dStart + k), elemPath, mt);
				}
			}
			for (int k = paired; k < mLen; k++) {
				arrayOfTablesInsert(doc, requireAot(doc, path), dStart + k, modelElems.get(mStart + k));
			}
			for (int i = dEnd - 1; i >= dStart + paired; i--) {
				arrayOfTablesRemove(doc, requireAot(doc, path), i);
			}
		}
	}

	private static CstNavigator.ArrayOfTablesTarget requireAot(Cst.Doc doc, ConfigPath path) {
		return (CstNavigator.ArrayOfTablesTarget) CstNavigator.requireTarget(doc, path);
	}

	/**
	 * Returns {@code true} when {@link DocumentEditor#reconcileTable} under {@link ReconcilePolicy#SYNC}
	 * will converge {@code docTbl} to be semantically equal to {@code modelTbl} (guaranteeing INV-2/INV-3).
	 */
	private static boolean canConvergeInPlace(TomlValue.Table docTbl, TomlValue.Table modelTbl) {
		if (!docTbl.members().keySet().equals(modelTbl.members().keySet())) return false;
		for (Map.Entry<String, TomlValue> e : docTbl.members().entrySet()) {
			TomlValue dv = e.getValue();
			TomlValue mv = modelTbl.get(e.getKey());
			if (dv instanceof TomlValue.Table dt && mv instanceof TomlValue.Table mt && !canConvergeInPlace(dt, mt)) {
				return false;
			}
		}
		return true;
	}

	// ------------------------------------------------------------------ lossless subtree rename

	/**
	 * Surgically renames a section, array-of-tables, or virtual-table subtree from {@code from} to
	 * {@code to}, preserving all inner entries, comments, vertical arrays, and sub-sections.
	 */
	static void renameSubtree(Cst.Doc doc, ConfigPath from, ConfigPath to) {
		byte[] nl = CstEntryEditor.detectDocNewline(doc);
		CstNavigator.SectionIndex index = CstNavigator.SectionIndex.of(doc);
		boolean sameParent = from.parent().equals(to.parent());

		// 1. Handle dotted entries in strict ancestors (entries inside `from`'s own section(s) travel with those sections)
		List<Cst.Entry> movedDotted = new ArrayList<>();
		List<ConfigPath> movedDottedPaths = new ArrayList<>();
		String toKey = CstEntryEditor.requireKeySegment(to.last(), to);
		processAncestorDottedEntries(doc.rootItems, ConfigPath.root(), from, toKey, sameParent, movedDotted, movedDottedPaths);
		for (Cst.Section sec : doc.sections) {
			ConfigPath sp = index.pathOf().get(sec);
			if (sp != null && sp.size() < from.size() && from.startsWith(sp)) {
				processAncestorDottedEntries(sec.items, sp, from, toKey, sameParent, movedDotted, movedDottedPaths);
			}
		}

		// 2. Rewrite header keys on all matching sections in document order
		List<Cst.Section> matchedSections = new ArrayList<>();
		for (Cst.Section sec : doc.sections) {
			ConfigPath sp = index.pathOf().get(sec);
			if (sp != null && sp.startsWith(from)) {
				ConfigPath suffix = new ConfigPath(sp.segments().subList(from.size(), sp.size()));
				CstEntryEditor.replaceKeyPath(sec.headerKey, CstEntryEditor.buildDottedKeyPath(to.concat(suffix)));
				matchedSections.add(sec);
			}
		}
		if (!matchedSections.isEmpty()) doc.invalidateSectionIndex();

		if (sameParent) return;

		doc.removeAllSections(matchedSections);

		if (!movedDotted.isEmpty()) {
			relocateDottedEntries(doc, from, to, movedDotted, movedDottedPaths, nl);
		}
		if (!matchedSections.isEmpty()) {
			int insertIdx = findSectionInsertIndex(doc, to.parent());
			ensureEndsWithNewlineBefore(doc, insertIdx, nl);
			addSectionSeparatorBlankLineBefore(doc, insertIdx, nl);
			for (Cst.Section sec : matchedSections) {
				doc.addSection(insertIdx++, sec);
			}
			if (insertIdx < doc.sections.size()) {
				Cst.Section lastMoved = matchedSections.get(matchedSections.size() - 1);
				ensureItemListEndsWithNewline(lastMoved.items, lastMoved.trailingTrivia, nl);
				if (lastMoved.items.isEmpty() || !(lastMoved.items.get(lastMoved.items.size() - 1) instanceof Cst.TriviaLine tl && !tl.hasComment())) {
					lastMoved.items.add(new Cst.TriviaLine(List.of(new Cst.Tok(Cst.TokKind.NL, nl))));
				}
			}
		}
	}

	private static void processAncestorDottedEntries(List<Cst.Item> items, ConfigPath basePath, ConfigPath from,
			String toKey, boolean sameParent, List<Cst.Entry> movedDotted, List<ConfigPath> movedDottedPaths) {
		if (sameParent) {
			rewriteDottedPrefixInPlace(items, basePath, from, toKey);
		} else {
			extractDottedMatching(items, basePath, from, movedDotted, movedDottedPaths);
		}
	}

	// ------------------------------------------------------------------ internals

	private static Cst.Section createAndInsertSection(Cst.Doc doc, int insertIdx, boolean arrayTable,
			ConfigPath path, String comment, byte[] nl) {
		addSectionSeparatorBlankLineBefore(doc, insertIdx, nl);
		List<Cst.TriviaLine> leadingComments = comment != null
				? CstEntryEditor.buildCommentLines(CstEntryEditor.normalizeCommentInput(comment), new byte[0], nl) : List.of();
		Cst.KeyPath headerKey = CstEntryEditor.buildDottedKeyPath(path);
		byte[] openBytes = arrayTable ? new byte[] {'[', '['} : new byte[] {'['};
		byte[] closeBytes = arrayTable ? new byte[] {']', ']'} : new byte[] {']'};
		Cst.Section sec = new Cst.Section(arrayTable, leadingComments, List.of(),
				new Cst.Tok(Cst.TokKind.PUNCT, openBytes),
				List.of(), headerKey, List.of(),
				new Cst.Tok(Cst.TokKind.PUNCT, closeBytes),
				List.of(new Cst.Tok(Cst.TokKind.NL, nl)));
		if (insertIdx < doc.sections.size()) {
			sec.items.add(new Cst.TriviaLine(List.of(new Cst.Tok(Cst.TokKind.NL, nl))));
		}
		doc.addSection(insertIdx, sec);
		return sec;
	}

	private static int populateSectionMembers(Cst.Doc doc, Cst.Section sec, ConfigPath sectionPath,
			int nextIdx, TomlValue.Table tbl, Comments comments, byte[] nl) {
		for (Map.Entry<String, TomlValue> e : tbl.members().entrySet()) {
			ConfigPath childPath = sectionPath.appended(e.getKey());
			TomlValue v = e.getValue();
			if (v instanceof TomlValue.Table sub) {
				nextIdx = appendTableSection(doc, nextIdx, childPath, sub, comments, nl);
			} else if (v instanceof TomlValue.Array arr && Cst.isArrayOfTables(arr)) {
				nextIdx = appendArrayOfTablesSections(doc, nextIdx, childPath, arr, comments, nl);
			} else if (sec != null) {
				String comment = comments.get(childPath).orElse(null);
				CstEntryEditor.insertEntryIntoItemList(sec.items, e.getKey(), v, comment, null, nl);
			}
		}
		return nextIdx;
	}

	private static int appendSingleArrayTableElement(Cst.Doc doc, int insertIdx, ConfigPath path, int elemIndex,
			TomlValue.Table elem, String comment, Comments comments, byte[] nl) {
		ensureEndsWithNewlineBefore(doc, insertIdx, nl);
		Cst.Section sec = createAndInsertSection(doc, insertIdx, true, path, comment, nl);
		return populateSectionMembers(doc, sec, path.appended(elemIndex), insertIdx + 1, elem, comments, nl);
	}

	private static TomlValue.Array mergeInsertOnly(List<TomlValue> docElems, List<TomlValue> modelElems) {
		List<int[]> matches = Lcs.matches(docElems, modelElems);
		TomlValue.Array merged = TomlValue.array();
		if (matches == null) {
			Set<TomlValue> seen = new HashSet<>(docElems);
			for (TomlValue e : docElems) merged.add(e);
			for (TomlValue e : modelElems) {
				if (seen.add(e)) merged.add(e);
			}
			return merged;
		}
		int dIdx = 0;
		int mIdx = 0;
		for (int[] pair : matches) {
			while (dIdx < pair[0]) merged.add(docElems.get(dIdx++));
			while (mIdx < pair[1]) merged.add(modelElems.get(mIdx++));
			merged.add(docElems.get(dIdx++));
			mIdx++;
		}
		while (dIdx < docElems.size()) merged.add(docElems.get(dIdx++));
		while (mIdx < modelElems.size()) merged.add(modelElems.get(mIdx++));
		return merged;
	}

	private static void relocateDottedEntries(Cst.Doc doc, ConfigPath from, ConfigPath to,
			List<Cst.Entry> movedDotted, List<ConfigPath> movedDottedPaths, byte[] nl) {
		CstNavigator.Target destParent = CstNavigator.resolve(doc, to.parent());
		if (destParent == null) {
			DocumentEditor.ensureAncestors(doc, to.parent());
			destParent = CstNavigator.requireTarget(doc, to.parent());
		}
		List<Cst.Item> destItems;
		ConfigPath destBase;
		if (destParent instanceof CstNavigator.RootTarget) {
			destItems = doc.rootItems;
			destBase = ConfigPath.root();
		} else if (destParent instanceof CstNavigator.SectionTarget st) {
			if (!Cst.endsWithNewline(st.section().trailingTrivia)) {
				st.section().trailingTrivia.add(new Cst.Tok(Cst.TokKind.NL, nl));
			}
			destItems = st.section().items;
			destBase = st.sectionPath();
		} else if (destParent instanceof CstNavigator.VirtualTableTarget vt && vt.dottedOwnerItems() != null) {
			destItems = vt.dottedOwnerItems();
			destBase = vt.dottedOwnerBase();
		} else if (destParent instanceof CstNavigator.VirtualTableTarget) {
			// Implicit super-table of [section] headers: materialize [to.parent()] so entries stay in scope
			Cst.Section sec = materializeSectionHeader(doc, to.parent(), null, nl);
			destItems = sec.items;
			destBase = to.parent();
		} else {
			throw new TomlEditException("destination ancestor is not a table: " + to.parent(), to.parent());
		}
		for (int i = 0; i < movedDotted.size(); i++) {
			Cst.Entry e = movedDotted.get(i);
			ConfigPath oldFull = movedDottedPaths.get(i);
			ConfigPath suffix = new ConfigPath(oldFull.segments().subList(from.size(), oldFull.size()));
			ConfigPath newFull = to.concat(suffix);
			ConfigPath rel = new ConfigPath(newFull.segments().subList(destBase.size(), newFull.size()));
			CstEntryEditor.replaceKeyPath(e.key, CstEntryEditor.buildDottedKeyPath(rel));
			CstEntryEditor.insertExistingEntryIntoItemList(destItems, e, nl);
		}
	}

	private static void rewriteDottedPrefixInPlace(List<Cst.Item> items, ConfigPath basePath, ConfigPath from, String newKey) {
		int segIdx = from.size() - basePath.size() - 1;
		if (segIdx < 0) return;
		for (Cst.Item item : items) {
			if (!(item instanceof Cst.Entry entry)) continue;
			ConfigPath full = CstNavigator.appendKeys(basePath, entry.key.keys);
			if (full.size() > from.size() && full.startsWith(from)) {
				CstEntryEditor.replaceKeySegmentAt(entry.key, segIdx, newKey);
			}
		}
	}

	private static void extractDottedMatching(List<Cst.Item> items, ConfigPath basePath, ConfigPath from,
			List<Cst.Entry> outEntries, List<ConfigPath> outPaths) {
		var it = items.iterator();
		while (it.hasNext()) {
			Cst.Item item = it.next();
			if (item instanceof Cst.Entry entry) {
				ConfigPath full = CstNavigator.appendKeys(basePath, entry.key.keys);
				if (full.startsWith(from)) {
					outEntries.add(entry);
					outPaths.add(full);
					it.remove();
				}
			}
		}
	}

	private static void removeDottedMatching(List<Cst.Item> items, ConfigPath basePath, ConfigPath target) {
		items.removeIf(item -> item instanceof Cst.Entry e && CstNavigator.appendKeys(basePath, e.key.keys).startsWith(target));
	}

	private static void ensureEndsWithNewlineBefore(Cst.Doc doc, int sectionInsertIdx, byte[] nl) {
		if (sectionInsertIdx == 0) {
			ensureItemListEndsWithNewline(doc.rootItems, null, nl);
		} else {
			Cst.Section prev = doc.sections.get(sectionInsertIdx - 1);
			ensureItemListEndsWithNewline(prev.items, prev.trailingTrivia, nl);
		}
	}

	private static void ensureItemListEndsWithNewline(List<Cst.Item> items, List<Cst.Tok> fallbackTrailing, byte[] nl) {
		if (!items.isEmpty()) {
			Cst.Item last = items.get(items.size() - 1);
			if (last instanceof Cst.Entry e && !Cst.endsWithNewline(e.trailingTrivia)) {
				e.trailingTrivia.add(new Cst.Tok(Cst.TokKind.NL, nl));
			} else if (last instanceof Cst.TriviaLine tl && !Cst.endsWithNewline(tl.tokens)) {
				tl.tokens.add(new Cst.Tok(Cst.TokKind.NL, nl));
			}
		} else if (fallbackTrailing != null && !Cst.endsWithNewline(fallbackTrailing)) {
			fallbackTrailing.add(new Cst.Tok(Cst.TokKind.NL, nl));
		}
	}

	private static void addSectionSeparatorBlankLineBefore(Cst.Doc doc, int sectionInsertIdx, byte[] nl) {
		if (sectionInsertIdx == 0) {
			if (doc.rootItems.isEmpty()) return;
			Cst.Item last = doc.rootItems.get(doc.rootItems.size() - 1);
			if (last instanceof Cst.TriviaLine tl && !tl.hasComment()) return;
			doc.rootItems.add(new Cst.TriviaLine(List.of(new Cst.Tok(Cst.TokKind.NL, nl))));
		} else {
			List<Cst.Item> prevItems = doc.sections.get(sectionInsertIdx - 1).items;
			if (!prevItems.isEmpty() && prevItems.get(prevItems.size() - 1) instanceof Cst.TriviaLine tl && !tl.hasComment()) {
				return;
			}
			prevItems.add(new Cst.TriviaLine(List.of(new Cst.Tok(Cst.TokKind.NL, nl))));
		}
	}
}
