package pl.skidam.tomledit;

/**
 * Controls how reconciliation converges a document toward a model.
 *
 * <p>{@link Document#reconcile} uses it for arrays; {@link TomlSchema#apply} additionally uses it
 * for entries of model-defined dynamic table sections.
 */
public enum ReconcilePolicy {
	/**
	 * Full convergence: arrays insert missing model elements and remove elements absent from the
	 * model while preserving kept elements' layout and comments; dynamic table entries absent from
	 * the model are removed.
	 */
	SYNC,
	/**
	 * Additive convergence: arrays insert missing model elements and leave extra document elements
	 * untouched; dynamic table entries absent from the model are preserved and still receive their
	 * schema defaults.
	 */
	INSERT_ONLY
}
