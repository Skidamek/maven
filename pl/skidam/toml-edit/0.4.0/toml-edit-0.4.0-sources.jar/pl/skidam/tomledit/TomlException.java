package pl.skidam.tomledit;

/**
 * Base class for path-aware failures raised while editing or validating TOML values.
 *
 * <p>{@link TomlEditException} reports invalid arguments or edit operations;
 * {@link TomlValidationException} reports typed-reading failures. Both expose the offending
 * {@link ConfigPath} through {@link #path()}.
 */
public abstract sealed class TomlException extends RuntimeException permits TomlEditException, TomlValidationException {
	private static final long serialVersionUID = 1L;
	private final transient ConfigPath path;

	/**
	 * Creates a path-aware TOML exception.
	 *
	 * @param message detail message
	 * @param path offending config path, or {@code null}
	 * @param cause underlying cause, or {@code null}
	 */
	protected TomlException(String message, ConfigPath path, Throwable cause) {
		super(message, cause);
		this.path = path;
	}

	/**
	 * Returns the offending path, or {@code null} when the failure is not path-specific.
	 *
	 * @return offending {@link ConfigPath}, or {@code null}
	 */
	public ConfigPath path() {
		return path;
	}
}
