package pl.skidam.tomledit;

/**
 * Thrown on invalid API arguments or paths during document editing or canonical serialization.
 * Extends {@link TomlException} so callers can catch editing and validation failures together.
 */
public final class TomlEditException extends TomlException {
	private static final long serialVersionUID = 1L;

	/**
	 * Creates an exception without an associated path.
	 *
	 * @param message detail message
	 */
	public TomlEditException(String message) {
		super(message, null, null);
	}

	/**
	 * Creates an exception associated with {@code path}.
	 *
	 * @param message detail message
	 * @param path offending config path, or {@code null}
	 */
	public TomlEditException(String message, ConfigPath path) {
		super(message, path, null);
	}

	/**
	 * Creates an exception with an associated path and underlying cause.
	 *
	 * @param message detail message
	 * @param path offending config path, or {@code null}
	 * @param cause underlying cause, or {@code null}
	 */
	public TomlEditException(String message, ConfigPath path, Throwable cause) {
		super(message, path, cause);
	}
}
