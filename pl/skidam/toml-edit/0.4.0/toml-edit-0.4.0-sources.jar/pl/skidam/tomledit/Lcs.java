package pl.skidam.tomledit;

import java.util.ArrayList;
import java.util.List;

/**
 * Longest common subsequence over semantic equality for array reconciliation.
 *
 * <p>Trims common prefixes and suffixes in O(N) before allocating the DP matrix, and returns
 * {@code null} when the remaining middle matrix would exceed {@link #MAX_CELLS} so callers can take
 * an explicit, idempotent fallback instead of confusing budget overflow with zero matches.
 */
final class Lcs {
	static final long MAX_CELLS = 1_000_000L;

	private Lcs() {}

	/** Returns matched index pairs {@code (docIdx, modelIdx)} in increasing order, or {@code null} if over budget. */
	static List<int[]> matches(List<TomlValue> doc, List<TomlValue> model) {
		int n = doc.size();
		int m = model.size();

		int prefix = 0;
		int minLen = Math.min(n, m);
		while (prefix < minLen && doc.get(prefix).equals(model.get(prefix))) {
			prefix++;
		}

		int suffix = 0;
		while (prefix + suffix < minLen && doc.get(n - 1 - suffix).equals(model.get(m - 1 - suffix))) {
			suffix++;
		}

		int midN = n - prefix - suffix;
		int midM = m - prefix - suffix;
		if ((long) (midN + 1) * (midM + 1) > MAX_CELLS) {
			return null;
		}

		List<int[]> out = new ArrayList<>(prefix + suffix + Math.min(midN, midM));
		for (int k = 0; k < prefix; k++) {
			out.add(new int[] {k, k});
		}

		if (midN > 0 && midM > 0) {
			int[][] dp = new int[midN + 1][midM + 1];
			for (int i = midN - 1; i >= 0; i--) {
				TomlValue docVal = doc.get(prefix + i);
				for (int j = midM - 1; j >= 0; j--) {
					if (docVal.equals(model.get(prefix + j))) {
						dp[i][j] = dp[i + 1][j + 1] + 1;
					} else {
						dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
					}
				}
			}
			int i = 0;
			int j = 0;
			while (i < midN && j < midM) {
				if (doc.get(prefix + i).equals(model.get(prefix + j))) {
					out.add(new int[] {prefix + i, prefix + j});
					i++;
					j++;
				} else if (dp[i + 1][j] >= dp[i][j + 1]) {
					i++;
				} else {
					j++;
				}
			}
		}

		int docTail = n - suffix;
		int modelTail = m - suffix;
		for (int k = 0; k < suffix; k++) {
			out.add(new int[] {docTail + k, modelTail + k});
		}
		return out;
	}
}
