package pl.skidam.tomledit;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Declarative schema of default values and comments for fresh canonical generation and lossless
 * convergence of existing {@link Document}s.
 *
 * <p>A {@code TomlSchema} can describe a full document (with an optional top-of-file banner) or a
 * reusable sub-table (for example, a dynamic section repeated under multiple paths) using the
 * {@code prefix} overloads {@link #ensureDefaults(Document, ConfigPath)} and
 * {@link #addCommentsTo(Comments.Builder, ConfigPath)}.
 */
public final class TomlSchema {
	private final String banner;
	private final Map<ConfigPath, FieldSpec> fields;
	private final Map<ConfigPath, String> sectionComments;

	private TomlSchema(String banner, Map<ConfigPath, FieldSpec> fields, Map<ConfigPath, String> sectionComments) {
		this.banner = banner;
		this.fields = Collections.unmodifiableMap(fields);
		this.sectionComments = Collections.unmodifiableMap(sectionComments);
	}

	/**
	 * Creates a new fluent {@link Builder}.
	 *
	 * @return new schema builder
	 */
	public static Builder builder() {
		return new Builder();
	}

	/**
	 * Returns a fresh {@link TomlValue.Table} populated with all declared default values in
	 * declaration order. Mutating the returned table does not affect this schema.
	 *
	 * @return default semantic table
	 */
	public TomlValue.Table defaultTree() {
		TomlValue.Table root = TomlValue.table();
		for (FieldSpec spec : fields.values()) {
			putNested(root, spec.path, deepCopy(spec.defaultValue));
		}
		return root;
	}

	/**
	 * Builds a {@link Comments} specification containing this schema's banner, section comments,
	 * and field comments.
	 *
	 * @return immutable {@link Comments}
	 */
	public Comments comments() {
		Comments.Builder builder = Comments.builder();
		if (banner != null) builder.banner(banner);
		addCommentsTo(builder, ConfigPath.root());
		return builder.build();
	}

	/**
	 * Appends all section and field comments declared in this schema to {@code builder}, prefixed
	 * with {@code prefix}. Useful for documenting dynamic sub-tables without reflection.
	 *
	 * @param builder destination comments builder
	 * @param prefix path prefix (use {@link ConfigPath#root()} for top-level)
	 */
	public void addCommentsTo(Comments.Builder builder, ConfigPath prefix) {
		Objects.requireNonNull(builder, "builder");
		Objects.requireNonNull(prefix, "prefix");
		for (var entry : sectionComments.entrySet()) {
			builder.put(prefix.concat(entry.getKey()), entry.getValue());
		}
		for (FieldSpec spec : fields.values()) {
			if (spec.comment != null) {
				builder.put(prefix.concat(spec.path), spec.comment);
			}
		}
	}

	/**
	 * Generates canonical TOML bytes for {@link #defaultTree()} with {@link #comments()}.
	 *
	 * @return UTF-8 canonical TOML bytes
	 */
	public byte[] canonical() {
		return TomlEdit.canonical(defaultTree(), comments());
	}

	/**
	 * Generates canonical TOML bytes for {@code model} with {@link #comments()}.
	 *
	 * @param model root table to serialize
	 * @return UTF-8 canonical TOML bytes
	 */
	public byte[] canonical(TomlValue.Table model) {
		Objects.requireNonNull(model, "model");
		return TomlEdit.canonical(model, comments());
	}

	/**
	 * Materializes every declared field that is absent from {@code doc} with its default value and
	 * optional comment. Existing fields and their comments are left untouched.
	 *
	 * @param doc target document
	 */
	public void ensureDefaults(Document doc) {
		ensureDefaults(doc, ConfigPath.root());
	}

	/**
	 * Atomically materializes every declared field that is absent under {@code prefix} in {@code doc}
	 * with its default value and optional comment. Existing fields and their comments are left untouched.
	 *
	 * @param doc target document
	 * @param prefix path prefix for this schema
	 */
	public void ensureDefaults(Document doc, ConfigPath prefix) {
		Objects.requireNonNull(doc, "doc");
		Objects.requireNonNull(prefix, "prefix");
		doc.atomicEdit(() -> ensureDefaultsUnchecked(doc.cst(), prefix));
	}

	/**
	 * Atomically reconciles {@code doc} against {@code model} with {@code policy}, then materializes
	 * any missing declared defaults.
	 *
	 * @param doc target document
	 * @param model updated semantic model
	 * @param policy array reconciliation strategy
	 */
	public void apply(Document doc, TomlValue.Table model, ReconcilePolicy policy) {
		Objects.requireNonNull(doc, "doc");
		Objects.requireNonNull(model, "model");
		Objects.requireNonNull(policy, "policy");
		doc.atomicEdit(() -> {
			DocumentEditor.reconcile(doc.cst(), model, policy);
			ensureDefaultsUnchecked(doc.cst(), ConfigPath.root());
		});
	}

	private void ensureDefaultsUnchecked(Cst.Doc cst, ConfigPath prefix) {
		for (FieldSpec spec : fields.values()) {
			DocumentEditor.ensure(cst, prefix.concat(spec.path), deepCopy(spec.defaultValue), spec.comment);
		}
	}

	private static void putNested(TomlValue.Table root, ConfigPath path, TomlValue value) {
		TomlValue.Table cur = root;
		var segs = path.segments();
		for (int i = 0; i < segs.size() - 1; i++) {
			String key = ((ConfigPath.Segment.Key) segs.get(i)).name();
			TomlValue existing = cur.get(key);
			if (existing instanceof TomlValue.Table sub) {
				cur = sub;
			} else {
				TomlValue.Table sub = TomlValue.table();
				cur.put(key, sub);
				cur = sub;
			}
		}
		cur.put(((ConfigPath.Segment.Key) segs.get(segs.size() - 1)).name(), value);
	}

	private static TomlValue deepCopy(TomlValue value) {
		if (value instanceof TomlValue.Table t) {
			TomlValue.Table copy = TomlValue.table();
			for (var e : t.members().entrySet()) {
				copy.put(e.getKey(), deepCopy(e.getValue()));
			}
			return copy;
		}
		if (value instanceof TomlValue.Array a) {
			TomlValue.Array copy = TomlValue.array();
			for (TomlValue elem : a.elements()) {
				copy.add(deepCopy(elem));
			}
			return copy;
		}
		return value;
	}

	private static void requireKeyOnlyPath(ConfigPath path) {
		Objects.requireNonNull(path, "path");
		if (path.isRoot()) throw new IllegalArgumentException("schema path must not be root");
		for (ConfigPath.Segment seg : path.segments()) {
			if (!(seg instanceof ConfigPath.Segment.Key)) {
				throw new IllegalArgumentException("schema path must contain only key segments: " + path);
			}
		}
	}

	private record FieldSpec(ConfigPath path, TomlValue defaultValue, String comment) {}

	/** Fluent builder for {@link TomlSchema}. */
	public static final class Builder {
		private String banner;
		private final LinkedHashMap<ConfigPath, FieldSpec> fields = new LinkedHashMap<>();
		private final LinkedHashMap<ConfigPath, String> sectionComments = new LinkedHashMap<>();

		/** Creates an empty schema builder. */
		public Builder() {}

		/**
		 * Sets the top-of-file banner comment.
		 *
		 * @param banner banner text, or {@code null} for none
		 * @return this builder
		 */
		public Builder banner(String banner) {
			this.banner = banner;
			return this;
		}

		/**
		 * Declares a field with a default value and no comment.
		 *
		 * @param path key-only path to the field
		 * @param defaultValue default TOML value
		 * @return this builder
		 */
		public Builder field(ConfigPath path, TomlValue defaultValue) {
			return field(path, defaultValue, null);
		}

		/**
		 * Declares a field with a default value and an optional attached comment.
		 *
		 * @param path key-only path to the field
		 * @param defaultValue default TOML value
		 * @param comment optional attached comment text, or {@code null}
		 * @return this builder
		 */
		public Builder field(ConfigPath path, TomlValue defaultValue, String comment) {
			requireKeyOnlyPath(path);
			Objects.requireNonNull(defaultValue, "defaultValue");
			fields.put(path, new FieldSpec(path, deepCopy(defaultValue), comment));
			return this;
		}

		/**
		 * Declares a comment for a section header or table path without attaching a default value.
		 *
		 * @param path key-only path to the table/section
		 * @param comment comment text
		 * @return this builder
		 */
		public Builder comment(ConfigPath path, String comment) {
			requireKeyOnlyPath(path);
			Objects.requireNonNull(comment, "comment");
			sectionComments.put(path, comment);
			return this;
		}

		/**
		 * Builds an immutable {@link TomlSchema}.
		 *
		 * @return built {@link TomlSchema}
		 */
		public TomlSchema build() {
			return new TomlSchema(banner, new LinkedHashMap<>(fields), new LinkedHashMap<>(sectionComments));
		}
	}
}
