package pl.skidam.tomledit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Declarative schema of defaults and comments for fresh canonical generation and lossless
 * convergence of existing {@link Document}s.
 *
 * <p>A schema is an immutable tree of keyed nodes. Each node can carry a default value, a comment
 * used both for canonical output and when the value or section is materialized, and a dynamic
 * map-of-tables entry schema ({@link Builder#dynamicTable(ConfigPath, TomlSchema)}).
 *
 * <p>A {@code TomlSchema} can describe a full document (with an optional top-of-file banner) or a
 * reusable sub-table, such as a single dynamic section entry. The {@code prefix} overloads
 * {@link #ensureDefaults(Document, ConfigPath)} and {@link #addCommentsTo(Comments.Builder, ConfigPath)}
 * apply a sub-schema manually at a known path. A root-path comment on a sub-schema is emitted above
 * the section header where that schema is attached, so dynamic entry headers and materialized
 * sub-schema headers can be documented.
 *
 * <p>This type declares defaults, comments, and dynamic shape; it is not a validator. Use
 * {@link TableReader} for typed reads, required-key checks, and unknown-key reporting.
 *
 * <p>Banners are part of canonical generation only and are never prepended to an existing document.
 * During {@link #ensureDefaults(Document)} and {@link #apply(Document, TomlValue.Table, ReconcilePolicy)},
 * declared field and section comments are attached whenever the corresponding value or section is
 * newly materialized; existing nodes and their comments are never replaced or retrofitted.
 */
public final class TomlSchema {
	private final String banner;
	private final Node root;

	private TomlSchema(String banner, Node root) {
		this.banner = banner;
		this.root = root;
	}

	/**
	 * Creates a new fluent {@link Builder}.
	 *
	 * @return new schema builder
	 */
	public static Builder builder() {
		return new Builder();
	}

	/**
	 * Returns a fresh {@link TomlValue.Table} populated with all declared default values in
	 * declaration order. Mutating the returned table does not affect this schema.
	 *
	 * @return default semantic table
	 */
	public TomlValue.Table defaultTree() {
		TomlValue.Table rootTable = TomlValue.table();
		addDefaults(root, rootTable);
		return rootTable;
	}

	/**
	 * Builds a {@link Comments} specification containing this schema's banner, section comments,
	 * and field comments.
	 *
	 * @return immutable {@link Comments}
	 */
	public Comments comments() {
		Comments.Builder builder = Comments.builder();
		if (banner != null) builder.banner(banner);
		addCommentsTo(builder, ConfigPath.root());
		return builder.build();
	}

	/**
	 * Appends all comments declared in this schema to {@code builder}, prefixed with {@code prefix}.
	 * A root-path comment is appended only when {@code prefix} is not the document root, which is
	 * what makes it usable as a dynamic entry header comment.
	 *
	 * @param builder destination comments builder
	 * @param prefix path prefix (use {@link ConfigPath#root()} for top-level)
	 */
	public void addCommentsTo(Comments.Builder builder, ConfigPath prefix) {
		Objects.requireNonNull(builder, "builder");
		Objects.requireNonNull(prefix, "prefix");
		addDeclaredComments(root, builder, prefix);
	}

	/**
	 * Generates canonical TOML bytes for {@link #defaultTree()} with this schema's comments.
	 *
	 * @return UTF-8 canonical TOML bytes
	 */
	public byte[] canonical() {
		TomlValue.Table model = defaultTree();
		return TomlEdit.canonical(model, commentsFor(model));
	}

	/**
	 * Generates canonical TOML bytes for {@code model} with this schema's comments, including
	 * entry comments declared by {@link Builder#dynamicTable(ConfigPath, TomlSchema)}.
	 *
	 * @param model root table to serialize
	 * @return UTF-8 canonical TOML bytes
	 */
	public byte[] canonical(TomlValue.Table model) {
		Objects.requireNonNull(model, "model");
		return TomlEdit.canonical(model, commentsFor(model));
	}

	/**
	 * Generates canonical TOML text for {@link #defaultTree()} with this schema's comments.
	 *
	 * @return canonical TOML text
	 */
	public String canonicalString() {
		TomlValue.Table model = defaultTree();
		return TomlEdit.canonicalString(model, commentsFor(model));
	}

	/**
	 * Generates canonical TOML text for {@code model} with this schema's comments, including
	 * entry comments declared by {@link Builder#dynamicTable(ConfigPath, TomlSchema)}.
	 *
	 * @param model root table to serialize
	 * @return canonical TOML text
	 */
	public String canonicalString(TomlValue.Table model) {
		Objects.requireNonNull(model, "model");
		return TomlEdit.canonicalString(model, commentsFor(model));
	}

	/**
	 * Materializes every declared field that is absent from {@code doc} with its default value and
	 * declared field/section comments. Existing fields, sections, and their comments are left
	 * untouched. Dynamic sections are only materialized by
	 * {@link #apply(Document, TomlValue.Table, ReconcilePolicy)} because they need a model to define
	 * their entries.
	 *
	 * @param doc target document
	 */
	public void ensureDefaults(Document doc) {
		ensureDefaults(doc, ConfigPath.root());
	}

	/**
	 * Atomically materializes every declared field that is absent under {@code prefix} in {@code doc}
	 * with its default value and declared field/section comments. Existing fields, sections, and
	 * their comments are left untouched. Dynamic sections are not materialized by this method.
	 *
	 * @param doc target document
	 * @param prefix path prefix for this schema
	 */
	public void ensureDefaults(Document doc, ConfigPath prefix) {
		Objects.requireNonNull(doc, "doc");
		Objects.requireNonNull(prefix, "prefix");
		doc.atomicEdit(() -> {
			TomlValue currentVal = Cst.toTable(doc.cst()).get(prefix);
			if (currentVal != null && !(currentVal instanceof TomlValue.Table)) {
				throw new TomlEditException("ancestor is not a table: " + prefix, prefix);
			}
			TomlValue.Table currentSub = currentVal instanceof TomlValue.Table table ? table : null;
			ConvergencePlan plan = plan(currentSub, prefix, null, ReconcilePolicy.INSERT_ONLY);
			DocumentEditor.materialize(doc.cst(), prefix, plan.additions(), plan.comments());
		});
	}

	/**
	 * Atomically converges {@code doc} toward {@code model} and this schema:
	 * <ul>
	 *   <li>existing values and arrays are reconciled with {@code DocumentEditor.reconcile};</li>
	 *   <li>missing declared fields take the model value when present, otherwise the schema default,
	 *       with declared field and section comments on newly materialized nodes;</li>
	 *   <li>a dynamic section is managed only when {@code model} contains its path. Entries absent
	 *       from the model are removed under {@link ReconcilePolicy#SYNC} and preserved under
	 *       {@link ReconcilePolicy#INSERT_ONLY}; entries present in the model receive missing model
	 *       members and entry-schema defaults.</li>
	 * </ul>
	 *
	 * <p>Keys present only in {@code model} are not inserted outside dynamic sections; declare them
	 * as schema fields or materialize them explicitly with {@link Document#ensure}. Extra document
	 * keys are never removed, except stale dynamic entries under {@link ReconcilePolicy#SYNC}.
	 *
	 * @param doc target document
	 * @param model updated semantic model
	 * @param policy reconciliation strategy
	 * @throws TomlEditException if {@code model} contains a cycle, exceeds the maximum TOML nesting
	 *                           depth, or conflicts with the document structure
	 */
	public void apply(Document doc, TomlValue.Table model, ReconcilePolicy policy) {
		Objects.requireNonNull(doc, "doc");
		Objects.requireNonNull(model, "model");
		Objects.requireNonNull(policy, "policy");
		TomlTrees.validateForEdit(model, 0);
		doc.atomicEdit(() -> {
			TomlValue.Table before = Cst.toTable(doc.cst());
			ConvergencePlan plan = plan(before, ConfigPath.root(), model, policy);
			for (ConfigPath removal : plan.removals()) {
				DocumentEditor.remove(doc.cst(), removal);
			}
			TomlValue.Table reconcileBase = plan.removals().isEmpty() ? before : Cst.toTable(doc.cst());
			DocumentEditor.reconcile(doc.cst(), reconcileBase, model, policy);
			DocumentEditor.materialize(doc.cst(), ConfigPath.root(), plan.additions(), plan.comments());
		});
	}

	// ------------------------------------------------------------------ pure convergence planner

	private record ConvergencePlan(List<ConfigPath> removals, TomlValue.Table additions, Comments comments) {}

	private ConvergencePlan plan(TomlValue.Table currentDoc, ConfigPath prefix, TomlValue.Table model, ReconcilePolicy policy) {
		List<ConfigPath> removals = new ArrayList<>();
		TomlValue.Table additions = TomlValue.table();
		Comments.Builder comments = Comments.builder();
		planNode(root, currentDoc, model, prefix, policy, additions, comments, removals);
		if (currentDoc == null && !prefix.isRoot() && root.comment() != null && !additions.isEmpty()) {
			comments.put(prefix, root.comment());
		}
		return new ConvergencePlan(removals, additions, comments.build());
	}

	private void planNode(Node node, TomlValue.Table currentDoc, TomlValue.Table model, ConfigPath abs,
			ReconcilePolicy policy, TomlValue.Table additions, Comments.Builder comments, List<ConfigPath> removals) {
		for (Map.Entry<String, Node> entry : node.children().entrySet()) {
			String key = entry.getKey();
			Node child = entry.getValue();
			ConfigPath childAbs = abs.appended(key);
			TomlValue docVal = currentDoc == null ? null : currentDoc.get(key);
			TomlValue modelVal = model == null ? null : model.get(key);

			if (child.dynamic()) {
				if (modelVal != null) {
					planDynamic(child, key, docVal, modelVal, childAbs, policy, additions, comments, removals);
				}
				continue;
			}

			if (child.defaultValue() != null) {
				if (docVal == null) {
					TomlValue source = modelVal != null ? modelVal : child.defaultValue();
					TomlValue base;
					if (child.comment() != null) comments.put(childAbs, child.comment());
					if (child.hasChildren() && source instanceof TomlValue.Table sourceTbl) {
						TomlValue.Table baseTbl = TomlValue.table();
						planDynamicEntryModelMembers(child, null, sourceTbl, childAbs, baseTbl, comments);
						TomlValue.Table refined = TomlValue.table();
						planNode(child, baseTbl, modelVal instanceof TomlValue.Table mt ? mt : null,
								childAbs, policy, refined, comments, removals);
						mergeInto(baseTbl, refined);
						base = baseTbl;
					} else {
						base = TomlTrees.deepCopy(source);
					}
					additions.put(key, base);
				} else if (child.hasChildren()) {
					planChildrenIntoExisting(child, key, docVal, modelVal, childAbs, policy, additions, comments, removals);
				}
				continue;
			}

			if (child.hasChildren()) {
				if (docVal == null) {
					TomlValue.Table childAdditions = TomlValue.table();
					planNode(child, null, modelVal instanceof TomlValue.Table mt ? mt : null,
							childAbs, policy, childAdditions, comments, removals);
					if (!childAdditions.isEmpty()) {
						if (child.comment() != null) comments.put(childAbs, child.comment());
						additions.put(key, childAdditions);
					}
				} else if (!(docVal instanceof TomlValue.Table) && modelVal instanceof TomlValue.Table modelSub) {
					removals.add(childAbs);
					TomlValue.Table childAdditions = TomlValue.table();
					planNode(child, null, modelSub, childAbs, policy, childAdditions, comments, removals);
					if (!childAdditions.isEmpty()) {
						if (child.comment() != null) comments.put(childAbs, child.comment());
						additions.put(key, childAdditions);
					}
				} else {
					planChildrenIntoExisting(child, key, docVal, modelVal, childAbs, policy, additions, comments, removals);
				}
			}
		}
	}

	private void planChildrenIntoExisting(Node child, String key, TomlValue docVal, TomlValue modelVal, ConfigPath childAbs,
			ReconcilePolicy policy, TomlValue.Table additions, Comments.Builder comments, List<ConfigPath> removals) {
		TomlValue.Table modelSub = modelVal instanceof TomlValue.Table mt ? mt : null;
		if (!(docVal instanceof TomlValue.Table docSub)) {
			if (hasMaterializableDescendant(child, modelSub)) {
				throw new TomlEditException("ancestor is not a table: " + childAbs, childAbs);
			}
			return;
		}
		TomlValue.Table childAdditions = TomlValue.table();
		planNode(child, docSub, modelSub, childAbs, policy, childAdditions, comments, removals);
		if (!childAdditions.isEmpty()) {
			additions.put(key, childAdditions);
		}
	}

	private static boolean hasMaterializableDescendant(Node node, TomlValue.Table model) {
		for (Map.Entry<String, Node> entry : node.children().entrySet()) {
			Node child = entry.getValue();
			TomlValue modelVal = model == null ? null : model.get(entry.getKey());
			if (child.dynamic()) {
				if (modelVal != null) return true;
			} else if (child.defaultValue() != null) {
				return true;
			} else if (child.hasChildren()
					&& hasMaterializableDescendant(child, modelVal instanceof TomlValue.Table mt ? mt : null)) {
				return true;
			}
		}
		return false;
	}

	private void planDynamic(Node node, String key, TomlValue docVal, TomlValue modelVal, ConfigPath abs,
			ReconcilePolicy policy, TomlValue.Table additions, Comments.Builder comments, List<ConfigPath> removals) {
		if (!(modelVal instanceof TomlValue.Table modelMap)) {
			throw new TomlEditException("dynamic table model must be a table: " + abs, abs);
		}
		TomlValue.Table docMap;
		if (docVal == null) {
			docMap = null;
		} else if (docVal instanceof TomlValue.Table table) {
			docMap = table;
		} else {
			removals.add(abs);
			docMap = null;
		}

		if (policy == ReconcilePolicy.SYNC && docMap != null) {
			for (String existingKey : docMap.members().keySet()) {
				if (!modelMap.containsKey(existingKey)) {
					removals.add(abs.appended(existingKey));
				}
			}
		}

		TomlSchema entrySchema = node.entrySchema();
		TomlValue.Table mapAdditions = TomlValue.table();

		for (Map.Entry<String, TomlValue> entry : modelMap.members().entrySet()) {
			String entryKey = entry.getKey();
			TomlValue entryModelVal = entry.getValue();
			ConfigPath entryAbs = abs.appended(entryKey);
			if (!(entryModelVal instanceof TomlValue.Table entryModel)) {
				throw new TomlEditException("dynamic table entry must be a table: " + entryAbs, entryAbs);
			}
			TomlValue docEntryVal = docMap == null ? null : docMap.get(entryKey);
			TomlValue.Table docEntry;
			if (docEntryVal == null) {
				docEntry = null;
			} else if (docEntryVal instanceof TomlValue.Table table) {
				docEntry = table;
			} else {
				removals.add(entryAbs);
				docEntry = null;
			}
			TomlValue.Table entryAdditions = TomlValue.table();

			planDynamicEntryModelMembers(entrySchema == null ? null : entrySchema.root,
					docEntry, entryModel, entryAbs, entryAdditions, comments);

			if (entrySchema != null) {
				TomlValue.Table effectiveDoc = mergeView(docEntry, entryAdditions);
				TomlValue.Table schemaAdditions = TomlValue.table();
				entrySchema.planNode(entrySchema.root, effectiveDoc, entryModel, entryAbs, policy,
						schemaAdditions, comments, removals);
				mergeInto(entryAdditions, schemaAdditions);
			}

			if (docEntry == null) {
				if (entrySchema != null && entrySchema.root.comment() != null) {
					comments.put(entryAbs, entrySchema.root.comment());
				}
				mapAdditions.put(entryKey, entryAdditions);
			} else if (!entryAdditions.isEmpty()) {
				mapAdditions.put(entryKey, entryAdditions);
			}
		}

		// Entries preserved by INSERT_ONLY still receive declared entry-schema defaults and comments.
		if (entrySchema != null && policy != ReconcilePolicy.SYNC && docMap != null) {
			for (Map.Entry<String, TomlValue> existing : docMap.members().entrySet()) {
				String existingKey = existing.getKey();
				if (modelMap.containsKey(existingKey) || !(existing.getValue() instanceof TomlValue.Table existingEntry)) {
					continue;
				}
				ConfigPath entryAbs = abs.appended(existingKey);
				TomlValue.Table entryAdditions = TomlValue.table();
				entrySchema.planNode(entrySchema.root, existingEntry, existingEntry, entryAbs, policy,
						entryAdditions, comments, removals);
				if (!entryAdditions.isEmpty()) {
					mapAdditions.put(existingKey, entryAdditions);
				}
			}
		}

		if (!mapAdditions.isEmpty()) {
			if (docMap == null && node.comment() != null) {
				comments.put(abs, node.comment());
			}
			additions.put(key, mapAdditions);
		}
	}

	private static void planDynamicEntryModelMembers(Node schemaNode, TomlValue.Table docTable, TomlValue.Table modelTable,
			ConfigPath abs, TomlValue.Table outAdditions, Comments.Builder comments) {
		for (Map.Entry<String, TomlValue> entry : modelTable.members().entrySet()) {
			String key = entry.getKey();
			TomlValue value = entry.getValue();
			Node schemaChild = schemaNode == null ? null : schemaNode.children().get(key);
			if (schemaChild != null && schemaChild.dynamic()) {
				continue;
			}
			ConfigPath childAbs = abs.appended(key);
			TomlValue docVal = docTable == null ? null : docTable.get(key);
			if (docVal == null) {
				if (schemaChild != null && schemaChild.comment() != null) {
					comments.put(childAbs, schemaChild.comment());
				}
				if (value instanceof TomlValue.Table modelSub && schemaChild != null && schemaChild.hasChildren()) {
					TomlValue.Table childAdditions = TomlValue.table();
					planDynamicEntryModelMembers(schemaChild, null, modelSub, childAbs, childAdditions, comments);
					outAdditions.put(key, childAdditions);
				} else {
					outAdditions.put(key, TomlTrees.deepCopy(value));
				}
			} else if (docVal instanceof TomlValue.Table docSub && value instanceof TomlValue.Table modelSub) {
				TomlValue.Table childAdditions = TomlValue.table();
				planDynamicEntryModelMembers(schemaChild, docSub, modelSub, childAbs, childAdditions, comments);
				if (!childAdditions.isEmpty()) {
					outAdditions.put(key, childAdditions);
				}
			}
		}
	}

	private static TomlValue.Table mergeView(TomlValue.Table existing, TomlValue.Table additions) {
		if (existing == null) return additions;
		if (additions.isEmpty()) return existing;
		TomlValue.Table view = (TomlValue.Table) TomlTrees.deepCopy(existing);
		mergeInto(view, additions);
		return view;
	}

	private static void mergeInto(TomlValue.Table target, TomlValue.Table source) {
		for (Map.Entry<String, TomlValue> entry : source.members().entrySet()) {
			String key = entry.getKey();
			TomlValue srcVal = entry.getValue();
			TomlValue dstVal = target.get(key);
			if (dstVal == null) {
				target.put(key, srcVal);
			} else if (dstVal instanceof TomlValue.Table dstTbl && srcVal instanceof TomlValue.Table srcTbl) {
				mergeInto(dstTbl, srcTbl);
			}
		}
	}

	// ------------------------------------------------------------------ canonical comments & defaults

	private Comments commentsFor(TomlValue.Table model) {
		Comments.Builder builder = Comments.builder();
		if (banner != null) builder.banner(banner);
		addCommentsTo(builder, ConfigPath.root());
		addDynamicComments(root, model, ConfigPath.root(), builder);
		return builder.build();
	}

	private static void addDynamicComments(Node node, TomlValue.Table model, ConfigPath path, Comments.Builder builder) {
		for (Map.Entry<String, Node> entry : node.children().entrySet()) {
			Node child = entry.getValue();
			TomlValue modelValue = model.get(entry.getKey());
			ConfigPath childPath = path.appended(entry.getKey());
			if (child.dynamic()) {
				if (child.entrySchema() == null || !(modelValue instanceof TomlValue.Table map)) continue;
				for (Map.Entry<String, TomlValue> mapEntry : map.members().entrySet()) {
					if (!(mapEntry.getValue() instanceof TomlValue.Table entryTable)) continue;
					ConfigPath entryPath = childPath.appended(mapEntry.getKey());
					child.entrySchema().addCommentsTo(builder, entryPath);
					addDynamicComments(child.entrySchema().root, entryTable, entryPath, builder);
				}
			} else if (child.hasChildren() && modelValue instanceof TomlValue.Table table) {
				addDynamicComments(child, table, childPath, builder);
			}
		}
	}

	private static void addDeclaredComments(Node node, Comments.Builder builder, ConfigPath path) {
		String comment = node.comment();
		if (comment != null && !path.isRoot()) builder.put(path, comment);
		for (Map.Entry<String, Node> entry : node.children().entrySet()) {
			addDeclaredComments(entry.getValue(), builder, path.appended(entry.getKey()));
		}
	}

	private static void addDefaults(Node node, TomlValue.Table target) {
		for (Map.Entry<String, Node> entry : node.children().entrySet()) {
			Node child = entry.getValue();
			TomlValue value;
			if (child.defaultValue() != null) {
				value = TomlTrees.deepCopy(child.defaultValue());
				if (child.hasChildren() && value instanceof TomlValue.Table table) {
					addDefaults(child, table);
				}
			} else if (child.hasChildren()) {
				TomlValue.Table sub = TomlValue.table();
				addDefaults(child, sub);
				if (sub.isEmpty()) continue;
				value = sub;
			} else {
				continue;
			}
			target.put(entry.getKey(), value);
		}
	}

	private int maxDepth() {
		return maxDepth(root);
	}

	private static int maxDepth(Node node) {
		int max = 0;
		for (Node child : node.children().values()) {
			int childDepth = 1 + (child.dynamic() && child.entrySchema() != null
					? 1 + child.entrySchema().maxDepth()
					: maxDepth(child));
			if (childDepth > max) max = childDepth;
		}
		return max;
	}

	private static void requireKeyOnlyPath(ConfigPath path, boolean allowRoot) {
		Objects.requireNonNull(path, "path");
		if (path.isRoot()) {
			if (allowRoot) return;
			throw new IllegalArgumentException("schema path must not be root");
		}
		if (path.size() > TomlParser.MAX_DEPTH) {
			throw new IllegalArgumentException("TOML key nesting exceeds " + TomlParser.MAX_DEPTH);
		}
		for (ConfigPath.Segment segment : path.segments()) {
			if (!(segment instanceof ConfigPath.Segment.Key)) {
				throw new IllegalArgumentException("schema path must contain only key segments: " + path);
			}
		}
	}

	private record Node(
			TomlValue defaultValue,
			String comment,
			boolean dynamic,
			TomlSchema entrySchema,
			Map<String, Node> children) {
		private boolean hasChildren() {
			return !children.isEmpty();
		}
	}

	/** Fluent builder for {@link TomlSchema}. */
	public static final class Builder {
		private String banner;
		private final BuilderNode root = new BuilderNode();

		/** Creates an empty schema builder. */
		public Builder() {}

		/**
		 * Sets the top-of-file banner comment.
		 *
		 * @param banner banner text, or {@code null} for none
		 * @return this builder
		 */
		public Builder banner(String banner) {
			this.banner = banner;
			return this;
		}

		/**
		 * Declares a field with a default value and no comment.
		 *
		 * @param path key-only path to the field
		 * @param defaultValue default TOML value
		 * @return this builder
		 */
		public Builder field(ConfigPath path, TomlValue defaultValue) {
			return field(path, defaultValue, null);
		}

		/**
		 * Declares a field with a default value and an optional attached comment. Each path may be
		 * declared once. A table default may be refined by more specific field declarations below
		 * the same path; a non-table default may not have nested fields.
		 *
		 * @param path key-only path to the field
		 * @param defaultValue default TOML value
		 * @param comment optional attached comment text, or {@code null}
		 * @return this builder
		 */
		public Builder field(ConfigPath path, TomlValue defaultValue, String comment) {
			requireKeyOnlyPath(path, false);
			Objects.requireNonNull(defaultValue, "defaultValue");
			TomlTrees.validateForBuilder(defaultValue, path.size());
			requireNoDynamicAncestor(path, true);
			BuilderNode existing = findNode(path);
			if (existing != null) {
				if (existing.defaultValue != null) throw new IllegalArgumentException("field already declared: " + path);
				if (existing.hasChildren() && !(defaultValue instanceof TomlValue.Table)) {
					throw new IllegalArgumentException("field with non-table default cannot have nested fields: " + path);
				}
			}
			BuilderNode node = existing != null ? existing : nodeAt(path);
			node.defaultValue = TomlTrees.deepCopy(defaultValue);
			if (comment != null) node.comment = comment;
			return this;
		}

		/**
		 * Declares a comment for a section header or field path without attaching a default value.
		 * A root-path comment documents the header of a sub-schema when it is attached as a dynamic
		 * entry or materialized at a non-root prefix; top-level document comments belong in
		 * {@link #banner(String)}. Repeated declarations for the same path replace the earlier
		 * comment.
		 *
		 * @param path key-only path to the table/section/field, or {@link ConfigPath#root()} for a
		 *             sub-schema root comment
		 * @param comment comment text
		 * @return this builder
		 */
		public Builder comment(ConfigPath path, String comment) {
			requireKeyOnlyPath(path, true);
			Objects.requireNonNull(comment, "comment");
			requireNoDynamicAncestor(path, false);
			nodeAt(path).comment = comment;
			return this;
		}

		/**
		 * Declares a dynamic map-of-tables section (for example {@code [groups.<id>]}) without an
		 * entry schema. On {@link TomlSchema#apply(Document, TomlValue.Table, ReconcilePolicy)}
		 * entries present in the model are inserted, missing members of existing entries are added,
		 * and under {@link ReconcilePolicy#SYNC} entries absent from the model are removed. A model
		 * that does not contain this path leaves the document section untouched.
		 *
		 * @param path key-only path to the parent map table
		 * @return this builder
		 */
		public Builder dynamicTable(ConfigPath path) {
			return dynamicTable(path, null);
		}

		/**
		 * Declares a dynamic map-of-tables section with an optional per-entry schema. The entry
		 * schema supplies defaults and comments for every entry in the model; an entry's section
		 * header uses the entry schema's root comment. Under {@link ReconcilePolicy#INSERT_ONLY},
		 * entries absent from the model are preserved and still receive entry-schema defaults.
		 *
		 * <p>A path may be registered only once, and may not overlap declared fields.
		 *
		 * @param path key-only path to the parent map table
		 * @param entrySchema optional entry schema for defaults and comments, or {@code null}
		 * @return this builder
		 */
		public Builder dynamicTable(ConfigPath path, TomlSchema entrySchema) {
			requireKeyOnlyPath(path, false);
			if (entrySchema != null && path.size() + 1 + entrySchema.maxDepth() > TomlParser.MAX_DEPTH) {
				throw new IllegalArgumentException("TOML key nesting exceeds " + TomlParser.MAX_DEPTH);
			}
			requireNoDynamicAncestor(path, false);
			BuilderNode existing = findNode(path);
			if (existing != null) {
				if (existing.dynamic) throw new IllegalArgumentException("dynamic table already declared: " + path);
				if (existing.defaultValue != null) throw new IllegalArgumentException("dynamic table conflicts with a field default: " + path);
				if (existing.hasChildren()) throw new IllegalArgumentException("dynamic table conflicts with nested field declarations: " + path);
			}
			BuilderNode node = existing != null ? existing : nodeAt(path);
			node.dynamic = true;
			node.entrySchema = entrySchema;
			return this;
		}

		/**
		 * Builds an immutable {@link TomlSchema}.
		 *
		 * @return built {@link TomlSchema}
		 */
		public TomlSchema build() {
			return new TomlSchema(banner, root.freeze());
		}

		private BuilderNode findNode(ConfigPath path) {
			BuilderNode current = root;
			for (ConfigPath.Segment segment : path.segments()) {
				current = current.children.get(((ConfigPath.Segment.Key) segment).name());
				if (current == null) return null;
			}
			return current;
		}

		private BuilderNode nodeAt(ConfigPath path) {
			BuilderNode current = root;
			for (ConfigPath.Segment segment : path.segments()) {
				current = current.children.computeIfAbsent(((ConfigPath.Segment.Key) segment).name(), unused -> new BuilderNode());
			}
			return current;
		}

		private void requireNoDynamicAncestor(ConfigPath path, boolean includeTarget) {
			BuilderNode current = root;
			List<ConfigPath.Segment> segments = path.segments();
			for (int i = 0; i < segments.size(); i++) {
				BuilderNode next = current.children.get(((ConfigPath.Segment.Key) segments.get(i)).name());
				if (next == null) return;
				boolean last = i == segments.size() - 1;
				if (next.dynamic && (includeTarget || !last)) {
					throw new IllegalArgumentException("schema path must not enter a dynamic table: " + path);
				}
				if (!last && next.defaultValue != null && !(next.defaultValue instanceof TomlValue.Table)) {
					throw new IllegalArgumentException("schema path passes through a non-table default: " + path);
				}
				current = next;
			}
		}

		private static final class BuilderNode {
			private final LinkedHashMap<String, BuilderNode> children = new LinkedHashMap<>();
			private TomlValue defaultValue;
			private String comment;
			private boolean dynamic;
			private TomlSchema entrySchema;

			private boolean hasChildren() {
				return !children.isEmpty();
			}

			private Node freeze() {
				LinkedHashMap<String, Node> frozenChildren = new LinkedHashMap<>(children.size());
				for (Map.Entry<String, BuilderNode> entry : children.entrySet()) {
					frozenChildren.put(entry.getKey(), entry.getValue().freeze());
				}
				TomlValue frozenDefault = defaultValue == null ? null : TomlTrees.deepCopy(defaultValue);
				return new Node(frozenDefault, comment, dynamic, entrySchema, Collections.unmodifiableMap(frozenChildren));
			}
		}
	}
}
