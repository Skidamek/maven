package pl.skidam.tomledit;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Surgical entry and comment editor over {@link Cst.Doc}.
 *
 * <p>Preserves local line endings (LF/CRLF), indentation, key spelling, and trailing comments.
 * Delegates section-level operations to {@link CstSectionEditor} and inline-table edits to
 * {@link CstInlineTableEditor}.
 */
final class CstEntryEditor {
	private CstEntryEditor() {}

	static void set(Cst.Doc doc, ConfigPath path, TomlValue value) {
		if (path.isRoot()) throw new TomlEditException("cannot replace root table with set()", path);
		CstNavigator.Target target = CstNavigator.requireTarget(doc, path);

		if (target instanceof CstNavigator.ValueTarget vt) {
			if (Cst.toValue(vt.value()).equals(value)) return;
			vt.setValue(Cst.parseInlineVal(value));
			return;
		}
		TomlValue existing = Cst.toTable(doc).get(path);
		if (value.equals(existing)) return;

		if (target instanceof CstNavigator.SectionTarget st) {
			if (value instanceof TomlValue.Table newTbl) {
				CstSectionEditor.replaceSectionBody(doc, st.section(), path, newTbl);
				return;
			}
			replaceMemberSubtree(doc, path, value);
			return;
		}
		if (target instanceof CstNavigator.VirtualInlineTableTarget vit) {
			CstInlineTableEditor.replaceVirtualTable(vit, value);
			return;
		}
		if (target instanceof CstNavigator.ArrayOfTablesTarget || target instanceof CstNavigator.VirtualTableTarget) {
			replaceMemberSubtree(doc, path, value);
			return;
		}
		throw new TomlEditException("cannot set value at " + path, path);
	}

	private static void replaceMemberSubtree(Cst.Doc doc, ConfigPath path, TomlValue value) {
		String key = requireKeySegment(path.last(), path);
		Optional<String> comment = attachedComment(doc, path);
		removeMember(doc, path);
		DocumentEditor.ensureAncestors(doc, path.parent());
		insertMember(doc, path.parent(), key, value, comment.orElse(null), null);
	}

	static void insertMember(Cst.Doc doc, ConfigPath parentPath, String key, TomlValue value, String comment, String trailingNote) {
		Comments comments = comment == null ? Comments.NONE : Comments.of(null, Map.of(parentPath.appended(key), comment));
		insertMemberValue(doc, parentPath, key, value, null, comments, trailingNote);
	}

	static void insertMember(Cst.Doc doc, ConfigPath parentPath, String key, TomlValue value, Comments comments) {
		insertMemberValue(doc, parentPath, key, value, null, comments, null);
	}

	/**
	 * Inserts a new member into {@code parentPath}. When {@code preservedVal} is non-null (used by
	 * lossless {@code rename}), the existing {@link Cst.Val} CST node is carried verbatim instead of
	 * re-formatting from {@code value}.
	 */
	static void insertMemberValue(Cst.Doc doc, ConfigPath parentPath, String key, TomlValue value, Cst.Val preservedVal,
			Comments comments, String trailingNote) {
		ConfigPath fullPath = parentPath.appended(key);
		if (CstNavigator.resolve(doc, fullPath) != null) {
			throw new TomlEditException("member already exists: " + fullPath, fullPath);
		}
		CstNavigator.Target parent = CstNavigator.requireTarget(doc, parentPath);
		byte[] nl = detectDocNewline(doc);
		String comment = comments.get(fullPath).orElse(null);

		// Case 1: Inline table parent (including dotted virtual table inside an inline table)
		if (parent instanceof CstNavigator.VirtualInlineTableTarget vit) {
			List<String> dotted = new ArrayList<>(vit.prefixKeys());
			dotted.add(key);
			CstInlineTableEditor.insert(vit.ownerTable(), dotted, value, comment, nl);
			return;
		}
		Cst.InlineTable inlineTbl = parent.asInlineTable();
		if (inlineTbl != null) {
			CstInlineTableEditor.insert(inlineTbl, List.of(key), value, comment, nl);
			return;
		}

		if (!(parent instanceof CstNavigator.RootTarget || parent instanceof CstNavigator.SectionTarget || parent instanceof CstNavigator.VirtualTableTarget)) {
			throw new TomlEditException("parent is not a table: " + parentPath, parentPath);
		}

		// Case 2: Table or all-table array value -> emit section(s) placed right after parent's subtree
		if (preservedVal == null && value instanceof TomlValue.Table tbl) {
			int insertAt = CstSectionEditor.findSectionInsertIndex(doc, parentPath);
			CstSectionEditor.appendTableSection(doc, insertAt, fullPath, tbl, comments, nl);
			return;
		}
		if (preservedVal == null && value instanceof TomlValue.Array arr && Cst.isArrayOfTables(arr)) {
			int insertAt = CstSectionEditor.findSectionInsertIndex(doc, parentPath);
			CstSectionEditor.appendArrayOfTablesSections(doc, insertAt, fullPath, arr, comments, nl);
			return;
		}

		// Case 3: Scalar, array, or carried Cst.Val entry into root, section, or virtual table
		if (parent instanceof CstNavigator.RootTarget) {
			insertKeyPathEntryIntoItemList(doc.rootItems, buildSingleKeyPath(key), value, preservedVal, comment, trailingNote, nl);
		} else if (parent instanceof CstNavigator.SectionTarget st) {
			byte[] secNl = detectSectionNewline(st.section(), nl);
			if (!Cst.endsWithNewline(st.section().trailingTrivia)) {
				st.section().trailingTrivia.add(new Cst.Tok(Cst.TokKind.NL, secNl));
			}
			insertKeyPathEntryIntoItemList(st.section().items, buildSingleKeyPath(key), value, preservedVal, comment, trailingNote, secNl);
		} else if (parent instanceof CstNavigator.VirtualTableTarget vt) {
			if (vt.dottedOwnerItems() != null) {
				ConfigPath relPath = new ConfigPath(fullPath.segments().subList(vt.dottedOwnerBase().size(), fullPath.size()));
				insertKeyPathEntryIntoItemList(vt.dottedOwnerItems(), buildDottedKeyPath(relPath), value, preservedVal, comment, trailingNote, nl);
			} else {
				Cst.Section sec = CstSectionEditor.materializeSectionHeader(doc, parentPath, null, nl);
				insertKeyPathEntryIntoItemList(sec.items, buildSingleKeyPath(key), value, preservedVal, comment, trailingNote, nl);
			}
		}
	}

	static void removeMember(Cst.Doc doc, ConfigPath path) {
		if (path.isRoot()) throw new TomlEditException("cannot remove root table", path);
		CstNavigator.Target target = CstNavigator.requireTarget(doc, path);

		if (target instanceof CstNavigator.EntryTarget et) {
			et.ownerItems().remove(et.entry());
			return;
		}
		if (target instanceof CstNavigator.InlineEntryTarget iet) {
			CstInlineTableEditor.removeEntry(iet.ownerTable(), iet.entry());
			return;
		}
		if (target instanceof CstNavigator.VirtualInlineTableTarget vit) {
			CstInlineTableEditor.removeVirtualTable(vit.ownerTable(), vit.prefixKeys());
			return;
		}
		if (target instanceof CstNavigator.SectionTarget || target instanceof CstNavigator.ArrayOfTablesTarget || target instanceof CstNavigator.VirtualTableTarget) {
			CstSectionEditor.removeSubtree(doc, path);
			return;
		}
		throw new TomlEditException("removeMember addresses table members, not array elements: " + path, path);
	}

	static Optional<String> attachedComment(Cst.Doc doc, ConfigPath path) {
		if (path.isRoot()) return Optional.empty();
		CstNavigator.Target target = CstNavigator.resolve(doc, path);
		if (target == null) return Optional.empty();
		if (target instanceof CstNavigator.EntryTarget et) {
			return formatLeadingComments(et.entry().leadingComments);
		}
		if (target instanceof CstNavigator.SectionTarget st) {
			return formatLeadingComments(st.section().leadingComments);
		}
		if (target instanceof CstNavigator.ArrayOfTablesTarget aot) {
			return formatLeadingComments(aot.sections().get(0).leadingComments);
		}
		if (target instanceof CstNavigator.ArrayElemTarget aet) {
			return extractCommentRunFromTrivia(aet.item().leadingTrivia);
		}
		if (target instanceof CstNavigator.InlineEntryTarget iet) {
			return extractCommentRunFromTrivia(iet.entry().leadingTrivia);
		}
		return Optional.empty();
	}

	static void setComment(Cst.Doc doc, ConfigPath path, String comment) {
		if (path.isRoot()) throw new TomlEditException("cannot set comment on root", path);
		CstNavigator.Target target = CstNavigator.requireTarget(doc, path);
		byte[] docNl = detectDocNewline(doc);

		if (target instanceof CstNavigator.EntryTarget et) {
			setLeadingComments(et.entry().leadingComments, et.entry().leadingWs, comment, detectEntryNewline(et.entry(), docNl));
			return;
		}
		if (target instanceof CstNavigator.SectionTarget st) {
			setLeadingComments(st.section().leadingComments, st.section().leadingWs, comment, detectSectionNewline(st.section(), docNl));
			return;
		}
		if (target instanceof CstNavigator.ArrayOfTablesTarget aot) {
			Cst.Section first = aot.sections().get(0);
			setLeadingComments(first.leadingComments, first.leadingWs, comment, detectSectionNewline(first, docNl));
			return;
		}
		throw new TomlEditException("setComment addresses entries or table headers: " + path, path);
	}

	private static void setLeadingComments(List<Cst.TriviaLine> leadingComments, List<Cst.Tok> leadingWs, String comment, byte[] nl) {
		Optional<String> current = formatLeadingComments(leadingComments);
		if (comment == null) {
			leadingComments.clear();
			return;
		}
		String normalized = normalizeCommentInput(comment);
		if (current.isPresent() && current.get().equals(normalized)) return;
		byte[] indent = firstWsBytes(leadingWs);
		leadingComments.clear();
		leadingComments.addAll(buildCommentLines(normalized, indent, nl));
	}

	static String extractTrailingNote(Cst.Entry entry) {
		for (Cst.Tok tok : entry.trailingTrivia) {
			if (tok.kind() == Cst.TokKind.COMMENT) {
				return stripCommentMarker(tok.bytes());
			}
		}
		return null;
	}

	// ------------------------------------------------------------------ shared entry & trivia primitives

	static void insertEntryIntoItemList(List<Cst.Item> items, String key, TomlValue value, String comment, String trailingNote, byte[] nl) {
		insertKeyPathEntryIntoItemList(items, buildSingleKeyPath(key), value, null, comment, trailingNote, nl);
	}

	static void insertKeyPathEntryIntoItemList(List<Cst.Item> items, Cst.KeyPath keyPath, TomlValue value, Cst.Val preservedVal,
			String comment, String trailingNote, byte[] nl) {
		int insertAt = prepareItemInsertPoint(items, nl);
		byte[] indent = detectEntryIndent(items);
		List<Cst.TriviaLine> comments = comment != null ? buildCommentLines(normalizeCommentInput(comment), indent, nl) : List.of();
		List<Cst.Tok> leadingWs = indent.length > 0 ? List.of(new Cst.Tok(Cst.TokKind.WS, indent)) : List.of();
		List<Cst.Tok> eqTrivia = Cst.eqTrivia();
		Cst.Val val = preservedVal != null ? preservedVal : Cst.parseInlineVal(value);
		List<Cst.Tok> trailing = new ArrayList<>();
		if (trailingNote != null) {
			String cleanNote = CanonicalWriter.sanitizeCommentLine(normalizeCommentInput(trailingNote).replace('\n', ' '));
			trailing.add(new Cst.Tok(Cst.TokKind.WS, new byte[] {' '}));
			trailing.add(new Cst.Tok(Cst.TokKind.COMMENT, CanonicalWriter.encodeUtf8Strict("# " + cleanNote)));
		}
		trailing.add(new Cst.Tok(Cst.TokKind.NL, nl));
		items.add(insertAt, new Cst.Entry(comments, leadingWs, keyPath, eqTrivia, val, trailing));
	}

	static void insertExistingEntryIntoItemList(List<Cst.Item> items, Cst.Entry entry, byte[] nl) {
		int insertAt = prepareItemInsertPoint(items, nl);
		if (!Cst.endsWithNewline(entry.trailingTrivia)) {
			entry.trailingTrivia.add(new Cst.Tok(Cst.TokKind.NL, nl));
		}
		items.add(insertAt, entry);
	}

	private static int prepareItemInsertPoint(List<Cst.Item> items, byte[] nl) {
		// Insert before trailing blank lines so inter-section spacing stays intact
		int insertAt = items.size();
		while (insertAt > 0 && items.get(insertAt - 1) instanceof Cst.TriviaLine tl && !tl.hasComment()) {
			insertAt--;
		}
		if (insertAt > 0 && items.get(insertAt - 1) instanceof Cst.Entry prev && !Cst.endsWithNewline(prev.trailingTrivia)) {
			prev.trailingTrivia.add(new Cst.Tok(Cst.TokKind.NL, nl));
		} else if (insertAt > 0 && items.get(insertAt - 1) instanceof Cst.TriviaLine prevTl) {
			if (!Cst.endsWithNewline(prevTl.tokens)) {
				prevTl.tokens.add(new Cst.Tok(Cst.TokKind.NL, nl));
			}
			// Separate dangling comment with a blank line so re-parsing does not re-bind it onto this entry (INV-6)
			if (prevTl.hasComment()) {
				items.add(insertAt++, new Cst.TriviaLine(List.of(new Cst.Tok(Cst.TokKind.NL, nl))));
			}
		}
		return insertAt;
	}

	static Cst.KeyPath buildSingleKeyPath(String key) {
		String spelled = CanonicalWriter.formatKey(key);
		Cst.TokKind kind = spelled.startsWith("\"") ? Cst.TokKind.BASIC_STR : Cst.TokKind.BARE_KEY;
		return new Cst.KeyPath(List.of(new Cst.Tok(kind, CanonicalWriter.encodeUtf8Strict(spelled))), List.of(key));
	}

	static Cst.KeyPath buildDottedKeyPath(ConfigPath path) {
		List<String> keys = new ArrayList<>(path.size());
		for (ConfigPath.Segment seg : path.segments()) {
			if (seg instanceof ConfigPath.Segment.Key k) keys.add(k.name());
		}
		return buildDottedKeyPath(keys);
	}

	static Cst.KeyPath buildDottedKeyPath(List<String> keys) {
		List<Cst.Tok> toks = new ArrayList<>(keys.size() * 2);
		for (int i = 0; i < keys.size(); i++) {
			if (i > 0) toks.add(new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {'.'}));
			String spelled = CanonicalWriter.formatKey(keys.get(i));
			Cst.TokKind kind = spelled.startsWith("\"") ? Cst.TokKind.BASIC_STR : Cst.TokKind.BARE_KEY;
			toks.add(new Cst.Tok(kind, CanonicalWriter.encodeUtf8Strict(spelled)));
		}
		return new Cst.KeyPath(toks, keys);
	}

	static void replaceKeyPath(Cst.KeyPath target, Cst.KeyPath replacement) {
		target.tokens.clear();
		target.tokens.addAll(replacement.tokens);
		target.keys.clear();
		target.keys.addAll(replacement.keys);
	}

	/** Replaces a single key segment inside a {@link Cst.KeyPath} in place, preserving dots and surrounding whitespace. */
	static void replaceKeySegmentAt(Cst.KeyPath keyPath, int keyIndex, String newKey) {
		Cst.KeyPath single = buildSingleKeyPath(newKey);
		int seen = 0;
		for (int i = 0; i < keyPath.tokens.size(); i++) {
			Cst.TokKind kind = keyPath.tokens.get(i).kind();
			if (kind == Cst.TokKind.BARE_KEY || kind == Cst.TokKind.BASIC_STR || kind == Cst.TokKind.LITERAL_STR) {
				if (seen == keyIndex) {
					keyPath.tokens.set(i, single.tokens.get(0));
					keyPath.keys.set(keyIndex, newKey);
					return;
				}
				seen++;
			}
		}
	}

	static Optional<String> formatLeadingComments(List<Cst.TriviaLine> lines) {
		if (lines.isEmpty()) return Optional.empty();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < lines.size(); i++) {
			if (i > 0) sb.append('\n');
			for (Cst.Tok tok : lines.get(i).tokens) {
				if (tok.kind() == Cst.TokKind.COMMENT) {
					sb.append(stripCommentMarker(tok.bytes()));
					break;
				}
			}
		}
		return Optional.of(sb.toString());
	}

	private static Optional<String> extractCommentRunFromTrivia(List<Cst.Tok> trivia) {
		List<List<Cst.Tok>> lines = new ArrayList<>();
		List<Cst.Tok> current = new ArrayList<>();
		for (Cst.Tok tok : trivia) {
			current.add(tok);
			if (tok.kind() == Cst.TokKind.NL) {
				lines.add(current);
				current = new ArrayList<>();
			}
		}
		List<String> collected = new ArrayList<>();
		for (int i = lines.size() - 1; i >= 0; i--) {
			String comment = null;
			for (Cst.Tok tok : lines.get(i)) {
				if (tok.kind() == Cst.TokKind.COMMENT) {
					comment = stripCommentMarker(tok.bytes());
					break;
				}
			}
			if (comment == null) break;
			collected.add(0, comment);
		}
		return collected.isEmpty() ? Optional.empty() : Optional.of(String.join("\n", collected));
	}

	private static String stripCommentMarker(byte[] bytes) {
		int s = 1;
		if (s < bytes.length && bytes[s] == ' ') s++;
		return new String(bytes, s, bytes.length - s, StandardCharsets.UTF_8);
	}

	static String normalizeCommentInput(String comment) {
		return comment.replace("\r\n", "\n").replace("\r", "\n");
	}

	static List<Cst.TriviaLine> buildCommentLines(String normalized, byte[] indent, byte[] nl) {
		String[] parts = normalized.split("\n", -1);
		List<Cst.TriviaLine> out = new ArrayList<>(parts.length);
		for (String part : parts) {
			String clean = CanonicalWriter.sanitizeCommentLine(part);
			List<Cst.Tok> toks = new ArrayList<>();
			if (indent.length > 0) toks.add(new Cst.Tok(Cst.TokKind.WS, indent));
			String line = clean.isEmpty() ? "#" : "# " + clean;
			toks.add(new Cst.Tok(Cst.TokKind.COMMENT, CanonicalWriter.encodeUtf8Strict(line)));
			toks.add(new Cst.Tok(Cst.TokKind.NL, nl));
			out.add(new Cst.TriviaLine(toks));
		}
		return out;
	}

	static String requireKeySegment(ConfigPath.Segment seg, ConfigPath path) {
		if (seg instanceof ConfigPath.Segment.Key k) return k.name();
		throw new TomlEditException("expected table key segment at " + path, path);
	}

	private static byte[] firstWsBytes(List<Cst.Tok> ws) {
		return !ws.isEmpty() ? ws.get(0).bytes() : new byte[0];
	}

	private static byte[] detectEntryIndent(List<Cst.Item> items) {
		for (int i = items.size() - 1; i >= 0; i--) {
			if (items.get(i) instanceof Cst.Entry e) {
				return firstWsBytes(e.leadingWs);
			}
		}
		return new byte[0];
	}

	static byte[] detectDocNewline(Cst.Doc doc) {
		for (Cst.Item item : doc.rootItems) {
			byte[] nl = itemNewline(item);
			if (nl != null) return nl;
		}
		for (Cst.Section sec : doc.sections) {
			byte[] nl = detectSectionNewline(sec, null);
			if (nl != null) return nl;
		}
		return new byte[] {'\n'};
	}

	static byte[] detectSectionNewline(Cst.Section sec, byte[] fallback) {
		for (Cst.Tok tok : sec.trailingTrivia) {
			if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
		}
		for (Cst.Item item : sec.items) {
			byte[] nl = itemNewline(item);
			if (nl != null) return nl;
		}
		return fallback;
	}

	private static byte[] detectEntryNewline(Cst.Entry entry, byte[] fallback) {
		for (Cst.Tok tok : entry.trailingTrivia) {
			if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
		}
		return fallback;
	}

	private static byte[] itemNewline(Cst.Item item) {
		if (item instanceof Cst.TriviaLine tl) {
			for (Cst.Tok tok : tl.tokens) if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
		} else if (item instanceof Cst.Entry e) {
			for (Cst.Tok tok : e.trailingTrivia) if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
		}
		return null;
	}
}
