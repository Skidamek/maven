package pl.skidam.tomledit;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Structured concrete syntax tree for TOML 1.1.0.
 *
 * <p>Every byte of the input lives in a {@link Tok}. Walking a {@link Doc} and concatenating
 * every token's bytes reproduces the source byte-for-byte.
 */
final class Cst {
	private Cst() {}

	enum TokKind {
		BOM, WS, NL, COMMENT,
		BARE_KEY, BASIC_STR, ML_BASIC_STR, LITERAL_STR, ML_LITERAL_STR,
		INT, FLOAT, BOOL,
		OFFSET_DATETIME, LOCAL_DATETIME, LOCAL_DATE, LOCAL_TIME,
		PUNCT
	}

	record Tok(TokKind kind, byte[] bytes) {}

	/** A dotted or single key preserving exact token spelling and whitespace around dots. */
	static final class KeyPath {
		final List<Tok> tokens;
		final List<String> keys;

		KeyPath(List<Tok> tokens, List<String> keys) {
			this.tokens = new ArrayList<>(tokens);
			this.keys = new ArrayList<>(keys);
		}
	}

	sealed interface Item permits TriviaLine, Entry {}

	/** Standalone blank line or comment line (optional WS, optional COMMENT, optional NL). */
	static final class TriviaLine implements Item {
		final List<Tok> tokens;

		TriviaLine(List<Tok> tokens) {
			this.tokens = new ArrayList<>(tokens);
		}

		boolean hasComment() {
			for (Tok tok : tokens) if (tok.kind() == TokKind.COMMENT) return true;
			return false;
		}
	}

	/** A key = value line inside root or a section, owning its attached leading comment lines. */
	static final class Entry implements Item {
		final List<TriviaLine> leadingComments;
		final List<Tok> leadingWs;
		final KeyPath key;
		final List<Tok> eqTrivia;
		Val value;
		final List<Tok> trailingTrivia;

		Entry(List<TriviaLine> leadingComments, List<Tok> leadingWs, KeyPath key, List<Tok> eqTrivia, Val value, List<Tok> trailingTrivia) {
			this.leadingComments = new ArrayList<>(leadingComments);
			this.leadingWs = new ArrayList<>(leadingWs);
			this.key = key;
			this.eqTrivia = new ArrayList<>(eqTrivia);
			this.value = value;
			this.trailingTrivia = new ArrayList<>(trailingTrivia);
		}
	}

	/** A [table] or [[array-table]] header and its owned items, plus its attached leading comment lines. */
	static final class Section {
		final boolean arrayTable;
		final List<TriviaLine> leadingComments;
		final List<Tok> leadingWs;
		final Tok openBracket;
		final List<Tok> preKeyWs;
		final KeyPath headerKey;
		final List<Tok> postKeyWs;
		final Tok closeBracket;
		final List<Tok> trailingTrivia;
		final List<Item> items = new ArrayList<>();

		Section(boolean arrayTable, List<TriviaLine> leadingComments, List<Tok> leadingWs, Tok openBracket, List<Tok> preKeyWs,
				KeyPath headerKey, List<Tok> postKeyWs, Tok closeBracket, List<Tok> trailingTrivia) {
			this.arrayTable = arrayTable;
			this.leadingComments = new ArrayList<>(leadingComments);
			this.leadingWs = new ArrayList<>(leadingWs);
			this.openBracket = openBracket;
			this.preKeyWs = new ArrayList<>(preKeyWs);
			this.headerKey = headerKey;
			this.postKeyWs = new ArrayList<>(postKeyWs);
			this.closeBracket = closeBracket;
			this.trailingTrivia = new ArrayList<>(trailingTrivia);
		}
	}

	/** Top-level document: optional BOM, root items, and [table]/[[array-table]] sections. */
	static final class Doc {
		Tok bom;
		final List<Item> rootItems = new ArrayList<>();
		final List<Section> sections = new ArrayList<>();
		CstNavigator.SectionIndex sectionIndex;

		void addSection(int index, Section section) {
			sections.add(index, section);
			sectionIndex = null;
		}

		void removeSections(Predicate<Section> filter) {
			if (sections.removeIf(filter)) {
				sectionIndex = null;
			}
		}

		void removeAllSections(List<Section> toRemove) {
			if (sections.removeAll(toRemove)) {
				sectionIndex = null;
			}
		}

		void invalidateSectionIndex() {
			sectionIndex = null;
		}
	}

	sealed interface Val permits Scalar, Arr, InlineTable {}

	static final class Scalar implements Val {
		final Tok token;
		final TomlValue value;

		Scalar(Tok token, TomlValue value) {
			this.token = token;
			this.value = value;
		}
	}

	static final class ArrayItem {
		final List<Tok> leadingTrivia;
		Val value;
		final List<Tok> postValueTrivia;
		Tok comma; // nullable
		final List<Tok> trailingSameLineTrivia;

		ArrayItem(List<Tok> leadingTrivia, Val value, List<Tok> postValueTrivia, Tok comma, List<Tok> trailingSameLineTrivia) {
			this.leadingTrivia = new ArrayList<>(leadingTrivia);
			this.value = value;
			this.postValueTrivia = new ArrayList<>(postValueTrivia);
			this.comma = comma;
			this.trailingSameLineTrivia = new ArrayList<>(trailingSameLineTrivia);
		}
	}

	static final class Arr implements Val {
		final Tok openBracket;
		final List<ArrayItem> items = new ArrayList<>();
		final List<Tok> trailingTrivia = new ArrayList<>();
		final Tok closeBracket;

		Arr(Tok openBracket, Tok closeBracket) {
			this.openBracket = openBracket;
			this.closeBracket = closeBracket;
		}
	}

	static final class InlineEntry {
		final List<Tok> leadingTrivia;
		final KeyPath key;
		final List<Tok> eqTrivia;
		Val value;
		final List<Tok> postValueTrivia;
		Tok comma; // nullable
		final List<Tok> trailingSameLineTrivia;

		InlineEntry(List<Tok> leadingTrivia, KeyPath key, List<Tok> eqTrivia, Val value, List<Tok> postValueTrivia, Tok comma, List<Tok> trailingSameLineTrivia) {
			this.leadingTrivia = new ArrayList<>(leadingTrivia);
			this.key = key;
			this.eqTrivia = new ArrayList<>(eqTrivia);
			this.value = value;
			this.postValueTrivia = new ArrayList<>(postValueTrivia);
			this.comma = comma;
			this.trailingSameLineTrivia = new ArrayList<>(trailingSameLineTrivia);
		}
	}

	static final class InlineTable implements Val {
		final Tok openBrace;
		final List<InlineEntry> entries = new ArrayList<>();
		final List<Tok> trailingTrivia = new ArrayList<>();
		final Tok closeBrace;

		InlineTable(Tok openBrace, Tok closeBrace) {
			this.openBrace = openBrace;
			this.closeBrace = closeBrace;
		}
	}

	// ------------------------------------------------------------------ shared CST primitives

	static Val parseInlineVal(TomlValue value) {
		String rendered = CanonicalWriter.formatInline(value);
		return TomlParser.parseValueFragment(rendered.getBytes(StandardCharsets.UTF_8));
	}

	static List<Tok> eqTrivia() {
		return List.of(
				new Tok(TokKind.WS, new byte[] {' '}),
				new Tok(TokKind.PUNCT, new byte[] {'='}),
				new Tok(TokKind.WS, new byte[] {' '}));
	}

	static boolean hasNewline(List<Tok> toks) {
		for (Tok tok : toks) if (tok.kind() == TokKind.NL) return true;
		return false;
	}

	static boolean endsWithNewline(List<Tok> toks) {
		return !toks.isEmpty() && toks.get(toks.size() - 1).kind() == TokKind.NL;
	}

	static List<Tok> extractSameLineFromTrivia(List<Tok> postValueTrivia, List<Tok> containerTrailing) {
		if (postValueTrivia.isEmpty()) return List.of();
		List<Tok> sameLine = new ArrayList<>();
		int split = postValueTrivia.size();
		for (int i = 0; i < postValueTrivia.size(); i++) {
			Tok tok = postValueTrivia.get(i);
			sameLine.add(tok);
			if (tok.kind() == TokKind.NL) {
				split = i + 1;
				break;
			}
		}
		if (split < postValueTrivia.size()) {
			containerTrailing.addAll(0, postValueTrivia.subList(split, postValueTrivia.size()));
		}
		postValueTrivia.clear();
		return sameLine;
	}

	static boolean isArrayOfTables(TomlValue.Array arr) {
		if (arr.isEmpty()) return false;
		for (int i = 0; i < arr.size(); i++) {
			if (!(arr.get(i) instanceof TomlValue.Table)) return false;
		}
		return true;
	}

	// ------------------------------------------------------------------ rendering

	static byte[] render(Doc doc) {
		int total = byteLength(doc);
		byte[] out = new byte[total];
		int offset = 0;
		if (doc.bom != null) offset = writeTok(doc.bom, out, offset);
		for (Item item : doc.rootItems) offset = renderItem(item, out, offset);
		for (Section section : doc.sections) offset = renderSection(section, out, offset);
		return out;
	}

	private static int byteLength(Doc doc) {
		int len = doc.bom != null ? doc.bom.bytes().length : 0;
		for (Item item : doc.rootItems) len += itemLength(item);
		for (Section section : doc.sections) len += sectionLength(section);
		return len;
	}

	private static int sectionLength(Section section) {
		int len = 0;
		for (TriviaLine comment : section.leadingComments) len += toksLength(comment.tokens);
		len += toksLength(section.leadingWs);
		len += section.openBracket.bytes().length;
		len += toksLength(section.preKeyWs);
		len += toksLength(section.headerKey.tokens);
		len += toksLength(section.postKeyWs);
		len += section.closeBracket.bytes().length;
		len += toksLength(section.trailingTrivia);
		for (Item item : section.items) len += itemLength(item);
		return len;
	}

	private static int itemLength(Item item) {
		if (item instanceof TriviaLine trivia) return toksLength(trivia.tokens);
		Entry entry = (Entry) item;
		int len = 0;
		for (TriviaLine comment : entry.leadingComments) len += toksLength(comment.tokens);
		len += toksLength(entry.leadingWs);
		len += toksLength(entry.key.tokens);
		len += toksLength(entry.eqTrivia);
		len += valLength(entry.value);
		len += toksLength(entry.trailingTrivia);
		return len;
	}

	private static int valLength(Val val) {
		if (val instanceof Scalar scalar) return scalar.token.bytes().length;
		if (val instanceof Arr arr) {
			int len = arr.openBracket.bytes().length + arr.closeBracket.bytes().length + toksLength(arr.trailingTrivia);
			for (ArrayItem item : arr.items) {
				len += toksLength(item.leadingTrivia) + valLength(item.value) + toksLength(item.postValueTrivia)
						+ (item.comma != null ? item.comma.bytes().length : 0) + toksLength(item.trailingSameLineTrivia);
			}
			return len;
		}
		InlineTable tbl = (InlineTable) val;
		int len = tbl.openBrace.bytes().length + tbl.closeBrace.bytes().length + toksLength(tbl.trailingTrivia);
		for (InlineEntry entry : tbl.entries) {
			len += toksLength(entry.leadingTrivia) + toksLength(entry.key.tokens) + toksLength(entry.eqTrivia)
					+ valLength(entry.value) + toksLength(entry.postValueTrivia)
					+ (entry.comma != null ? entry.comma.bytes().length : 0) + toksLength(entry.trailingSameLineTrivia);
		}
		return len;
	}

	private static int toksLength(List<Tok> toks) {
		int len = 0;
		for (Tok tok : toks) len += tok.bytes().length;
		return len;
	}

	/**
	 * Verifies that container nesting and dotted-key depths stay within {@code maxDepth} so every
	 * mutated CST remains parseable by {@link TomlParser} (INV-6).
	 */
	static void validateDepth(Doc doc, int maxDepth) {
		for (Item item : doc.rootItems) {
			if (item instanceof Entry entry) validateEntryDepth(entry, maxDepth);
		}
		for (Section section : doc.sections) {
			if (section.headerKey.keys.size() > maxDepth) {
				throw new TomlEditException("TOML key nesting exceeds " + maxDepth);
			}
			for (Item item : section.items) {
				if (item instanceof Entry entry) validateEntryDepth(entry, maxDepth);
			}
		}
	}

	private static void validateEntryDepth(Entry entry, int maxDepth) {
		if (entry.key.keys.size() > maxDepth) {
			throw new TomlEditException("TOML key nesting exceeds " + maxDepth);
		}
		validateValDepth(entry.value, 0, maxDepth);
	}

	private static void validateValDepth(Val val, int depth, int maxDepth) {
		if (val instanceof Arr arr) {
			int next = depth + 1;
			if (next > maxDepth) {
				throw new TomlEditException("TOML container nesting exceeds " + maxDepth);
			}
			for (ArrayItem item : arr.items) {
				validateValDepth(item.value, next, maxDepth);
			}
		} else if (val instanceof InlineTable tbl) {
			int next = depth + 1;
			if (next > maxDepth) {
				throw new TomlEditException("TOML container nesting exceeds " + maxDepth);
			}
			for (InlineEntry entry : tbl.entries) {
				if (entry.key.keys.size() > maxDepth) {
					throw new TomlEditException("TOML key nesting exceeds " + maxDepth);
				}
				validateValDepth(entry.value, next, maxDepth);
			}
		}
	}

	private static int renderSection(Section section, byte[] out, int offset) {
		for (TriviaLine comment : section.leadingComments) offset = writeToks(comment.tokens, out, offset);
		offset = writeToks(section.leadingWs, out, offset);
		offset = writeTok(section.openBracket, out, offset);
		offset = writeToks(section.preKeyWs, out, offset);
		offset = writeToks(section.headerKey.tokens, out, offset);
		offset = writeToks(section.postKeyWs, out, offset);
		offset = writeTok(section.closeBracket, out, offset);
		offset = writeToks(section.trailingTrivia, out, offset);
		for (Item item : section.items) offset = renderItem(item, out, offset);
		return offset;
	}

	private static int renderItem(Item item, byte[] out, int offset) {
		if (item instanceof TriviaLine trivia) {
			return writeToks(trivia.tokens, out, offset);
		}
		Entry entry = (Entry) item;
		for (TriviaLine comment : entry.leadingComments) offset = writeToks(comment.tokens, out, offset);
		offset = writeToks(entry.leadingWs, out, offset);
		offset = writeToks(entry.key.tokens, out, offset);
		offset = writeToks(entry.eqTrivia, out, offset);
		offset = renderVal(entry.value, out, offset);
		return writeToks(entry.trailingTrivia, out, offset);
	}

	private static int renderVal(Val val, byte[] out, int offset) {
		if (val instanceof Scalar scalar) {
			return writeTok(scalar.token, out, offset);
		}
		if (val instanceof Arr arr) {
			offset = writeTok(arr.openBracket, out, offset);
			for (ArrayItem item : arr.items) {
				offset = writeToks(item.leadingTrivia, out, offset);
				offset = renderVal(item.value, out, offset);
				offset = writeToks(item.postValueTrivia, out, offset);
				if (item.comma != null) offset = writeTok(item.comma, out, offset);
				offset = writeToks(item.trailingSameLineTrivia, out, offset);
			}
			offset = writeToks(arr.trailingTrivia, out, offset);
			return writeTok(arr.closeBracket, out, offset);
		}
		InlineTable tbl = (InlineTable) val;
		offset = writeTok(tbl.openBrace, out, offset);
		for (InlineEntry entry : tbl.entries) {
			offset = writeToks(entry.leadingTrivia, out, offset);
			offset = writeToks(entry.key.tokens, out, offset);
			offset = writeToks(entry.eqTrivia, out, offset);
			offset = renderVal(entry.value, out, offset);
			offset = writeToks(entry.postValueTrivia, out, offset);
			if (entry.comma != null) offset = writeTok(entry.comma, out, offset);
			offset = writeToks(entry.trailingSameLineTrivia, out, offset);
		}
		offset = writeToks(tbl.trailingTrivia, out, offset);
		return writeTok(tbl.closeBrace, out, offset);
	}

	private static int writeToks(List<Tok> toks, byte[] out, int offset) {
		for (Tok tok : toks) offset = writeTok(tok, out, offset);
		return offset;
	}

	private static int writeTok(Tok tok, byte[] out, int offset) {
		byte[] bytes = tok.bytes();
		System.arraycopy(bytes, 0, out, offset, bytes.length);
		return offset + bytes.length;
	}

	// ------------------------------------------------------------------ semantic derivation

	/** Derives the semantic {@link TomlValue.Table} directly from a validated CST without re-parsing. */
	static TomlValue.Table toTable(Doc doc) {
		TomlValue.Table root = TomlValue.table();
		for (Item item : doc.rootItems) {
			if (item instanceof Entry entry) insertDotted(root, entry.key.keys, toValue(entry.value));
		}
		for (Section section : doc.sections) {
			TomlValue.Table target = resolveSectionTarget(root, section.headerKey.keys, section.arrayTable);
			for (Item item : section.items) {
				if (item instanceof Entry entry) insertDotted(target, entry.key.keys, toValue(entry.value));
			}
		}
		return root;
	}

	static TomlValue toValue(Val val) {
		if (val instanceof Scalar s) return s.value;
		if (val instanceof Arr a) {
			TomlValue.Array out = TomlValue.array();
			for (ArrayItem item : a.items) out.add(toValue(item.value));
			return out;
		}
		InlineTable t = (InlineTable) val;
		TomlValue.Table out = TomlValue.table();
		for (InlineEntry entry : t.entries) insertDotted(out, entry.key.keys, toValue(entry.value));
		return out;
	}

	private static TomlValue.Table resolveSectionTarget(TomlValue.Table root, List<String> keys, boolean arrayTable) {
		TomlValue.Table current = root;
		for (int i = 0; i < keys.size() - 1; i++) {
			String seg = keys.get(i);
			TomlValue existing = current.get(seg);
			if (existing == null) {
				TomlValue.Table next = TomlValue.table();
				current.put(seg, next);
				current = next;
			} else if (existing instanceof TomlValue.Table tbl) {
				current = tbl;
			} else if (existing instanceof TomlValue.Array arr) {
				current = (TomlValue.Table) arr.get(arr.size() - 1);
			} else {
				throw new IllegalStateException("validated CST contains non-table parent: " + seg);
			}
		}
		String last = keys.get(keys.size() - 1);
		if (arrayTable) {
			TomlValue existing = current.get(last);
			TomlValue.Array arr;
			if (existing == null) {
				arr = TomlValue.array();
				current.put(last, arr);
			} else {
				arr = (TomlValue.Array) existing;
			}
			TomlValue.Table elem = TomlValue.table();
			arr.add(elem);
			return elem;
		}
		TomlValue existing = current.get(last);
		if (existing == null) {
			TomlValue.Table created = TomlValue.table();
			current.put(last, created);
			return created;
		}
		return (TomlValue.Table) existing;
	}

	private static void insertDotted(TomlValue.Table target, List<String> keys, TomlValue value) {
		TomlValue.Table current = target;
		for (int i = 0; i < keys.size() - 1; i++) {
			String seg = keys.get(i);
			TomlValue existing = current.get(seg);
			if (existing == null) {
				TomlValue.Table next = TomlValue.table();
				current.put(seg, next);
				current = next;
			} else {
				current = (TomlValue.Table) existing;
			}
		}
		String last = keys.get(keys.size() - 1);
		if (current.containsKey(last)) {
			throw new IllegalStateException("corrupted CST: duplicate key '" + last + "'");
		}
		current.put(last, value);
	}
}
