package pl.skidam.tomledit;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/** Public entry point for parsing and canonical TOML writing. */
public final class TomlEdit {
	private TomlEdit() {}

	/**
	 * Parses a UTF-8 TOML 1.1.0 document. Fail-fast; returns either a {@link Document} or a {@link ParseError}.
	 *
	 * @param bytes raw UTF-8 TOML bytes
	 * @return a {@link Document} on success or a positioned {@link ParseError} on syntax/UTF-8 failure
	 */
	public static ParseResult parse(byte[] bytes) {
		Objects.requireNonNull(bytes, "bytes");
		return parseOwned(bytes.clone());
	}

	/**
	 * Parses a TOML 1.1.0 document from a Java {@link String}. Rejects unpaired UTF-16 surrogates as
	 * {@link ErrorKind#INVALID_UTF8} rather than silently replacing them.
	 *
	 * @param text TOML source text
	 * @return a {@link Document} on success or a positioned {@link ParseError} on syntax/UTF-8 failure
	 */
	public static ParseResult parse(String text) {
		Objects.requireNonNull(text, "text");
		CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder()
				.onMalformedInput(CodingErrorAction.REPORT)
				.onUnmappableCharacter(CodingErrorAction.REPORT);
		byte[] bytes;
		try {
			ByteBuffer buf = encoder.encode(CharBuffer.wrap(text));
			bytes = new byte[buf.remaining()];
			buf.get(bytes);
		} catch (CharacterCodingException e) {
			return unpairedSurrogateError(text);
		}
		return parseOwned(bytes);
	}

	/**
	 * Canonical TOML serialization (1.0.0-compatible subset, UTF-8, no BOM, LF).
	 *
	 * @param root root table to serialize
	 * @return UTF-8 canonical TOML bytes
	 */
	public static byte[] canonical(TomlValue.Table root) {
		return CanonicalWriter.write(root, Comments.NONE);
	}

	/**
	 * Canonical TOML serialization with banner and per-path comments at any depth.
	 *
	 * @param root root table to serialize
	 * @param comments banner and per-path comment declarations
	 * @return UTF-8 canonical TOML bytes
	 */
	public static byte[] canonical(TomlValue.Table root, Comments comments) {
		return CanonicalWriter.write(root, comments);
	}

	/**
	 * Canonical TOML serialization as a {@link String} (1.0.0-compatible subset, LF).
	 *
	 * @param root root table to serialize
	 * @return canonical TOML text
	 */
	public static String canonicalString(TomlValue.Table root) {
		return CanonicalWriter.writeString(root, Comments.NONE);
	}

	/**
	 * Canonical TOML serialization as a {@link String} with banner and per-path comments at any depth.
	 *
	 * @param root root table to serialize
	 * @param comments banner and per-path comment declarations
	 * @return canonical TOML text
	 */
	public static String canonicalString(TomlValue.Table root, Comments comments) {
		return CanonicalWriter.writeString(root, comments);
	}

	private static ParseResult parseOwned(byte[] owned) {
		try {
			Cst.Doc doc = TomlParser.parse(owned);
			return new Document(doc, owned);
		} catch (ParseFailure failure) {
			return failure.toParseError();
		}
	}

	private static ParseError unpairedSurrogateError(String text) {
		int line = 1;
		int col = 1;
		int byteOffset = 0;
		for (int i = 0; i < text.length(); ) {
			char c = text.charAt(i);
			if (Character.isHighSurrogate(c)) {
				if (i + 1 < text.length() && Character.isLowSurrogate(text.charAt(i + 1))) {
					i += 2;
					col++;
					byteOffset += 4;
					continue;
				}
				return new ParseError(ErrorKind.INVALID_UTF8, "input contains an unpaired UTF-16 surrogate", line, col, byteOffset);
			}
			if (Character.isLowSurrogate(c)) {
				return new ParseError(ErrorKind.INVALID_UTF8, "input contains an unpaired UTF-16 surrogate", line, col, byteOffset);
			}
			if (c == '\n') {
				line++;
				col = 1;
				byteOffset++;
			} else if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') {
				i++;
				line++;
				col = 1;
				byteOffset += 2;
			} else {
				col++;
				byteOffset += c < 0x80 ? 1 : (c < 0x800 ? 2 : 3);
			}
			i++;
		}
		return new ParseError(ErrorKind.INVALID_UTF8, "input is not valid UTF-8", line, col, byteOffset);
	}
}
