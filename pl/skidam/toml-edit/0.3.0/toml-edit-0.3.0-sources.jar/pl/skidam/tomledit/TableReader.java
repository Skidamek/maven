package pl.skidam.tomledit;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiFunction;

/**
 * Strict, path-aware typed reader over a {@link TomlValue.Table} with recursive unknown-key tracking.
 *
 * <p>Every key read through this reader is marked as consumed. Calling {@link #unknownKeys()}
 * returns the {@link ConfigPath} of every unconsumed key in this table and in any child
 * {@link TableReader}s obtained via {@link #table(String)}, {@link #tableOrEmpty(String)},
 * {@link #tableList(String)}, {@link #tableListOrEmpty(String)}, {@link #tableMap(String)}, or
 * {@link #tableMapOrEmpty(String)}.
 *
 * <p>{@link #raw(String)} and {@link #consume(String)} mark a key known without opening a child
 * reader. When that key holds a table or array, its whole subtree is treated as known and is not
 * reported by {@link #unknownKeys()}; use the typed child accessors when nested unknown-key tracking
 * matters.
 *
 * <p>Type mismatches, integer range overflows, invalid enum names, and missing required keys throw
 * {@link TomlValidationException} carrying the exact {@link ConfigPath}. Not thread-safe.
 */
public final class TableReader {
	private final TomlValue.Table table;
	private final ConfigPath basePath;
	private final Set<String> consumed = new LinkedHashSet<>();
	private final Map<String, TableReader> childTables = new LinkedHashMap<>();
	private final Map<String, List<TableReader>> childLists = new LinkedHashMap<>();

	private TableReader(TomlValue.Table table, ConfigPath basePath) {
		this.table = Objects.requireNonNull(table, "table");
		this.basePath = Objects.requireNonNull(basePath, "basePath");
	}

	/**
	 * Creates a reader rooted at {@link ConfigPath#root()}.
	 *
	 * @param table root TOML table
	 * @return new {@link TableReader}
	 */
	public static TableReader of(TomlValue.Table table) {
		return new TableReader(table, ConfigPath.root());
	}

	/**
	 * Creates a reader rooted at {@code basePath}.
	 *
	 * @param table TOML table
	 * @param basePath path of {@code table} within its document
	 * @return new {@link TableReader}
	 */
	public static TableReader of(TomlValue.Table table, ConfigPath basePath) {
		return new TableReader(table, basePath);
	}

	/**
	 * Returns this reader's base path.
	 *
	 * @return base {@link ConfigPath}
	 */
	public ConfigPath path() {
		return basePath;
	}

	/**
	 * Returns the path of direct member {@code key} under this reader.
	 *
	 * @param key member key
	 * @return child {@link ConfigPath}
	 */
	public ConfigPath pathOf(String key) {
		Objects.requireNonNull(key, "key");
		return basePath.appended(key);
	}

	/**
	 * Returns an unmodifiable insertion-ordered set of all direct keys in this table.
	 *
	 * @return direct key names
	 */
	public Set<String> keys() {
		return Collections.unmodifiableSet(table.members().keySet());
	}

	/**
	 * Returns {@code true} if {@code key} is present in this table (does not mark it consumed).
	 *
	 * @param key member key
	 * @return {@code true} if present
	 */
	public boolean has(String key) {
		Objects.requireNonNull(key, "key");
		return table.containsKey(key);
	}

	/**
	 * Marks {@code key} as consumed without reading its value. If the value is a table or array, the
	 * whole subtree is treated as known and is not reported by {@link #unknownKeys()}.
	 *
	 * @param key member key
	 */
	public void consume(String key) {
		Objects.requireNonNull(key, "key");
		consumed.add(key);
	}

	/**
	 * Returns the raw {@link TomlValue} at {@code key} (or {@code null} if absent) and marks {@code key}
	 * consumed. If the value is a table or array, the whole subtree is treated as known and is not
	 * reported by {@link #unknownKeys()}.
	 *
	 * @param key member key
	 * @return raw value or {@code null}
	 */
	public TomlValue raw(String key) {
		Objects.requireNonNull(key, "key");
		consumed.add(key);
		return table.get(key);
	}

	/**
	 * Recursively collects all unconsumed keys in this table and all child readers opened from it.
	 * Subtrees consumed through {@link #raw(String)} or {@link #consume(String)} are skipped.
	 *
	 * @return immutable list of unknown key paths in document order
	 */
	public List<ConfigPath> unknownKeys() {
		List<ConfigPath> out = new ArrayList<>();
		collectUnknownKeys(out);
		return List.copyOf(out);
	}

	private void collectUnknownKeys(List<ConfigPath> out) {
		for (String key : table.members().keySet()) {
			if (!consumed.contains(key)) {
				out.add(basePath.appended(key));
				continue;
			}
			TableReader child = childTables.get(key);
			if (child != null) {
				child.collectUnknownKeys(out);
				continue;
			}
			List<TableReader> list = childLists.get(key);
			if (list != null) {
				for (TableReader elem : list) {
					elem.collectUnknownKeys(out);
				}
			}
		}
	}

	// ------------------------------------------------------------------ strings

	/**
	 * Reads an optional string at {@code key}.
	 *
	 * @param key member key
	 * @return optional string value
	 */
	public Optional<String> string(String key) {
		return read(key, TomlValue.Str.class, "string").map(TomlValue.Str::value);
	}

	/**
	 * Reads a string at {@code key}, returning {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback when absent
	 * @return string value or {@code defaultValue}
	 */
	public String string(String key, String defaultValue) {
		return string(key).orElse(defaultValue);
	}

	/**
	 * Reads a required string at {@code key}.
	 *
	 * @param key member key
	 * @return string value
	 */
	public String requireString(String key) {
		return string(key).orElseThrow(() -> missingError(key, "string"));
	}

	// ------------------------------------------------------------------ booleans

	/**
	 * Reads an optional boolean at {@code key}.
	 *
	 * @param key member key
	 * @return optional boolean value
	 */
	public Optional<Boolean> bool(String key) {
		return read(key, TomlValue.Bool.class, "boolean").map(TomlValue.Bool::value);
	}

	/**
	 * Reads a boolean at {@code key}, returning {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback when absent
	 * @return boolean value or {@code defaultValue}
	 */
	public boolean bool(String key, boolean defaultValue) {
		return bool(key).orElse(defaultValue);
	}

	/**
	 * Reads a required boolean at {@code key}.
	 *
	 * @param key member key
	 * @return boolean value
	 */
	public boolean requireBool(String key) {
		return bool(key).orElseThrow(() -> missingError(key, "boolean"));
	}

	// ------------------------------------------------------------------ ints

	/**
	 * Reads an optional 32-bit integer at {@code key}. Throws if the TOML integer overflows {@code int}.
	 *
	 * @param key member key
	 * @return optional integer value
	 */
	public Optional<Integer> intVal(String key) {
		return read(key, TomlValue.Int.class, "integer").map(i -> {
			long n = i.value();
			if (n < Integer.MIN_VALUE || n > Integer.MAX_VALUE) {
				throw new TomlValidationException(pathOf(key), "integer out of 32-bit range: " + n);
			}
			return (int) n;
		});
	}

	/**
	 * Reads a 32-bit integer at {@code key}, returning {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback when absent
	 * @return integer value or {@code defaultValue}
	 */
	public int intVal(String key, int defaultValue) {
		return intVal(key).orElse(defaultValue);
	}

	/**
	 * Reads a 32-bit integer at {@code key} validated to {@code [min, max]}, returning {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback when absent
	 * @param min inclusive lower bound
	 * @param max inclusive upper bound
	 * @return validated integer value or {@code defaultValue}
	 */
	public int intVal(String key, int defaultValue, int min, int max) {
		requireRange(min, max);
		Optional<Integer> val = intVal(key);
		if (val.isEmpty()) return defaultValue;
		int n = val.get();
		if (n < min || n > max) {
			throw new TomlValidationException(pathOf(key), "expected integer in [" + min + ", " + max + "], got " + n);
		}
		return n;
	}

	/**
	 * Reads a required 32-bit integer at {@code key}.
	 *
	 * @param key member key
	 * @return integer value
	 */
	public int requireInt(String key) {
		return intVal(key).orElseThrow(() -> missingError(key, "integer"));
	}

	/**
	 * Reads a required 32-bit integer at {@code key} validated to {@code [min, max]}.
	 *
	 * @param key member key
	 * @param min inclusive lower bound
	 * @param max inclusive upper bound
	 * @return validated integer value
	 */
	public int requireInt(String key, int min, int max) {
		requireRange(min, max);
		int n = requireInt(key);
		if (n < min || n > max) {
			throw new TomlValidationException(pathOf(key), "expected integer in [" + min + ", " + max + "], got " + n);
		}
		return n;
	}

	// ------------------------------------------------------------------ longs

	/**
	 * Reads an optional 64-bit integer at {@code key}.
	 *
	 * @param key member key
	 * @return optional long value
	 */
	public Optional<Long> longVal(String key) {
		return read(key, TomlValue.Int.class, "integer").map(TomlValue.Int::value);
	}

	/**
	 * Reads a 64-bit integer at {@code key}, returning {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback when absent
	 * @return long value or {@code defaultValue}
	 */
	public long longVal(String key, long defaultValue) {
		return longVal(key).orElse(defaultValue);
	}

	/**
	 * Reads a 64-bit integer at {@code key} validated to {@code [min, max]}, returning {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback when absent
	 * @param min inclusive lower bound
	 * @param max inclusive upper bound
	 * @return validated long value or {@code defaultValue}
	 */
	public long longVal(String key, long defaultValue, long min, long max) {
		requireRange(min, max);
		Optional<Long> val = longVal(key);
		if (val.isEmpty()) return defaultValue;
		long n = val.get();
		if (n < min || n > max) {
			throw new TomlValidationException(pathOf(key), "expected integer in [" + min + ", " + max + "], got " + n);
		}
		return n;
	}

	/**
	 * Reads a required 64-bit integer at {@code key}.
	 *
	 * @param key member key
	 * @return long value
	 */
	public long requireLong(String key) {
		return longVal(key).orElseThrow(() -> missingError(key, "integer"));
	}

	/**
	 * Reads a required 64-bit integer at {@code key} validated to {@code [min, max]}.
	 *
	 * @param key member key
	 * @param min inclusive lower bound
	 * @param max inclusive upper bound
	 * @return validated long value
	 */
	public long requireLong(String key, long min, long max) {
		requireRange(min, max);
		long n = requireLong(key);
		if (n < min || n > max) {
			throw new TomlValidationException(pathOf(key), "expected integer in [" + min + ", " + max + "], got " + n);
		}
		return n;
	}

	// ------------------------------------------------------------------ doubles

	/**
	 * Reads an optional floating-point value at {@code key}.
	 *
	 * @param key member key
	 * @return optional double value
	 */
	public Optional<Double> doubleVal(String key) {
		return read(key, TomlValue.Float.class, "float").map(TomlValue.Float::value);
	}

	/**
	 * Reads a floating-point value at {@code key}, returning {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback when absent
	 * @return double value or {@code defaultValue}
	 */
	public double doubleVal(String key, double defaultValue) {
		return doubleVal(key).orElse(defaultValue);
	}

	/**
	 * Reads a floating-point value at {@code key} validated to {@code [min, max]} (rejecting {@code NaN}),
	 * returning {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback when absent
	 * @param min inclusive lower bound
	 * @param max inclusive upper bound
	 * @return validated double value or {@code defaultValue}
	 */
	public double doubleVal(String key, double defaultValue, double min, double max) {
		requireRange(min, max);
		Optional<Double> val = doubleVal(key);
		if (val.isEmpty()) return defaultValue;
		double d = val.get();
		if (Double.isNaN(d) || d < min || d > max) {
			throw new TomlValidationException(pathOf(key), "expected float in [" + min + ", " + max + "], got " + d);
		}
		return d;
	}

	/**
	 * Reads a required floating-point value at {@code key}.
	 *
	 * @param key member key
	 * @return double value
	 */
	public double requireDouble(String key) {
		return doubleVal(key).orElseThrow(() -> missingError(key, "float"));
	}

	/**
	 * Reads a required floating-point value at {@code key} validated to {@code [min, max]} (rejecting {@code NaN}).
	 *
	 * @param key member key
	 * @param min inclusive lower bound
	 * @param max inclusive upper bound
	 * @return validated double value
	 */
	public double requireDouble(String key, double min, double max) {
		requireRange(min, max);
		double d = requireDouble(key);
		if (Double.isNaN(d) || d < min || d > max) {
			throw new TomlValidationException(pathOf(key), "expected float in [" + min + ", " + max + "], got " + d);
		}
		return d;
	}

	// ------------------------------------------------------------------ enums

	/**
	 * Reads an optional enum constant at {@code key}. Matches exact names first, then case-insensitively
	 * (with {@code '-'} accepted as {@code '_'}).
	 *
	 * @param <E> enum type
	 * @param key member key
	 * @param enumType target enum class
	 * @return optional enum constant
	 */
	public <E extends Enum<E>> Optional<E> enumVal(String key, Class<E> enumType) {
		Objects.requireNonNull(enumType, "enumType");
		Optional<String> raw = string(key);
		if (raw.isEmpty()) return Optional.empty();
		return Optional.of(parseEnum(key, raw.get(), enumType));
	}

	/**
	 * Reads an enum constant at {@code key}, returning {@code defaultValue} if absent.
	 *
	 * @param <E> enum type
	 * @param key member key
	 * @param enumType target enum class
	 * @param defaultValue fallback when absent
	 * @return enum constant or {@code defaultValue}
	 */
	public <E extends Enum<E>> E enumVal(String key, Class<E> enumType, E defaultValue) {
		return enumVal(key, enumType).orElse(defaultValue);
	}

	/**
	 * Reads a required enum constant at {@code key}.
	 *
	 * @param <E> enum type
	 * @param key member key
	 * @param enumType target enum class
	 * @return enum constant
	 */
	public <E extends Enum<E>> E requireEnum(String key, Class<E> enumType) {
		return enumVal(key, enumType).orElseThrow(() -> missingError(key, enumType.getSimpleName()));
	}

	private <E extends Enum<E>> E parseEnum(ConfigPath path, String text, Class<E> enumType) {
		E[] constants = enumType.getEnumConstants();
		for (E c : constants) {
			if (c.name().equals(text)) return c;
		}
		String normalized = text.replace('-', '_').toUpperCase(Locale.ROOT);
		for (E c : constants) {
			if (c.name().equalsIgnoreCase(text) || c.name().equals(normalized)) return c;
		}
		StringBuilder allowed = new StringBuilder("[");
		for (int i = 0; i < constants.length; i++) {
			if (i > 0) allowed.append(", ");
			allowed.append(constants[i].name());
		}
		allowed.append(']');
		throw new TomlValidationException(path, "expected one of " + allowed + ", got \"" + text + "\"");
	}

	private <E extends Enum<E>> E parseEnum(String key, String text, Class<E> enumType) {
		return parseEnum(pathOf(key), text, enumType);
	}

	// ------------------------------------------------------------------ temporals

	/**
	 * Reads an optional offset date-time at {@code key}.
	 *
	 * @param key member key
	 * @return optional {@link OffsetDateTime}
	 */
	public Optional<OffsetDateTime> offsetDateTime(String key) {
		return read(key, TomlValue.OffsetDateTimeVal.class, "offset date-time").map(TomlValue.OffsetDateTimeVal::value);
	}

	/**
	 * Reads an optional local date-time at {@code key}.
	 *
	 * @param key member key
	 * @return optional {@link LocalDateTime}
	 */
	public Optional<LocalDateTime> localDateTime(String key) {
		return read(key, TomlValue.LocalDateTimeVal.class, "local date-time").map(TomlValue.LocalDateTimeVal::value);
	}

	/**
	 * Reads an optional local date at {@code key}.
	 *
	 * @param key member key
	 * @return optional {@link LocalDate}
	 */
	public Optional<LocalDate> localDate(String key) {
		return read(key, TomlValue.LocalDateVal.class, "local date").map(TomlValue.LocalDateVal::value);
	}

	/**
	 * Reads an optional local time at {@code key}.
	 *
	 * @param key member key
	 * @return optional {@link LocalTime}
	 */
	public Optional<LocalTime> localTime(String key) {
		return read(key, TomlValue.LocalTimeVal.class, "local time").map(TomlValue.LocalTimeVal::value);
	}

	// ------------------------------------------------------------------ arrays

	/**
	 * Reads an optional array of strings at {@code key}. Every element must be a string.
	 *
	 * @param key member key
	 * @return optional mutable list of strings
	 */
	public Optional<List<String>> stringList(String key) {
		return readArray(key, "array of strings", TomlValue.Str.class, "string", (s, p) -> s.value());
	}

	/**
	 * Reads an array of strings at {@code key}, returning a copy of {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback list when absent
	 * @return mutable list of strings
	 */
	public List<String> stringList(String key, List<String> defaultValue) {
		Objects.requireNonNull(defaultValue, "defaultValue");
		return stringList(key).orElseGet(() -> new ArrayList<>(defaultValue));
	}

	/**
	 * Reads a required array of strings at {@code key}. Every element must be a string.
	 *
	 * @param key member key
	 * @return mutable list of strings
	 */
	public List<String> requireStringList(String key) {
		return stringList(key).orElseThrow(() -> missingError(key, "array of strings"));
	}

	/**
	 * Reads an optional array of strings as an insertion-ordered {@link LinkedHashSet}.
	 *
	 * @param key member key
	 * @return optional mutable ordered set of strings
	 */
	public Optional<Set<String>> stringSet(String key) {
		return stringList(key).map(LinkedHashSet::new);
	}

	/**
	 * Reads an array of strings as an insertion-ordered {@link LinkedHashSet}, returning a copy of
	 * {@code defaultValue} if absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback set when absent
	 * @return mutable ordered set of strings
	 */
	public Set<String> stringSet(String key, Set<String> defaultValue) {
		Objects.requireNonNull(defaultValue, "defaultValue");
		return stringSet(key).orElseGet(() -> new LinkedHashSet<>(defaultValue));
	}

	/**
	 * Reads an optional array of 32-bit integers at {@code key}. Throws if any element is not an
	 * integer or overflows {@code int}.
	 *
	 * @param key member key
	 * @return optional mutable list of integers
	 */
	public Optional<List<Integer>> intList(String key) {
		return readArray(key, "array of integers", TomlValue.Int.class, "integer", (n, p) -> {
			long v = n.value();
			if (v < Integer.MIN_VALUE || v > Integer.MAX_VALUE) {
				throw new TomlValidationException(p, "integer out of 32-bit range: " + v);
			}
			return (int) v;
		});
	}

	/**
	 * Reads an array of 32-bit integers at {@code key}, returning a copy of {@code defaultValue} if
	 * absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback list when absent
	 * @return mutable list of integers
	 */
	public List<Integer> intList(String key, List<Integer> defaultValue) {
		Objects.requireNonNull(defaultValue, "defaultValue");
		return intList(key).orElseGet(() -> new ArrayList<>(defaultValue));
	}

	/**
	 * Reads an optional array of 64-bit integers at {@code key}. Every element must be an integer.
	 *
	 * @param key member key
	 * @return optional mutable list of longs
	 */
	public Optional<List<Long>> longList(String key) {
		return readArray(key, "array of integers", TomlValue.Int.class, "integer", (n, p) -> n.value());
	}

	/**
	 * Reads an array of 64-bit integers at {@code key}, returning a copy of {@code defaultValue} if
	 * absent.
	 *
	 * @param key member key
	 * @param defaultValue fallback list when absent
	 * @return mutable list of longs
	 */
	public List<Long> longList(String key, List<Long> defaultValue) {
		Objects.requireNonNull(defaultValue, "defaultValue");
		return longList(key).orElseGet(() -> new ArrayList<>(defaultValue));
	}

	/**
	 * Reads a required array of 64-bit integers at {@code key}. Every element must be an integer.
	 *
	 * @param key member key
	 * @return mutable list of longs
	 */
	public List<Long> requireLongList(String key) {
		return longList(key).orElseThrow(() -> missingError(key, "array of integers"));
	}

	/**
	 * Reads an optional array of enum constants at {@code key}. Uses the same matching rules as
	 * {@link #enumVal(String, Class)}.
	 *
	 * @param <E> enum type
	 * @param key member key
	 * @param enumType target enum class
	 * @return optional mutable list of enum constants
	 */
	public <E extends Enum<E>> Optional<List<E>> enumList(String key, Class<E> enumType) {
		Objects.requireNonNull(enumType, "enumType");
		return readArray(key, "array of " + enumType.getSimpleName(), TomlValue.Str.class, "string",
				(s, p) -> parseEnum(p, s.value(), enumType));
	}

	/**
	 * Reads an array of enum constants at {@code key}, returning a copy of {@code defaultValue} if
	 * absent.
	 *
	 * @param <E> enum type
	 * @param key member key
	 * @param enumType target enum class
	 * @param defaultValue fallback list when absent
	 * @return mutable list of enum constants
	 */
	public <E extends Enum<E>> List<E> enumList(String key, Class<E> enumType, List<E> defaultValue) {
		Objects.requireNonNull(defaultValue, "defaultValue");
		return enumList(key, enumType).orElseGet(() -> new ArrayList<>(defaultValue));
	}

	/**
	 * Reads an optional array of tables (such as {@code [[array-of-tables]]}) as child {@link TableReader}s.
	 * Child readers participate in {@link #unknownKeys()}.
	 *
	 * @param key member key
	 * @return optional immutable list of child {@link TableReader}s
	 */
	public Optional<List<TableReader>> tableList(String key) {
		Objects.requireNonNull(key, "key");
		List<TableReader> cached = childLists.get(key);
		if (cached != null) return Optional.of(cached);
		Optional<List<TableReader>> readers = readArray(key, "array of tables", TomlValue.Table.class, "table", TableReader::new);
		if (readers.isEmpty()) return Optional.empty();
		List<TableReader> immutable = List.copyOf(readers.get());
		childLists.put(key, immutable);
		return Optional.of(immutable);
	}

	/**
	 * Reads an array of tables at {@code key}, returning an empty list if absent.
	 *
	 * @param key member key
	 * @return immutable list of child {@link TableReader}s
	 */
	public List<TableReader> tableListOrEmpty(String key) {
		return tableList(key).orElse(List.of());
	}

	/**
	 * Reads a required array of tables at {@code key}.
	 *
	 * @param key member key
	 * @return immutable list of child {@link TableReader}s
	 */
	public List<TableReader> requireTableList(String key) {
		return tableList(key).orElseThrow(() -> missingError(key, "array of tables"));
	}

	// ------------------------------------------------------------------ nested tables

	/**
	 * Reads an optional nested table as a child {@link TableReader}.
	 * Repeated calls for the same key return the same child reader so consumed keys accumulate.
	 *
	 * @param key member key
	 * @return optional child {@link TableReader}
	 */
	public Optional<TableReader> table(String key) {
		Objects.requireNonNull(key, "key");
		TableReader cached = childTables.get(key);
		if (cached != null) return Optional.of(cached);
		TomlValue v = raw(key);
		if (v == null) return Optional.empty();
		if (!(v instanceof TomlValue.Table t)) throw typeError(key, "table", v);
		TableReader child = new TableReader(t, pathOf(key));
		childTables.put(key, child);
		return Optional.of(child);
	}

	/**
	 * Reads a required nested table as a child {@link TableReader}.
	 *
	 * @param key member key
	 * @return child {@link TableReader}
	 */
	public TableReader requireTable(String key) {
		return table(key).orElseThrow(() -> missingError(key, "table"));
	}

	/**
	 * Reads a nested table at {@code key}, or returns an empty reader at {@code pathOf(key)} if absent.
	 * Still throws {@link TomlValidationException} if {@code key} is present with a non-table value.
	 *
	 * @param key member key
	 * @return child {@link TableReader}
	 */
	public TableReader tableOrEmpty(String key) {
		return table(key).orElseGet(() -> new TableReader(TomlValue.table(), pathOf(key)));
	}

	/**
	 * Reads an optional table at {@code key} whose entries are all child tables, preserving declaration order.
	 * Every child table participates in {@link #unknownKeys()}. This is the {@code [groups.<id>]} shape;
	 * for {@code [[groups]]} arrays of tables use {@link #tableList(String)}.
	 *
	 * @param key member key
	 * @return optional ordered map from child key to child {@link TableReader}
	 */
	public Optional<Map<String, TableReader>> tableMap(String key) {
		Optional<TableReader> parentOpt = table(key);
		if (parentOpt.isEmpty()) return Optional.empty();
		TableReader parent = parentOpt.get();
		LinkedHashMap<String, TableReader> entries = new LinkedHashMap<>();
		for (String childKey : parent.keys()) {
			entries.put(childKey, parent.requireTable(childKey));
		}
		return Optional.of(Collections.unmodifiableMap(entries));
	}

	/**
	 * Reads a map of child tables at {@code key}, returning an empty map if absent. This is the
	 * {@code [groups.<id>]} shape; {@code [[groups]]} arrays of tables are read with
	 * {@link #tableList(String)} and are rejected here. Still throws {@link TomlValidationException}
	 * if {@code key} or any entry inside it is not a table.
	 *
	 * @param key member key
	 * @return ordered map from child key to child {@link TableReader}
	 */
	public Map<String, TableReader> tableMapOrEmpty(String key) {
		return tableMap(key).orElse(Map.of());
	}

	/**
	 * Reads a required map of child tables at {@code key}.
	 *
	 * @param key member key
	 * @return ordered map from child key to child {@link TableReader}
	 */
	public Map<String, TableReader> requireTableMap(String key) {
		return tableMap(key).orElseThrow(() -> missingError(key, "table"));
	}

	// ------------------------------------------------------------------ internals & error formatting

	private static void requireRange(long min, long max) {
		if (min > max) throw new IllegalArgumentException("min (" + min + ") must not exceed max (" + max + ")");
	}

	private static void requireRange(double min, double max) {
		if (Double.isNaN(min) || Double.isNaN(max) || min > max) {
			throw new IllegalArgumentException("invalid bounds [" + min + ", " + max + "]");
		}
	}

	private <T extends TomlValue> Optional<T> read(String key, Class<T> type, String expected) {
		TomlValue v = raw(key);
		if (v == null) return Optional.empty();
		if (type.isInstance(v)) return Optional.of(type.cast(v));
		throw typeError(key, expected, v);
	}

	private <T extends TomlValue, R> Optional<List<R>> readArray(String key, String arrayExpected,
			Class<T> elemType, String elemExpected, BiFunction<T, ConfigPath, R> mapper) {
		Optional<TomlValue.Array> arrOpt = read(key, TomlValue.Array.class, arrayExpected);
		if (arrOpt.isEmpty()) return Optional.empty();
		TomlValue.Array arr = arrOpt.get();
		List<R> out = new ArrayList<>(arr.size());
		ConfigPath arrPath = pathOf(key);
		for (int i = 0; i < arr.size(); i++) {
			TomlValue elem = arr.get(i);
			ConfigPath elemPath = arrPath.appended(i);
			if (!elemType.isInstance(elem)) {
				throw new TomlValidationException(elemPath, "expected " + elemExpected + ", got " + kindName(elem));
			}
			out.add(mapper.apply(elemType.cast(elem), elemPath));
		}
		return Optional.of(out);
	}

	private TomlValidationException typeError(String key, String expected, TomlValue actual) {
		return new TomlValidationException(pathOf(key), "expected " + expected + ", got " + kindName(actual));
	}

	private TomlValidationException missingError(String key, String expected) {
		return new TomlValidationException(pathOf(key), "missing required " + expected);
	}

	private static String kindName(TomlValue value) {
		if (value instanceof TomlValue.Table) return "table";
		if (value instanceof TomlValue.Array) return "array";
		if (value instanceof TomlValue.Str) return "string";
		if (value instanceof TomlValue.Int) return "integer";
		if (value instanceof TomlValue.Float) return "float";
		if (value instanceof TomlValue.Bool) return "boolean";
		if (value instanceof TomlValue.OffsetDateTimeVal) return "offset date-time";
		if (value instanceof TomlValue.LocalDateTimeVal) return "local date-time";
		if (value instanceof TomlValue.LocalDateVal) return "local date";
		if (value instanceof TomlValue.LocalTimeVal) return "local time";
		return value.getClass().getSimpleName();
	}
}
