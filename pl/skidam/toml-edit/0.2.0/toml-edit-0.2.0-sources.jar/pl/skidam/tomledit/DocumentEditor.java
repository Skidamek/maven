package pl.skidam.tomledit;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * High-level document operations: {@code reconcile}, {@code ensure}, {@code rename}, and
 * {@code remove}, composed over {@link CstNavigator}, {@link CstEntryEditor},
 * {@link CstSectionEditor}, {@link CstInlineTableEditor}, and {@link CstArrayEditor}.
 */
final class DocumentEditor {
	private DocumentEditor() {}

	static void reconcile(Cst.Doc doc, TomlValue.Table model, ReconcilePolicy policy) {
		TomlValue.Table current = Cst.toTable(doc);
		reconcileTable(doc, ConfigPath.root(), current, model, policy);
	}

	static void reconcileTable(Cst.Doc doc, ConfigPath path, TomlValue.Table current, TomlValue.Table model, ReconcilePolicy policy) {
		for (Map.Entry<String, TomlValue> entry : current.members().entrySet()) {
			String key = entry.getKey();
			TomlValue modelVal = model.get(key);
			if (modelVal == null) continue; // unknown/stale keys in document stay untouched
			TomlValue docVal = entry.getValue();
			if (docVal.equals(modelVal)) continue;

			ConfigPath childPath = path.appended(key);
			if (docVal instanceof TomlValue.Table docTbl && modelVal instanceof TomlValue.Table modelTbl) {
				reconcileTable(doc, childPath, docTbl, modelTbl, policy);
			} else if (docVal instanceof TomlValue.Array docArr && modelVal instanceof TomlValue.Array modelArr) {
				reconcileArrayAtPath(doc, childPath, docArr, modelArr, policy);
			} else {
				CstEntryEditor.set(doc, childPath, modelVal);
			}
		}
	}

	private static void reconcileArrayAtPath(Cst.Doc doc, ConfigPath path, TomlValue.Array docArr, TomlValue.Array modelArr, ReconcilePolicy policy) {
		CstNavigator.Target target = CstNavigator.resolve(doc, path);
		if (target == null) return;
		byte[] docNl = CstEntryEditor.detectDocNewline(doc);
		Cst.Arr arr = target.asArray();
		if (arr != null) {
			CstArrayEditor.reconcile(arr, modelArr, docNl, policy);
			return;
		}
		if (target instanceof CstNavigator.ArrayOfTablesTarget) {
			CstSectionEditor.reconcileArrayOfTables(doc, path, docArr, modelArr, policy);
			return;
		}
		CstEntryEditor.set(doc, path, modelArr);
	}

	static void ensure(Cst.Doc doc, ConfigPath path, TomlValue defaultValue, String comment) {
		String key = requireMemberPath(path);
		if (CstNavigator.resolve(doc, path) != null) return;
		ensureAncestors(doc, path.parent());
		CstEntryEditor.insertMember(doc, path.parent(), key, defaultValue, comment, null);
	}

	static void rename(Cst.Doc doc, ConfigPath from, ConfigPath to) {
		requireMemberPath(from);
		String toKey = requireMemberPath(to);
		if (from.equals(to)) return;
		if (to.startsWith(from) || from.startsWith(to)) {
			throw new TomlEditException("rename source and destination cannot overlap: " + from + " -> " + to, to);
		}
		CstNavigator.Target fromTarget = CstNavigator.resolve(doc, from);
		if (fromTarget == null) return; // absent source: no-op

		validateDestinationAncestors(doc, to.parent());

		if (CstNavigator.resolve(doc, to) != null) {
			// Destination already present: drop source, leave destination untouched
			CstEntryEditor.removeMember(doc, from);
			return;
		}

		// Case 1: Same-parent Entry rename -> rename final key token in place (preserves order, value CST, comments)
		if (from.parent().equals(to.parent()) && fromTarget instanceof CstNavigator.EntryTarget et) {
			CstEntryEditor.replaceKeySegmentAt(et.entry().key, et.entry().key.keys.size() - 1, toKey);
			return;
		}

		// Case 2: Same-parent InlineEntry rename -> rename final key token in place
		if (from.parent().equals(to.parent()) && fromTarget instanceof CstNavigator.InlineEntryTarget iet) {
			CstEntryEditor.replaceKeySegmentAt(iet.entry().key, iet.entry().key.keys.size() - 1, toKey);
			return;
		}

		// Case 3: Same-parent VirtualInlineTableTarget rename -> rewrite dotted prefix in place
		if (from.parent().equals(to.parent()) && fromTarget instanceof CstNavigator.VirtualInlineTableTarget vit) {
			CstInlineTableEditor.renameVirtualTablePrefix(vit, toKey);
			return;
		}

		CstNavigator.Target destParent = CstNavigator.resolve(doc, to.parent());
		boolean destIsInline = destParent != null && destParent.isInlineTableTarget();

		// Case 4: Section, [[array-of-tables]], or VirtualTableTarget -> rewrite headers & dotted entries losslessly
		if (!destIsInline && (fromTarget instanceof CstNavigator.SectionTarget
				|| fromTarget instanceof CstNavigator.ArrayOfTablesTarget
				|| fromTarget instanceof CstNavigator.VirtualTableTarget)) {
			CstSectionEditor.renameSubtree(doc, from, to);
			return;
		}

		// Case 5: Cross-parent Entry move -> carry Cst.Val verbatim when destination is not inline
		TomlValue carried = CstNavigator.valueAt(Cst.toTable(doc), from);
		Optional<String> carriedComment = CstEntryEditor.attachedComment(doc, from);
		String trailingNote = (fromTarget instanceof CstNavigator.EntryTarget et)
				? CstEntryEditor.extractTrailingNote(et.entry()) : null;
		Cst.Val preservedVal = (!destIsInline && fromTarget instanceof CstNavigator.EntryTarget et)
				? et.entry().value : null;

		CstEntryEditor.removeMember(doc, from);
		ensureAncestors(doc, to.parent());
		CstEntryEditor.insertMemberValue(doc, to.parent(), toKey, carried, preservedVal, carriedComment.orElse(null), trailingNote);
	}

	static void remove(Cst.Doc doc, ConfigPath path) {
		requireMemberPath(path);
		if (CstNavigator.resolve(doc, path) == null) return;
		CstEntryEditor.removeMember(doc, path);
	}

	static void ensureAncestors(Cst.Doc doc, ConfigPath prefix) {
		walkAncestors(doc, prefix, true);
	}

	private static void validateDestinationAncestors(Cst.Doc doc, ConfigPath prefix) {
		walkAncestors(doc, prefix, false);
	}

	private static void walkAncestors(Cst.Doc doc, ConfigPath prefix, boolean createMissing) {
		List<ConfigPath.Segment> segs = prefix.segments();
		ConfigPath cur = ConfigPath.root();
		for (int i = 0; i < segs.size(); i++) {
			ConfigPath.Segment seg = segs.get(i);
			boolean nextIsIndex = (i + 1 < segs.size()) && (segs.get(i + 1) instanceof ConfigPath.Segment.Index);
			if (seg instanceof ConfigPath.Segment.Index idx) {
				ConfigPath next = cur.appended(idx.index());
				CstNavigator.Target t = CstNavigator.resolve(doc, next);
				if (t == null) {
					throw new TomlEditException((createMissing ? "cannot materialize missing array element: " : "destination array element does not exist: ") + next, next);
				}
				if (!nextIsIndex && !t.isTableLike()) {
					throw new TomlEditException((createMissing ? "ancestor is not a table: " : "destination ancestor is not a table: ") + next, next);
				}
				cur = next;
			} else if (seg instanceof ConfigPath.Segment.Key k) {
				ConfigPath next = cur.appended(k.name());
				CstNavigator.Target t = CstNavigator.resolve(doc, next);
				if (t == null) {
					if (nextIsIndex) {
						throw new TomlEditException((createMissing ? "cannot materialize missing array: " : "destination array does not exist: ") + next, next);
					}
					if (createMissing) {
						CstEntryEditor.insertMember(doc, cur, k.name(), TomlValue.table(), null, null);
					}
				} else if (!nextIsIndex && !t.isTableLike()) {
					throw new TomlEditException((createMissing ? "ancestor is not a table: " : "destination ancestor is not a table: ") + next, next);
				} else if (nextIsIndex && !t.isArrayLike()) {
					throw new TomlEditException((createMissing ? "ancestor is not an array: " : "destination ancestor is not an array: ") + next, next);
				}
				cur = next;
			}
		}
	}

	private static String requireMemberPath(ConfigPath path) {
		if (path.isRoot() || !(path.last() instanceof ConfigPath.Segment.Key key)) {
			throw new TomlEditException("operation addresses table members, not root or array elements: " + path, path);
		}
		return key.name();
	}
}
