package pl.skidam.tomledit;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Comment declarations for canonical TOML generation: an optional top-of-file banner and
 * per-path comments for root keys, nested keys, and table headers at any depth.
 */
public final class Comments {
	/** Empty comment specification with no banner and no path comments. */
	public static final Comments NONE = new Comments(null, Map.of());

	private final String banner;
	private final Map<ConfigPath, String> byPath;

	/**
	 * Creates a comment specification with an optional banner and per-path comment map.
	 *
	 * @param banner top-of-file banner text, or {@code null} for none
	 * @param byPath map from {@link ConfigPath} to comment text (neither keys nor values may be {@code null})
	 */
	public Comments(String banner, Map<ConfigPath, String> byPath) {
		Objects.requireNonNull(byPath, "byPath");
		LinkedHashMap<ConfigPath, String> copy = new LinkedHashMap<>(byPath.size());
		for (var entry : byPath.entrySet()) {
			ConfigPath key = Objects.requireNonNull(entry.getKey(), "comment path");
			String value = Objects.requireNonNull(entry.getValue(), "comment text");
			copy.put(key, value);
		}
		this.banner = banner;
		this.byPath = Collections.unmodifiableMap(copy);
	}

	/**
	 * Creates a comment specification with an optional banner and per-path comment map.
	 *
	 * @param banner top-of-file banner text, or {@code null} for none
	 * @param byPath map from {@link ConfigPath} to comment text
	 * @return immutable {@link Comments} instance
	 */
	public static Comments of(String banner, Map<ConfigPath, String> byPath) {
		return new Comments(banner, byPath);
	}

	/**
	 * Creates a new fluent {@link Builder}.
	 *
	 * @return a new builder
	 */
	public static Builder builder() {
		return new Builder();
	}

	/**
	 * Returns the top-of-file banner text, or {@code null} if none was set.
	 *
	 * @return banner text or {@code null}
	 */
	public String banner() {
		return banner;
	}

	/**
	 * Returns an unmodifiable view of the per-path comment map.
	 *
	 * @return unmodifiable map of paths to comment text
	 */
	public Map<ConfigPath, String> byPath() {
		return byPath;
	}

	/**
	 * Looks up the comment declared for {@code path}.
	 *
	 * @param path target path
	 * @return optional comment text
	 */
	public java.util.Optional<String> get(ConfigPath path) {
		return java.util.Optional.ofNullable(byPath.get(path));
	}

	@Override
	public boolean equals(Object o) {
		return o instanceof Comments other
				&& Objects.equals(banner, other.banner)
				&& byPath.equals(other.byPath);
	}

	@Override
	public int hashCode() {
		return Objects.hash(banner, byPath);
	}

	/** Fluent builder for {@link Comments}. */
	public static final class Builder {
		private String banner;
		private final LinkedHashMap<ConfigPath, String> byPath = new LinkedHashMap<>();

		/** Creates an empty builder. */
		public Builder() {}

		/**
		 * Sets the top-of-file banner text.
		 *
		 * @param banner banner text, or {@code null} to clear
		 * @return this builder
		 */
		public Builder banner(String banner) {
			this.banner = banner;
			return this;
		}

		/**
		 * Associates {@code comment} with {@code path}.
		 *
		 * @param path target path
		 * @param comment comment text
		 * @return this builder
		 */
		public Builder put(ConfigPath path, String comment) {
			Objects.requireNonNull(path, "path");
			Objects.requireNonNull(comment, "comment");
			byPath.put(path, comment);
			return this;
		}

		/**
		 * Builds an immutable {@link Comments} instance.
		 *
		 * @return built {@link Comments}
		 */
		public Comments build() {
			return new Comments(banner, byPath);
		}
	}
}
