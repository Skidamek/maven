package pl.skidam.tomledit;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Surgical array editor over {@link Cst.Arr}: handles {@code arrayInsert}, {@code arrayRemove},
 * and LCS reconciliation ({@link ReconcilePolicy#SYNC} and {@link ReconcilePolicy#INSERT_ONLY})
 * while preserving inline vs. vertical layout, indentation, line endings, and per-element comments.
 */
final class CstArrayEditor {
	private CstArrayEditor() {}

	static void arrayInsert(Cst.Arr arr, int index, TomlValue value, byte[] docNl) {
		if (index < 0 || index > arr.items.size()) {
			throw new TomlEditException("array index " + index + " out of range (size " + arr.items.size() + ")");
		}
		Cst.Val newVal = Cst.parseInlineVal(value);
		boolean vertical = isVertical(arr);
		byte[] nl = detectNewline(arr, docNl);

		if (arr.items.isEmpty()) {
			if (!vertical) {
				arr.trailingTrivia.clear();
				arr.items.add(new Cst.ArrayItem(List.of(), newVal, List.of(), null, List.of()));
				return;
			}
			byte[] indent = detectCloserIndentPlusTwo(arr);
			List<Cst.Tok> leading = new ArrayList<>();
			leading.add(new Cst.Tok(Cst.TokKind.NL, nl));
			if (indent.length > 0) leading.add(new Cst.Tok(Cst.TokKind.WS, indent));
			Cst.Tok comma = new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','});
			List<Cst.Tok> sameLine = List.of(new Cst.Tok(Cst.TokKind.NL, nl));
			// Keep closer indent in trailingTrivia, drop leading newlines already placed on item
			stripLeadingNewlines(arr.trailingTrivia);
			arr.items.add(new Cst.ArrayItem(leading, newVal, List.of(), comma, sameLine));
			return;
		}

		if (!vertical) {
			insertInline(arr, index, newVal);
		} else {
			insertVertical(arr, index, newVal, nl);
		}
	}

	static void arrayRemove(Cst.Arr arr, int index) {
		if (index < 0 || index >= arr.items.size()) {
			throw new TomlEditException("array index " + index + " out of range (size " + arr.items.size() + ")");
		}
		if (arr.items.size() == 1) {
			arr.items.clear();
			arr.trailingTrivia.clear();
			return;
		}
		boolean vertical = isVertical(arr);
		Cst.ArrayItem removed = arr.items.remove(index);
		if (!vertical) {
			if (index == 0) {
				// New first item should not have leading separator space from old comma
				arr.items.get(0).leadingTrivia.clear();
			} else if (index == arr.items.size()) {
				// Removed the last element: strip comma from the new last element in inline arrays
				Cst.ArrayItem newLast = arr.items.get(arr.items.size() - 1);
				newLast.comma = null;
			}
		} else {
			// If index 0 was removed and the new index 0 didn't start with a newline (e.g. opened right after '['),
			// ensure it starts cleanly on a new line if removed had leading newline
			if (index == 0 && !startsWithNewline(arr.items.get(0).leadingTrivia) && startsWithNewline(removed.leadingTrivia)) {
				byte[] nl = firstNewline(removed.leadingTrivia);
				if (nl != null) arr.items.get(0).leadingTrivia.add(0, new Cst.Tok(Cst.TokKind.NL, nl));
			}
			// If we removed the last item and the new last item has no trailing newline, preserve one before ']'
			if (index == arr.items.size()) {
				Cst.ArrayItem newLast = arr.items.get(arr.items.size() - 1);
				if (!Cst.endsWithNewline(newLast.trailingSameLineTrivia) && !startsWithNewline(arr.trailingTrivia)) {
					byte[] nl = detectNewline(arr, new byte[] {'\n'});
					newLast.trailingSameLineTrivia.add(new Cst.Tok(Cst.TokKind.NL, nl));
				}
			}
		}
	}

	static void reconcile(Cst.Arr arr, TomlValue.Array target, byte[] docNl, ReconcilePolicy policy) {
		TomlValue currentVal = Cst.toValue(arr);
		if (currentVal.equals(target)) return;

		List<TomlValue> docElems = ((TomlValue.Array) currentVal).elements();
		List<TomlValue> targetElems = target.elements();
		List<int[]> matches = Lcs.matches(docElems, targetElems);

		if (matches == null) {
			// Over LCS budget
			if (policy == ReconcilePolicy.SYNC) {
				arr.items.clear();
				arr.trailingTrivia.clear();
				for (int i = 0; i < targetElems.size(); i++) {
					arrayInsert(arr, i, targetElems.get(i), docNl);
				}
			} else {
				// INSERT_ONLY budget fallback: append only target elements not already present (idempotent!)
				Set<TomlValue> existing = new HashSet<>(docElems);
				for (TomlValue elem : targetElems) {
					if (!existing.contains(elem)) {
						arrayInsert(arr, arr.items.size(), elem, docNl);
						existing.add(elem);
					}
				}
			}
			return;
		}

		if (policy == ReconcilePolicy.SYNC) {
			// Pass 1: remove unmatched doc elements right-to-left (preserves kept elements' comments and layout)
			boolean[] docMatched = new boolean[docElems.size()];
			boolean[] targetMatched = new boolean[targetElems.size()];
			for (int[] pair : matches) {
				docMatched[pair[0]] = true;
				targetMatched[pair[1]] = true;
			}
			for (int i = docElems.size() - 1; i >= 0; i--) {
				if (!docMatched[i]) arrayRemove(arr, i);
			}
			// Pass 2: insert unmatched target elements at their exact target indices left-to-right
			for (int j = 0; j < targetElems.size(); j++) {
				if (!targetMatched[j]) arrayInsert(arr, j, targetElems.get(j), docNl);
			}
		} else {
			// INSERT_ONLY: insert unmatched target elements ahead of the next matched doc element (or at tail)
			int inserted = 0;
			int prevTarget = -1;
			for (int[] pair : matches) {
				int docPos = pair[0] + inserted;
				int targetPos = pair[1];
				for (int j = prevTarget + 1; j < targetPos; j++) {
					arrayInsert(arr, docPos, targetElems.get(j), docNl);
					docPos++;
					inserted++;
				}
				prevTarget = targetPos;
			}
			for (int j = prevTarget + 1; j < targetElems.size(); j++) {
				arrayInsert(arr, arr.items.size(), targetElems.get(j), docNl);
			}
		}
	}

	private static void insertInline(Cst.Arr arr, int index, Cst.Val newVal) {
		boolean spaceAfterComma = hasSpaceAfterComma(arr);
		Cst.Tok comma = new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','});
		if (index < arr.items.size()) {
			List<Cst.Tok> leading = index == 0 ? List.of() : (spaceAfterComma ? List.of(new Cst.Tok(Cst.TokKind.WS, new byte[] {' '})) : List.of());
			if (index == 0 && spaceAfterComma && arr.items.get(0).leadingTrivia.isEmpty()) {
				arr.items.get(0).leadingTrivia.add(new Cst.Tok(Cst.TokKind.WS, new byte[] {' '}));
			}
			arr.items.add(index, new Cst.ArrayItem(leading, newVal, List.of(), comma, List.of()));
		} else {
			// Append at end
			Cst.ArrayItem prev = arr.items.get(arr.items.size() - 1);
			if (prev.comma == null) prev.comma = comma;
			List<Cst.Tok> leading = spaceAfterComma ? List.of(new Cst.Tok(Cst.TokKind.WS, new byte[] {' '})) : List.of();
			arr.items.add(new Cst.ArrayItem(leading, newVal, List.of(), null, List.of()));
		}
	}

	private static void insertVertical(Cst.Arr arr, int index, Cst.Val newVal, byte[] nl) {
		Cst.ArrayItem neighbor = index < arr.items.size() ? arr.items.get(index) : arr.items.get(arr.items.size() - 1);
		byte[] indent = detectItemIndent(neighbor);
		boolean trailingComma = arr.items.get(arr.items.size() - 1).comma != null;

		if (index < arr.items.size()) {
			List<Cst.Tok> leading = new ArrayList<>();
			if (index == 0 && startsWithNewline(neighbor.leadingTrivia)) {
				leading.add(new Cst.Tok(Cst.TokKind.NL, nl));
				// Remove the opening newline from old index 0 since our item's trailingSameLineTrivia ends with NL
				neighbor.leadingTrivia.remove(0);
			}
			if (indent.length > 0) leading.add(new Cst.Tok(Cst.TokKind.WS, indent));
			Cst.Tok comma = new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','});
			List<Cst.Tok> sameLine = List.of(new Cst.Tok(Cst.TokKind.NL, nl));
			arr.items.add(index, new Cst.ArrayItem(leading, newVal, List.of(), comma, sameLine));
		} else {
			// Append at end of vertical array
			Cst.ArrayItem prev = arr.items.get(arr.items.size() - 1);
			if (prev.comma == null) {
				// Move only same-line trivia (up to and including first NL) after the new comma;
				// leave any closer indent in arr.trailingTrivia so no blank whitespace line is created.
				List<Cst.Tok> moved = Cst.extractSameLineFromTrivia(prev.postValueTrivia, arr.trailingTrivia);
				prev.comma = new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','});
				prev.trailingSameLineTrivia.addAll(moved);
			}
			if (!Cst.endsWithNewline(prev.trailingSameLineTrivia)) {
				prev.trailingSameLineTrivia.add(new Cst.Tok(Cst.TokKind.NL, nl));
			}
			List<Cst.Tok> leading = new ArrayList<>();
			if (indent.length > 0) leading.add(new Cst.Tok(Cst.TokKind.WS, indent));
			Cst.Tok comma = trailingComma ? new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','}) : null;
			List<Cst.Tok> sameLine = List.of(new Cst.Tok(Cst.TokKind.NL, nl));
			arr.items.add(new Cst.ArrayItem(leading, newVal, List.of(), comma, sameLine));
		}
	}

	static boolean isVertical(Cst.Arr arr) {
		for (Cst.ArrayItem item : arr.items) {
			if (Cst.hasNewline(item.leadingTrivia) || Cst.hasNewline(item.postValueTrivia) || Cst.hasNewline(item.trailingSameLineTrivia)) {
				return true;
			}
		}
		return Cst.hasNewline(arr.trailingTrivia);
	}

	private static boolean startsWithNewline(List<Cst.Tok> toks) {
		return !toks.isEmpty() && toks.get(0).kind() == Cst.TokKind.NL;
	}

	private static byte[] firstNewline(List<Cst.Tok> toks) {
		for (Cst.Tok tok : toks) {
			if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
		}
		return null;
	}

	private static byte[] detectNewline(Cst.Arr arr, byte[] fallback) {
		for (Cst.ArrayItem item : arr.items) {
			byte[] nl = firstNewline(item.trailingSameLineTrivia);
			if (nl != null) return nl;
			nl = firstNewline(item.leadingTrivia);
			if (nl != null) return nl;
		}
		byte[] nl = firstNewline(arr.trailingTrivia);
		return nl != null ? nl : fallback;
	}

	private static boolean hasSpaceAfterComma(Cst.Arr arr) {
		for (int i = 1; i < arr.items.size(); i++) {
			List<Cst.Tok> lead = arr.items.get(i).leadingTrivia;
			if (!lead.isEmpty() && lead.get(0).kind() == Cst.TokKind.WS) return true;
			return false;
		}
		return true;
	}

	private static byte[] detectItemIndent(Cst.ArrayItem item) {
		List<Cst.Tok> lead = item.leadingTrivia;
		if (!lead.isEmpty() && lead.get(lead.size() - 1).kind() == Cst.TokKind.WS) {
			return lead.get(lead.size() - 1).bytes();
		}
		return new byte[] {' ', ' '};
	}

	private static byte[] detectCloserIndentPlusTwo(Cst.Arr arr) {
		List<Cst.Tok> trail = arr.trailingTrivia;
		if (!trail.isEmpty() && trail.get(trail.size() - 1).kind() == Cst.TokKind.WS) {
			byte[] base = trail.get(trail.size() - 1).bytes();
			byte[] out = new byte[base.length + 2];
			System.arraycopy(base, 0, out, 0, base.length);
			out[base.length] = ' ';
			out[base.length + 1] = ' ';
			return out;
		}
		return new byte[] {' ', ' '};
	}

	private static void stripLeadingNewlines(List<Cst.Tok> toks) {
		while (!toks.isEmpty() && toks.get(0).kind() == Cst.TokKind.NL) {
			toks.remove(0);
		}
	}
}
