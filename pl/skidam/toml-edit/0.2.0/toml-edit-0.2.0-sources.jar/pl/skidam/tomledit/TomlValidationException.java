package pl.skidam.tomledit;

import java.util.Objects;

/**
 * Thrown when a parsed TOML tree violates expected types, value bounds, or required keys during
 * typed reading with {@link TableReader}.
 */
public final class TomlValidationException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private final transient ConfigPath path;

	/**
	 * Creates a validation exception for {@code path}.
	 *
	 * @param path offending config path (non-null)
	 * @param detail human-readable validation failure description
	 */
	public TomlValidationException(ConfigPath path, String detail) {
		this(path, detail, null);
	}

	/**
	 * Creates a validation exception for {@code path} with an underlying cause.
	 *
	 * @param path offending config path (non-null)
	 * @param detail human-readable validation failure description
	 * @param cause underlying cause, or {@code null}
	 */
	public TomlValidationException(ConfigPath path, String detail, Throwable cause) {
		super(Objects.requireNonNull(path, "path") + ": " + Objects.requireNonNull(detail, "detail"), cause);
		this.path = path;
	}

	/**
	 * Returns the offending path in the TOML tree.
	 *
	 * @return offending {@link ConfigPath}
	 */
	public ConfigPath path() {
		return path;
	}
}
