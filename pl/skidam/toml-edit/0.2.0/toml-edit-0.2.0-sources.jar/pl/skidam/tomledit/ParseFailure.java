package pl.skidam.tomledit;

/** Internal fast-fail parse error carrying exact 1-based line/column and 0-based byte offset. */
final class ParseFailure extends RuntimeException {
	private static final long serialVersionUID = 1L;
	final ErrorKind kind;
	final String message;
	final int line;
	final int column;
	final int byteOffset;

	ParseFailure(ErrorKind kind, String message, int line, int column, int byteOffset) {
		super(message, null, false, false);
		this.kind = kind;
		this.message = message;
		this.line = line;
		this.column = column;
		this.byteOffset = byteOffset;
	}

	ParseError toParseError() {
		return new ParseError(kind, message, line, column, byteOffset);
	}
}
