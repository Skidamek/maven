package pl.skidam.tomledit;

/** Thrown on invalid API arguments or paths during document editing or canonical serialization. */
public final class TomlEditException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private final transient ConfigPath path;

	/**
	 * Creates an exception without an associated path.
	 *
	 * @param message detail message
	 */
	public TomlEditException(String message) {
		this(message, null, null);
	}

	/**
	 * Creates an exception associated with {@code path}.
	 *
	 * @param message detail message
	 * @param path offending config path, or {@code null}
	 */
	public TomlEditException(String message, ConfigPath path) {
		this(message, path, null);
	}

	/**
	 * Creates an exception with an associated path and underlying cause.
	 *
	 * @param message detail message
	 * @param path offending config path, or {@code null}
	 * @param cause underlying cause, or {@code null}
	 */
	public TomlEditException(String message, ConfigPath path, Throwable cause) {
		super(message, cause);
		this.path = path;
	}

	/**
	 * Returns the offending path, or {@code null} when the error is not path-specific.
	 *
	 * @return offending {@link ConfigPath}, or {@code null}
	 */
	public ConfigPath path() {
		return path;
	}
}
