package pl.skidam.tomledit;

/** Outcome of {@link TomlEdit#parse(byte[])}: either a {@link Document} or a {@link ParseError}. */
public sealed interface ParseResult permits Document, ParseError {
	/**
	 * Returns {@code true} when parsing succeeded and {@link #document()} is available.
	 *
	 * @return {@code true} if this result is a {@link Document}
	 */
	boolean isOk();

	/**
	 * Returns the parsed document.
	 *
	 * @return the parsed {@link Document}
	 * @throws IllegalStateException if parsing failed
	 */
	Document document();

	/**
	 * Returns the parse failure.
	 *
	 * @return the {@link ParseError}
	 * @throws IllegalStateException if parsing succeeded
	 */
	ParseError error();
}
