package pl.skidam.tomledit;

/** Positioned parse error taxonomy for TOML 1.1.0. */
public enum ErrorKind {
	/** Input bytes are not valid UTF-8. */
	INVALID_UTF8,
	/** Unexpected character or token for the current grammatical construct. */
	UNEXPECTED_TOKEN,
	/** String literal reached end-of-line (single-line) or end-of-file without a closing delimiter. */
	UNTERMINATED_STRING,
	/** Array, inline table, or section header was not closed before end-of-file. */
	UNTERMINATED_CONTAINER,
	/** Unknown, incomplete, or out-of-range escape sequence in a basic string. */
	BAD_ESCAPE,
	/** Disallowed control character (including bare CR) in string, comment, or whitespace. */
	CONTROL_CHARACTER,
	/** Malformed or out-of-range 64-bit integer or floating-point literal. */
	INVALID_NUMBER,
	/** Malformed or out-of-range RFC 3339 date, time, or datetime literal. */
	INVALID_DATETIME,
	/** Duplicate key defined within the same table scope. */
	DUPLICATE_KEY,
	/** Illegal table or inline-table redefinition or reopening. */
	REDEFINED_TABLE,
	/** Container or dotted-key nesting exceeded the parser limit (255). */
	NESTING_OVERFLOW
}
