package pl.skidam.tomledit;

import java.util.ArrayList;
import java.util.List;

/**
 * Surgical inline-table editor over {@link Cst.InlineTable}.
 *
 * <p>Preserves TOML 1.0.0 single-line inline tables as single-line (omitting comments rather than
 * upgrading to TOML 1.1.0-only multiline syntax). Already-multiline TOML 1.1.0 inline tables
 * keep their multiline layout and accept attached comments.
 */
final class CstInlineTableEditor {
	private CstInlineTableEditor() {}

	static void insert(Cst.InlineTable tbl, List<String> keys, TomlValue value, String comment, byte[] docNl) {
		Cst.KeyPath kp = keys.size() == 1
				? CstEntryEditor.buildSingleKeyPath(keys.get(0))
				: CstEntryEditor.buildDottedKeyPath(keys);
		List<Cst.Tok> eqTrivia = Cst.eqTrivia();
		Cst.Val val = Cst.parseInlineVal(value);

		if (isSingleLine(tbl)) {
			// Preserve TOML 1.0.0 single-line compatibility; omit comments (inline tables cannot carry comments in 1.0.0)
			if (tbl.entries.isEmpty()) {
				tbl.trailingTrivia.clear();
				tbl.entries.add(new Cst.InlineEntry(
						List.of(new Cst.Tok(Cst.TokKind.WS, new byte[] {' '})),
						kp, eqTrivia, val, List.of(), null, List.of()));
				tbl.trailingTrivia.add(new Cst.Tok(Cst.TokKind.WS, new byte[] {' '}));
				return;
			}
			Cst.InlineEntry prev = tbl.entries.get(tbl.entries.size() - 1);
			if (prev.comma == null) {
				if (tbl.trailingTrivia.isEmpty() && !prev.postValueTrivia.isEmpty()) {
					tbl.trailingTrivia.addAll(prev.postValueTrivia);
				}
				prev.postValueTrivia.clear();
				prev.comma = new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','});
			}
			tbl.entries.add(new Cst.InlineEntry(
					List.of(new Cst.Tok(Cst.TokKind.WS, new byte[] {' '})),
					kp, eqTrivia, val, List.of(), null, List.of()));
			return;
		}

		// Already-multiline TOML 1.1.0 inline table
		byte[] nl = detectNewline(tbl, docNl);
		byte[] indent = detectIndent(tbl);
		boolean trailingComma = !tbl.entries.isEmpty() && tbl.entries.get(tbl.entries.size() - 1).comma != null;
		List<Cst.Tok> leading = new ArrayList<>();
		if (tbl.entries.isEmpty()) {
			leading.add(new Cst.Tok(Cst.TokKind.NL, nl));
			while (!tbl.trailingTrivia.isEmpty() && tbl.trailingTrivia.get(0).kind() == Cst.TokKind.NL) {
				tbl.trailingTrivia.remove(0);
			}
		} else {
			Cst.InlineEntry prev = tbl.entries.get(tbl.entries.size() - 1);
			if (prev.comma == null) {
				List<Cst.Tok> moved = Cst.extractSameLineFromTrivia(prev.postValueTrivia, tbl.trailingTrivia);
				prev.comma = new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','});
				prev.trailingSameLineTrivia.addAll(moved);
			}
			if (!Cst.endsWithNewline(prev.trailingSameLineTrivia)) {
				prev.trailingSameLineTrivia.add(new Cst.Tok(Cst.TokKind.NL, nl));
			}
		}
		if (comment != null) {
			for (Cst.TriviaLine cl : CstEntryEditor.buildCommentLines(CstEntryEditor.normalizeCommentInput(comment), indent, nl)) {
				leading.addAll(cl.tokens);
			}
		}
		if (indent.length > 0) leading.add(new Cst.Tok(Cst.TokKind.WS, indent));
		Cst.Tok comma = trailingComma ? new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','}) : null;
		List<Cst.Tok> postVal = comma == null ? List.of(new Cst.Tok(Cst.TokKind.NL, nl)) : List.of();
		List<Cst.Tok> sameLine = comma != null ? List.of(new Cst.Tok(Cst.TokKind.NL, nl)) : List.of();
		tbl.entries.add(new Cst.InlineEntry(leading, kp, eqTrivia, val, postVal, comma, sameLine));
	}

	static void removeEntry(Cst.InlineTable tbl, Cst.InlineEntry entry) {
		int idx = tbl.entries.indexOf(entry);
		tbl.entries.remove(idx);
		if (tbl.entries.isEmpty()) {
			tbl.trailingTrivia.clear();
		} else if (idx == tbl.entries.size()) {
			tbl.entries.get(tbl.entries.size() - 1).comma = null;
		}
	}

	static void removeVirtualTable(Cst.InlineTable tbl, List<String> prefixKeys) {
		tbl.entries.removeIf(e -> matchesPrefix(e, prefixKeys));
		if (tbl.entries.isEmpty()) {
			tbl.trailingTrivia.clear();
		} else {
			tbl.entries.get(tbl.entries.size() - 1).comma = null;
		}
	}

	static void replaceVirtualTable(CstNavigator.VirtualInlineTableTarget vit, TomlValue value) {
		Cst.InlineTable tbl = vit.ownerTable();
		List<String> prefix = vit.prefixKeys();
		int firstIdx = -1;
		Cst.InlineEntry firstRemoved = null;
		Cst.InlineEntry lastRemoved = null;
		for (int i = 0; i < tbl.entries.size(); i++) {
			Cst.InlineEntry e = tbl.entries.get(i);
			if (matchesPrefix(e, prefix)) {
				if (firstIdx < 0) {
					firstIdx = i;
					firstRemoved = e;
				}
				lastRemoved = e;
			}
		}
		if (firstIdx < 0) return;
		tbl.entries.removeIf(e -> matchesPrefix(e, prefix));

		Cst.KeyPath kp = prefix.size() == 1
				? CstEntryEditor.buildSingleKeyPath(prefix.get(0))
				: CstEntryEditor.buildDottedKeyPath(prefix);
		List<Cst.Tok> eqTrivia = Cst.eqTrivia();
		Cst.Val val = Cst.parseInlineVal(value);
		boolean isLast = firstIdx == tbl.entries.size();
		Cst.Tok comma = !isLast ? new Cst.Tok(Cst.TokKind.PUNCT, new byte[] {','})
				: (lastRemoved.comma != null && !isSingleLine(tbl) ? lastRemoved.comma : null);
		List<Cst.Tok> postVal = isLast && comma == null ? keepWsAndNewlines(lastRemoved.postValueTrivia) : List.of();
		List<Cst.Tok> sameLine = comma != null ? keepNewlines(lastRemoved.trailingSameLineTrivia) : List.of();
		if (comma != null && sameLine.isEmpty() && Cst.hasNewline(firstRemoved.trailingSameLineTrivia)) {
			sameLine = keepNewlines(firstRemoved.trailingSameLineTrivia);
		}
		tbl.entries.add(firstIdx, new Cst.InlineEntry(firstRemoved.leadingTrivia, kp, eqTrivia, val, postVal, comma, sameLine));
	}

	static void renameVirtualTablePrefix(CstNavigator.VirtualInlineTableTarget vit, String newKey) {
		int segIdx = vit.prefixKeys().size() - 1;
		for (Cst.InlineEntry entry : vit.ownerTable().entries) {
			if (matchesPrefix(entry, vit.prefixKeys())) {
				CstEntryEditor.replaceKeySegmentAt(entry.key, segIdx, newKey);
			}
		}
	}

	private static boolean matchesPrefix(Cst.InlineEntry entry, List<String> prefix) {
		return entry.key.keys.size() >= prefix.size() && entry.key.keys.subList(0, prefix.size()).equals(prefix);
	}

	private static boolean isSingleLine(Cst.InlineTable tbl) {
		for (Cst.InlineEntry e : tbl.entries) {
			if (Cst.hasNewline(e.leadingTrivia) || Cst.hasNewline(e.postValueTrivia) || Cst.hasNewline(e.trailingSameLineTrivia)) {
				return false;
			}
		}
		return !Cst.hasNewline(tbl.trailingTrivia);
	}

	private static List<Cst.Tok> keepWsAndNewlines(List<Cst.Tok> toks) {
		List<Cst.Tok> out = new ArrayList<>();
		for (Cst.Tok tok : toks) {
			if (tok.kind() == Cst.TokKind.WS || tok.kind() == Cst.TokKind.NL) out.add(tok);
		}
		return out;
	}

	private static List<Cst.Tok> keepNewlines(List<Cst.Tok> toks) {
		List<Cst.Tok> out = new ArrayList<>();
		for (Cst.Tok tok : toks) {
			if (tok.kind() == Cst.TokKind.NL) out.add(tok);
		}
		return out;
	}

	private static byte[] detectNewline(Cst.InlineTable tbl, byte[] fallback) {
		for (Cst.InlineEntry e : tbl.entries) {
			for (Cst.Tok tok : e.trailingSameLineTrivia) if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
			for (Cst.Tok tok : e.leadingTrivia) if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
			for (Cst.Tok tok : e.postValueTrivia) if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
		}
		for (Cst.Tok tok : tbl.trailingTrivia) if (tok.kind() == Cst.TokKind.NL) return tok.bytes();
		return fallback;
	}

	private static byte[] detectIndent(Cst.InlineTable tbl) {
		if (!tbl.entries.isEmpty()) {
			List<Cst.Tok> lead = tbl.entries.get(tbl.entries.size() - 1).leadingTrivia;
			if (!lead.isEmpty() && lead.get(lead.size() - 1).kind() == Cst.TokKind.WS) {
				return lead.get(lead.size() - 1).bytes();
			}
		}
		return new byte[] {' ', ' '};
	}
}
