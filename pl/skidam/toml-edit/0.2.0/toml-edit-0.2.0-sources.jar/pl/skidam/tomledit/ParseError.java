package pl.skidam.tomledit;

import java.util.Objects;

/**
 * Positioned parse failure returned by {@link TomlEdit#parse(byte[])}.
 *
 * @param kind error category
 * @param message human-readable error description
 * @param line 1-based line number
 * @param column 1-based UTF-8 code-point column
 * @param byteOffset 0-based byte offset in the input buffer
 */
public record ParseError(ErrorKind kind, String message, int line, int column, int byteOffset) implements ParseResult {

	/**
	 * Validates that {@code kind} and {@code message} are non-null.
	 *
	 * @param kind error category
	 * @param message human-readable error description
	 * @param line 1-based line number
	 * @param column 1-based UTF-8 code-point column
	 * @param byteOffset 0-based byte offset in the input buffer
	 */
	public ParseError {
		Objects.requireNonNull(kind, "kind");
		Objects.requireNonNull(message, "message");
	}

	@Override
	public boolean isOk() {
		return false;
	}

	@Override
	public Document document() {
		throw new IllegalStateException("parse failed: " + this);
	}

	@Override
	public ParseError error() {
		return this;
	}

	@Override
	public String toString() {
		return kind + " at line " + line + ":" + column + " (byte " + byteOffset + "): " + message;
	}
}
