package pl.skidam.tomledit;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Declarative schema of default values and comments for fresh canonical generation and lossless
 * convergence of existing {@link Document}s.
 *
 * <p>A {@code TomlSchema} can describe a full document (with an optional top-of-file banner) or a
 * reusable sub-table (for example, a dynamic section repeated under multiple paths) using the
 * {@code prefix} overloads {@link #ensureDefaults(Document, ConfigPath)} and
 * {@link #addCommentsTo(Comments.Builder, ConfigPath)}, or registered with
 * {@link Builder#dynamicTable(ConfigPath, TomlSchema)}.
 */
public final class TomlSchema {
	private final String banner;
	private final Map<ConfigPath, FieldSpec> fields;
	private final Map<ConfigPath, String> sectionComments;
	private final List<DynamicTableSpec> dynamicTables;

	private TomlSchema(String banner, Map<ConfigPath, FieldSpec> fields, Map<ConfigPath, String> sectionComments, List<DynamicTableSpec> dynamicTables) {
		this.banner = banner;
		this.fields = Collections.unmodifiableMap(fields);
		this.sectionComments = Collections.unmodifiableMap(sectionComments);
		this.dynamicTables = List.copyOf(dynamicTables);
	}

	/**
	 * Creates a new fluent {@link Builder}.
	 *
	 * @return new schema builder
	 */
	public static Builder builder() {
		return new Builder();
	}

	/**
	 * Returns a fresh {@link TomlValue.Table} populated with all declared default values in
	 * declaration order. Mutating the returned table does not affect this schema.
	 *
	 * @return default semantic table
	 */
	public TomlValue.Table defaultTree() {
		TomlValue.Table root = TomlValue.table();
		for (FieldSpec spec : fields.values()) {
			putNested(root, spec.path, deepCopy(spec.defaultValue));
		}
		return root;
	}

	/**
	 * Builds a {@link Comments} specification containing this schema's banner, section comments,
	 * and field comments.
	 *
	 * @return immutable {@link Comments}
	 */
	public Comments comments() {
		Comments.Builder builder = Comments.builder();
		if (banner != null) builder.banner(banner);
		addCommentsTo(builder, ConfigPath.root());
		return builder.build();
	}

	/**
	 * Appends all section and field comments declared in this schema to {@code builder}, prefixed
	 * with {@code prefix}. Useful for documenting dynamic sub-tables without reflection.
	 *
	 * @param builder destination comments builder
	 * @param prefix path prefix (use {@link ConfigPath#root()} for top-level)
	 */
	public void addCommentsTo(Comments.Builder builder, ConfigPath prefix) {
		Objects.requireNonNull(builder, "builder");
		Objects.requireNonNull(prefix, "prefix");
		for (var entry : sectionComments.entrySet()) {
			builder.put(prefix.concat(entry.getKey()), entry.getValue());
		}
		for (FieldSpec spec : fields.values()) {
			if (spec.comment != null) {
				builder.put(prefix.concat(spec.path), spec.comment);
			}
		}
	}

	/**
	 * Generates canonical TOML bytes for {@link #defaultTree()} with {@link #comments()}.
	 *
	 * @return UTF-8 canonical TOML bytes
	 */
	public byte[] canonical() {
		return TomlEdit.canonical(defaultTree(), comments());
	}

	/**
	 * Generates canonical TOML bytes for {@code model} with {@link #comments()} and any
	 * {@link Builder#dynamicTable(ConfigPath, TomlSchema)} entry comments.
	 *
	 * @param model root table to serialize
	 * @return UTF-8 canonical TOML bytes
	 */
	public byte[] canonical(TomlValue.Table model) {
		Objects.requireNonNull(model, "model");
		return TomlEdit.canonical(model, commentsFor(model));
	}

	private Comments commentsFor(TomlValue.Table model) {
		Comments.Builder builder = Comments.builder();
		if (banner != null) builder.banner(banner);
		addCommentsTo(builder, ConfigPath.root());
		for (DynamicTableSpec spec : dynamicTables) {
			if (spec.entrySchema() == null) continue;
			TomlValue.Table map = tableAt(model, spec.path());
			if (map == null) continue;
			for (var entry : map.members().entrySet()) {
				if (entry.getValue() instanceof TomlValue.Table) {
					spec.entrySchema().addCommentsTo(builder, spec.path().appended(entry.getKey()));
				}
			}
		}
		return builder.build();
	}

	/**
	 * Materializes every declared field that is absent from {@code doc} with its default value and
	 * optional comment. Existing fields and their comments are left untouched.
	 *
	 * @param doc target document
	 */
	public void ensureDefaults(Document doc) {
		ensureDefaults(doc, ConfigPath.root());
	}

	/**
	 * Atomically materializes every declared field that is absent under {@code prefix} in {@code doc}
	 * with its default value and optional comment. Existing fields and their comments are left untouched.
	 *
	 * @param doc target document
	 * @param prefix path prefix for this schema
	 */
	public void ensureDefaults(Document doc, ConfigPath prefix) {
		Objects.requireNonNull(doc, "doc");
		Objects.requireNonNull(prefix, "prefix");
		doc.atomicEdit(() -> ensureDefaultsUnchecked(doc.cst(), prefix));
	}

	/**
	 * Atomically reconciles {@code doc} against {@code model} with {@code policy}, materializes
	 * any missing declared defaults, and synchronizes any registered
	 * {@link Builder#dynamicTable(ConfigPath, TomlSchema)} sections (adding absent dynamic entries
	 * and sparse fields, and under {@link ReconcilePolicy#SYNC} removing entries absent from
	 * {@code model}).
	 *
	 * @param doc target document
	 * @param model updated semantic model
	 * @param policy reconciliation strategy
	 */
	public void apply(Document doc, TomlValue.Table model, ReconcilePolicy policy) {
		Objects.requireNonNull(doc, "doc");
		Objects.requireNonNull(model, "model");
		Objects.requireNonNull(policy, "policy");
		doc.atomicEdit(() -> {
			DocumentEditor.reconcile(doc.cst(), model, policy);
			ensureDefaultsUnchecked(doc.cst(), ConfigPath.root());
			reconcileDynamicTablesUnchecked(doc.cst(), model, policy);
		});
	}

	private void ensureDefaultsUnchecked(Cst.Doc cst, ConfigPath prefix) {
		for (FieldSpec spec : fields.values()) {
			DocumentEditor.ensure(cst, prefix.concat(spec.path), deepCopy(spec.defaultValue), spec.comment);
		}
	}

	private void reconcileDynamicTablesUnchecked(Cst.Doc cst, TomlValue.Table model, ReconcilePolicy policy) {
		if (dynamicTables.isEmpty()) return;
		TomlValue.Table currentRoot = Cst.toTable(cst);
		for (DynamicTableSpec spec : dynamicTables) {
			TomlValue.Table modelMap = tableAt(model, spec.path());
			TomlValue.Table currentMap = tableAt(currentRoot, spec.path());
			if (policy == ReconcilePolicy.SYNC && currentMap != null) {
				for (String existingKey : currentMap.members().keySet()) {
					if (modelMap == null || !modelMap.containsKey(existingKey)) {
						DocumentEditor.remove(cst, spec.path().appended(existingKey));
					}
				}
			}
			if (modelMap == null) continue;
			for (var entry : modelMap.members().entrySet()) {
				ConfigPath entryPath = spec.path().appended(entry.getKey());
				TomlValue modelVal = entry.getValue();
				if (CstNavigator.resolve(cst, entryPath) == null) {
					DocumentEditor.ensure(cst, entryPath, deepCopy(modelVal), null);
					if (spec.entrySchema() != null && modelVal instanceof TomlValue.Table sub) {
						applyEntrySchemaComments(cst, entryPath, ConfigPath.root(), sub, spec.entrySchema());
					}
				} else if (modelVal instanceof TomlValue.Table modelSub) {
					ensureModelMembers(cst, entryPath, ConfigPath.root(), modelSub, spec.entrySchema());
				}
			}
		}
	}

	private static void ensureModelMembers(Cst.Doc cst, ConfigPath absPrefix, ConfigPath relPrefix, TomlValue.Table modelSub, TomlSchema entrySchema) {
		for (var entry : modelSub.members().entrySet()) {
			String key = entry.getKey();
			TomlValue val = entry.getValue();
			ConfigPath abs = absPrefix.appended(key);
			ConfigPath rel = relPrefix.appended(key);
			if (CstNavigator.resolve(cst, abs) == null) {
				String comment = entrySchema != null ? entrySchema.commentFor(rel) : null;
				DocumentEditor.ensure(cst, abs, deepCopy(val), comment);
				if (entrySchema != null && val instanceof TomlValue.Table nested) {
					applyEntrySchemaComments(cst, abs, rel, nested, entrySchema);
				}
			} else if (val instanceof TomlValue.Table nested) {
				ensureModelMembers(cst, abs, rel, nested, entrySchema);
			}
		}
	}

	private static void applyEntrySchemaComments(Cst.Doc cst, ConfigPath absPrefix, ConfigPath relPrefix, TomlValue.Table table, TomlSchema entrySchema) {
		for (var entry : table.members().entrySet()) {
			String key = entry.getKey();
			TomlValue val = entry.getValue();
			ConfigPath abs = absPrefix.appended(key);
			ConfigPath rel = relPrefix.appended(key);
			String comment = entrySchema.commentFor(rel);
			if (comment != null) {
				CstNavigator.Target target = CstNavigator.resolve(cst, abs);
				if (target instanceof CstNavigator.EntryTarget || target instanceof CstNavigator.SectionTarget || target instanceof CstNavigator.ArrayOfTablesTarget) {
					CstEntryEditor.setComment(cst, abs, comment);
				}
			}
			if (val instanceof TomlValue.Table nested) {
				applyEntrySchemaComments(cst, abs, rel, nested, entrySchema);
			}
		}
	}

	private String commentFor(ConfigPath relative) {
		String sectionComment = sectionComments.get(relative);
		if (sectionComment != null) return sectionComment;
		FieldSpec spec = fields.get(relative);
		return spec == null ? null : spec.comment();
	}

	private static TomlValue.Table tableAt(TomlValue.Table root, ConfigPath path) {
		TomlValue cur = root;
		for (ConfigPath.Segment seg : path.segments()) {
			if (!(seg instanceof ConfigPath.Segment.Key k)) {
				throw new TomlEditException("dynamic table path must contain only keys: " + path, path);
			}
			if (!(cur instanceof TomlValue.Table tbl)) {
				throw new TomlEditException("dynamic table ancestor is not a table: " + path, path);
			}
			TomlValue next = tbl.get(k.name());
			if (next == null) return null;
			if (!(next instanceof TomlValue.Table nextTbl)) {
				throw new TomlEditException("dynamic table path is not a table: " + path, path);
			}
			cur = nextTbl;
		}
		return (TomlValue.Table) cur;
	}

	private static void putNested(TomlValue.Table root, ConfigPath path, TomlValue value) {
		TomlValue.Table cur = root;
		var segs = path.segments();
		for (int i = 0; i < segs.size() - 1; i++) {
			String key = ((ConfigPath.Segment.Key) segs.get(i)).name();
			TomlValue existing = cur.get(key);
			if (existing instanceof TomlValue.Table sub) {
				cur = sub;
			} else {
				TomlValue.Table sub = TomlValue.table();
				cur.put(key, sub);
				cur = sub;
			}
		}
		cur.put(((ConfigPath.Segment.Key) segs.get(segs.size() - 1)).name(), value);
	}

	private static TomlValue deepCopy(TomlValue value) {
		if (value instanceof TomlValue.Table t) {
			TomlValue.Table copy = TomlValue.table();
			for (var e : t.members().entrySet()) {
				copy.put(e.getKey(), deepCopy(e.getValue()));
			}
			return copy;
		}
		if (value instanceof TomlValue.Array a) {
			TomlValue.Array copy = TomlValue.array();
			for (TomlValue elem : a.elements()) {
				copy.add(deepCopy(elem));
			}
			return copy;
		}
		return value;
	}

	private static void requireKeyOnlyPath(ConfigPath path) {
		Objects.requireNonNull(path, "path");
		if (path.isRoot()) throw new IllegalArgumentException("schema path must not be root");
		for (ConfigPath.Segment seg : path.segments()) {
			if (!(seg instanceof ConfigPath.Segment.Key)) {
				throw new IllegalArgumentException("schema path must contain only key segments: " + path);
			}
		}
	}

	private record FieldSpec(ConfigPath path, TomlValue defaultValue, String comment) {}

	private record DynamicTableSpec(ConfigPath path, TomlSchema entrySchema) {}

	/** Fluent builder for {@link TomlSchema}. */
	public static final class Builder {
		private String banner;
		private final LinkedHashMap<ConfigPath, FieldSpec> fields = new LinkedHashMap<>();
		private final LinkedHashMap<ConfigPath, String> sectionComments = new LinkedHashMap<>();
		private final LinkedHashMap<ConfigPath, DynamicTableSpec> dynamicTables = new LinkedHashMap<>();

		/** Creates an empty schema builder. */
		public Builder() {}

		/**
		 * Sets the top-of-file banner comment.
		 *
		 * @param banner banner text, or {@code null} for none
		 * @return this builder
		 */
		public Builder banner(String banner) {
			this.banner = banner;
			return this;
		}

		/**
		 * Declares a field with a default value and no comment.
		 *
		 * @param path key-only path to the field
		 * @param defaultValue default TOML value
		 * @return this builder
		 */
		public Builder field(ConfigPath path, TomlValue defaultValue) {
			return field(path, defaultValue, null);
		}

		/**
		 * Declares a field with a default value and an optional attached comment.
		 *
		 * @param path key-only path to the field
		 * @param defaultValue default TOML value
		 * @param comment optional attached comment text, or {@code null}
		 * @return this builder
		 */
		public Builder field(ConfigPath path, TomlValue defaultValue, String comment) {
			requireKeyOnlyPath(path);
			Objects.requireNonNull(defaultValue, "defaultValue");
			fields.put(path, new FieldSpec(path, deepCopy(defaultValue), comment));
			return this;
		}

		/**
		 * Declares a comment for a section header or table path without attaching a default value.
		 *
		 * @param path key-only path to the table/section
		 * @param comment comment text
		 * @return this builder
		 */
		public Builder comment(ConfigPath path, String comment) {
			requireKeyOnlyPath(path);
			Objects.requireNonNull(comment, "comment");
			sectionComments.put(path, comment);
			return this;
		}

		/**
		 * Declares a dynamic map-of-tables section (for example {@code [groups.<id>]}). On
		 * {@link TomlSchema#apply(Document, TomlValue.Table, ReconcilePolicy)}, entries present in the
		 * model are inserted or updated in place without filling omitted optional fields, and under
		 * {@link ReconcilePolicy#SYNC} entries absent from the model are removed.
		 *
		 * @param path key-only path to the parent map table
		 * @return this builder
		 */
		public Builder dynamicTable(ConfigPath path) {
			return dynamicTable(path, null);
		}

		/**
		 * Declares a dynamic map-of-tables section with an optional per-entry comment schema used on
		 * {@link TomlSchema#canonical(TomlValue.Table)} and when inserting new keys/entries on
		 * {@link TomlSchema#apply(Document, TomlValue.Table, ReconcilePolicy)}.
		 *
		 * @param path key-only path to the parent map table
		 * @param entrySchema optional entry schema for comments, or {@code null}
		 * @return this builder
		 */
		public Builder dynamicTable(ConfigPath path, TomlSchema entrySchema) {
			requireKeyOnlyPath(path);
			dynamicTables.put(path, new DynamicTableSpec(path, entrySchema));
			return this;
		}

		/**
		 * Builds an immutable {@link TomlSchema}.
		 *
		 * @return built {@link TomlSchema}
		 */
		public TomlSchema build() {
			return new TomlSchema(banner, new LinkedHashMap<>(fields), new LinkedHashMap<>(sectionComments), List.copyOf(dynamicTables.values()));
		}
	}
}
