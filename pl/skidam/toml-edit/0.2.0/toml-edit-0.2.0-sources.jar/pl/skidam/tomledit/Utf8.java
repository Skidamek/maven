package pl.skidam.tomledit;

/**
 * Byte-level UTF-8 helpers over already-validated text. Decoding is only ever called on sequences
 * the validator accepted, so these are safe by construction.
 */
final class Utf8 {
	private Utf8() {}

	static boolean isHex(byte b) {
		return b >= '0' && b <= '9' || b >= 'a' && b <= 'f' || b >= 'A' && b <= 'F';
	}

	static int hexValue(byte b) {
		return b <= '9' ? b - '0' : (b & 0xDF) - 'A' + 10;
	}

	/** Number of bytes of the UTF-8 sequence starting with this lead byte, or -1 for an illegal lead. */
	static int sequenceLength(byte lead) {
		if (lead >= 0) return 1;
		if ((lead & 0xE0) == 0xC0) return 2;
		if ((lead & 0xF0) == 0xE0) return 3;
		if ((lead & 0xF8) == 0xF0) return 4;
		return -1;
	}

	/** Decodes one code point at {@code pos}; the caller guarantees a valid, in-bounds sequence. */
	static int decode(byte[] text, int pos) {
		byte lead = text[pos];
		if (lead >= 0) return lead;
		int length = sequenceLength(lead);
		int cp = lead & (0xFF >> (length + 1));
		for (int i = 1; i < length; i++) cp = cp << 6 | (text[pos + i] & 0x3F);
		return cp;
	}

	/**
	 * Validates the whole buffer as UTF-8, rejecting overlongs, surrogates, and truncated sequences.
	 * Returns the byte offset of the first offending byte, or -1 when the buffer is valid.
	 */
	static int firstInvalidOffset(byte[] text) {
		int i = 0;
		while (i < text.length) {
			byte lead = text[i];
			if (lead >= 0) {
				i++;
				continue;
			}
			int length = sequenceLength(lead);
			if (length < 0) return i;
			if (i + length > text.length) return i;
			byte b1 = text[i + 1];
			if ((b1 & 0xC0) != 0x80) return i;
			int cp = switch (length) {
				case 2 -> (lead & 0x1F) << 6 | (b1 & 0x3F);
				case 3 -> {
					byte b2 = text[i + 2];
					if ((b2 & 0xC0) != 0x80) yield -1;
					yield (lead & 0x0F) << 12 | (b1 & 0x3F) << 6 | (b2 & 0x3F);
				}
				default -> {
					byte b2 = text[i + 2];
					byte b3 = text[i + 3];
					if ((b2 & 0xC0) != 0x80 || (b3 & 0xC0) != 0x80) yield -1;
					yield (lead & 0x07) << 18 | (b1 & 0x3F) << 12 | (b2 & 0x3F) << 6 | (b3 & 0x3F);
				}
			};
			if (cp < 0) return i;
			if (length == 2 && cp < 0x80) return i;
			if (length == 3 && cp < 0x800) return i;
			if (length == 4 && cp < 0x10000) return i;
			if (length == 4 && cp > 0x10FFFF) return i;
			if (cp >= 0xD800 && cp <= 0xDFFF) return i;
			i += length;
		}
		return -1;
	}
}
