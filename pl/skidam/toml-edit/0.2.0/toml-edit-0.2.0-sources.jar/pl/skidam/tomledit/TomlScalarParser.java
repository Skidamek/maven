package pl.skidam.tomledit;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

/**
 * Pure, stateless decoder for TOML 1.1.0 bare scalar tokens: booleans, integers (decimal/hex/octal/binary),
 * IEEE 754 floats (including {@code inf}/{@code nan}), and RFC 3339 date/time literals.
 */
final class TomlScalarParser {
	private TomlScalarParser() {}

	static Cst.Scalar parse(String text, byte[] raw, int startLine, int startCol, int startPos) {
		switch (text) {
			case "true" -> {
				return new Cst.Scalar(new Cst.Tok(Cst.TokKind.BOOL, raw), TomlValue.Bool.TRUE);
			}
			case "false" -> {
				return new Cst.Scalar(new Cst.Tok(Cst.TokKind.BOOL, raw), TomlValue.Bool.FALSE);
			}
			case "inf", "+inf" -> {
				return new Cst.Scalar(new Cst.Tok(Cst.TokKind.FLOAT, raw), TomlValue.floating(Double.POSITIVE_INFINITY, text));
			}
			case "-inf" -> {
				return new Cst.Scalar(new Cst.Tok(Cst.TokKind.FLOAT, raw), TomlValue.floating(Double.NEGATIVE_INFINITY, text));
			}
			case "nan", "+nan", "-nan" -> {
				return new Cst.Scalar(new Cst.Tok(Cst.TokKind.FLOAT, raw), TomlValue.floating(Double.NaN, text));
			}
			default -> {
			}
		}
		if (looksLikeTemporal(text)) {
			return parseTemporal(text, raw, startLine, startCol, startPos);
		}
		return parseNumber(text, raw, startLine, startCol, startPos);
	}

	static boolean looksLikeDate(byte[] buf, int off) {
		return isDigit(buf[off]) && isDigit(buf[off + 1]) && isDigit(buf[off + 2]) && isDigit(buf[off + 3])
				&& buf[off + 4] == '-'
				&& isDigit(buf[off + 5]) && isDigit(buf[off + 6])
				&& buf[off + 7] == '-'
				&& isDigit(buf[off + 8]) && isDigit(buf[off + 9]);
	}

	private static boolean looksLikeTemporal(String s) {
		if (s.length() >= 5 && isDigit(s.charAt(0)) && isDigit(s.charAt(1)) && s.charAt(2) == ':' && isDigit(s.charAt(3))) {
			return true;
		}
		return s.length() >= 8 && isDigit(s.charAt(0)) && isDigit(s.charAt(1)) && isDigit(s.charAt(2)) && isDigit(s.charAt(3)) && s.charAt(4) == '-';
	}

	private static Cst.Scalar parseTemporal(String text, byte[] raw, int l, int c, int p) {
		if (text.length() >= 5 && text.charAt(2) == ':') {
			LocalTime time = parseLocalTimeStrict(text, 0, text.length(), l, c, p);
			return new Cst.Scalar(new Cst.Tok(Cst.TokKind.LOCAL_TIME, raw), TomlValue.localTime(time, text));
		}
		if (text.length() < 10 || !looksLikeDate(raw, 0)) {
			throw failAt(ErrorKind.INVALID_DATETIME, "invalid date/time literal: " + text, l, c, p);
		}
		LocalDate date = parseLocalDateStrict(text, l, c, p);
		if (text.length() == 10) {
			return new Cst.Scalar(new Cst.Tok(Cst.TokKind.LOCAL_DATE, raw), TomlValue.localDate(date, text));
		}
		char sep = text.charAt(10);
		if (sep != 'T' && sep != 't' && sep != ' ') {
			throw failAt(ErrorKind.INVALID_DATETIME, "invalid date/time separator in: " + text, l, c, p);
		}
		int timeStart = 11;
		int offsetIdx = -1;
		for (int i = timeStart; i < text.length(); i++) {
			char ch = text.charAt(i);
			if (ch == 'Z' || ch == 'z' || ch == '+' || ch == '-') {
				offsetIdx = i;
				break;
			}
		}
		if (offsetIdx < 0) {
			LocalTime time = parseLocalTimeStrict(text, timeStart, text.length(), l, c, p);
			return new Cst.Scalar(new Cst.Tok(Cst.TokKind.LOCAL_DATETIME, raw),
					TomlValue.localDateTime(LocalDateTime.of(date, time), text));
		}
		LocalTime time = parseLocalTimeStrict(text, timeStart, offsetIdx, l, c, p);
		ZoneOffset offset = parseOffsetStrict(text, offsetIdx, l, c, p);
		return new Cst.Scalar(new Cst.Tok(Cst.TokKind.OFFSET_DATETIME, raw),
				TomlValue.offsetDateTime(OffsetDateTime.of(date, time, offset), text));
	}

	private static LocalDate parseLocalDateStrict(String text, int l, int c, int p) {
		int year = parse2Or4(text, 0, 4);
		int month = parse2Or4(text, 5, 2);
		int day = parse2Or4(text, 8, 2);
		try {
			return LocalDate.of(year, month, day);
		} catch (DateTimeException e) {
			throw failAt(ErrorKind.INVALID_DATETIME, "invalid calendar date: " + text, l, c, p);
		}
	}

	private static LocalTime parseLocalTimeStrict(String text, int start, int end, int l, int c, int p) {
		int len = end - start;
		if (len < 5) throw failAt(ErrorKind.INVALID_DATETIME, "incomplete time: " + text, l, c, p);
		if (!isDigit(text.charAt(start)) || !isDigit(text.charAt(start + 1)) || text.charAt(start + 2) != ':'
				|| !isDigit(text.charAt(start + 3)) || !isDigit(text.charAt(start + 4))) {
			throw failAt(ErrorKind.INVALID_DATETIME, "malformed time: " + text, l, c, p);
		}
		int hour = parse2Or4(text, start, 2);
		int minute = parse2Or4(text, start + 3, 2);
		int second = 0;
		int nano = 0;
		int idx = start + 5;
		if (idx < end) {
			if (text.charAt(idx) != ':' || idx + 3 > end
					|| !isDigit(text.charAt(idx + 1)) || !isDigit(text.charAt(idx + 2))) {
				throw failAt(ErrorKind.INVALID_DATETIME, "malformed seconds in time: " + text, l, c, p);
			}
			second = parse2Or4(text, idx + 1, 2);
			idx += 3;
			if (idx < end) {
				if (text.charAt(idx) != '.' || idx + 1 >= end) {
					throw failAt(ErrorKind.INVALID_DATETIME, "malformed fractional seconds in time: " + text, l, c, p);
				}
				idx++;
				int fracStart = idx;
				while (idx < end) {
					if (!isDigit(text.charAt(idx))) {
						throw failAt(ErrorKind.INVALID_DATETIME, "non-digit in fractional seconds: " + text, l, c, p);
					}
					idx++;
				}
				int digits = idx - fracStart;
				int scale = 100_000_000;
				for (int i = 0; i < Math.min(digits, 9); i++) {
					nano += (text.charAt(fracStart + i) - '0') * scale;
					scale /= 10;
				}
			}
		}
		try {
			return LocalTime.of(hour, minute, second, nano);
		} catch (DateTimeException e) {
			throw failAt(ErrorKind.INVALID_DATETIME, "time out of range: " + text, l, c, p);
		}
	}

	private static ZoneOffset parseOffsetStrict(String text, int start, int l, int c, int p) {
		int len = text.length() - start;
		char first = text.charAt(start);
		if (first == 'Z' || first == 'z') {
			if (len != 1) throw failAt(ErrorKind.INVALID_DATETIME, "trailing characters after Z offset: " + text, l, c, p);
			return ZoneOffset.UTC;
		}
		if ((first != '+' && first != '-') || len != 6 || text.charAt(start + 3) != ':'
				|| !isDigit(text.charAt(start + 1)) || !isDigit(text.charAt(start + 2))
				|| !isDigit(text.charAt(start + 4)) || !isDigit(text.charAt(start + 5))) {
			throw failAt(ErrorKind.INVALID_DATETIME, "malformed timezone offset: " + text, l, c, p);
		}
		int hours = parse2Or4(text, start + 1, 2);
		int minutes = parse2Or4(text, start + 4, 2);
		if (hours > 23 || minutes > 59) {
			throw failAt(ErrorKind.INVALID_DATETIME, "timezone offset out of range: " + text, l, c, p);
		}
		try {
			return first == '+' ? ZoneOffset.ofHoursMinutes(hours, minutes) : ZoneOffset.ofHoursMinutes(-hours, -minutes);
		} catch (DateTimeException e) {
			throw failAt(ErrorKind.INVALID_DATETIME, "timezone offset outside Java ZoneOffset +-18:00 range: " + text, l, c, p);
		}
	}

	private static int parse2Or4(String s, int off, int len) {
		int v = 0;
		for (int i = 0; i < len; i++) v = v * 10 + (s.charAt(off + i) - '0');
		return v;
	}

	private static Cst.Scalar parseNumber(String text, byte[] raw, int l, int c, int p) {
		if (text.length() >= 2 && text.charAt(0) == '0') {
			char radixChar = text.charAt(1);
			if (radixChar == 'x' || radixChar == 'o' || radixChar == 'b') {
				int radix = radixChar == 'x' ? 16 : radixChar == 'o' ? 8 : 2;
				StringBuilder digits = new StringBuilder(text.length());
				int end = scanDigitRun(text, 2, radix, false, false, digits, l, c, p);
				if (end != text.length()) {
					throw failAt(ErrorKind.INVALID_NUMBER, "invalid radix integer: " + text, l, c, p);
				}
				try {
					return new Cst.Scalar(new Cst.Tok(Cst.TokKind.INT, raw), TomlValue.integer(Long.parseLong(digits.toString(), radix), text));
				} catch (NumberFormatException e) {
					throw failAt(ErrorKind.INVALID_NUMBER, "integer out of 64-bit signed range: " + text, l, c, p);
				}
			}
		}
		if (text.indexOf('.') >= 0 || text.indexOf('e') >= 0 || text.indexOf('E') >= 0) {
			String cleaned = validateFloat(text, l, c, p);
			try {
				return new Cst.Scalar(new Cst.Tok(Cst.TokKind.FLOAT, raw), TomlValue.floating(Double.parseDouble(cleaned), text));
			} catch (NumberFormatException e) {
				throw failAt(ErrorKind.INVALID_NUMBER, "invalid float: " + text, l, c, p);
			}
		}
		String cleaned = validateDecInt(text, l, c, p);
		try {
			return new Cst.Scalar(new Cst.Tok(Cst.TokKind.INT, raw), TomlValue.integer(Long.parseLong(cleaned), text));
		} catch (NumberFormatException e) {
			throw failAt(ErrorKind.INVALID_NUMBER, "integer out of 64-bit signed range: " + text, l, c, p);
		}
	}

	private static String validateDecInt(String text, int l, int c, int p) {
		int i = 0;
		StringBuilder sb = new StringBuilder(text.length());
		if (i < text.length() && (text.charAt(i) == '+' || text.charAt(i) == '-')) sb.append(text.charAt(i++));
		i = scanUnsignedDecIntPart(text, i, sb, l, c, p, false, false);
		if (i != text.length()) throw failAt(ErrorKind.INVALID_NUMBER, "invalid integer: " + text, l, c, p);
		return sb.toString();
	}

	private static String validateFloat(String text, int l, int c, int p) {
		int i = 0;
		int len = text.length();
		StringBuilder sb = new StringBuilder(len);
		if (i < len && (text.charAt(i) == '+' || text.charAt(i) == '-')) sb.append(text.charAt(i++));
		i = scanUnsignedDecIntPart(text, i, sb, l, c, p, true, true);
		if (i < len && text.charAt(i) == '.') {
			sb.append('.');
			i = scanDigitRun(text, i + 1, 10, false, true, sb, l, c, p);
		}
		if (i < len && (text.charAt(i) == 'e' || text.charAt(i) == 'E')) {
			sb.append(text.charAt(i++));
			if (i < len && (text.charAt(i) == '+' || text.charAt(i) == '-')) sb.append(text.charAt(i++));
			i = scanDigitRun(text, i, 10, false, false, sb, l, c, p);
		}
		if (i != len) throw failAt(ErrorKind.INVALID_NUMBER, "invalid float: " + text, l, c, p);
		return sb.toString();
	}

	private static int scanUnsignedDecIntPart(String text, int i, StringBuilder sb, int l, int c, int p,
			boolean stopAtDot, boolean stopAtExp) {
		if (i >= text.length() || !isDigit(text.charAt(i))) {
			throw failAt(ErrorKind.INVALID_NUMBER, "invalid number: " + text, l, c, p);
		}
		if (text.charAt(i) == '0') {
			sb.append('0');
			int next = i + 1;
			if (next < text.length() && !(stopAtDot && text.charAt(next) == '.')
					&& !(stopAtExp && (text.charAt(next) == 'e' || text.charAt(next) == 'E'))) {
				throw failAt(ErrorKind.INVALID_NUMBER, "leading zero in number: " + text, l, c, p);
			}
			return next;
		}
		return scanDigitRun(text, i, 10, stopAtDot, stopAtExp, sb, l, c, p);
	}

	/**
	 * Scans a non-empty run of digits in {@code radix} with single underscores strictly between digits,
	 * appending digits (without underscores) to {@code sb} and returning the stop index.
	 */
	private static int scanDigitRun(String text, int start, int radix, boolean stopAtDot, boolean stopAtExp,
			StringBuilder sb, int l, int c, int p) {
		int len = text.length();
		if (start >= len || !isRadixDigit(text.charAt(start), radix)) {
			throw failAt(ErrorKind.INVALID_NUMBER, "invalid number: " + text, l, c, p);
		}
		int i = start;
		boolean prevUnderscore = false;
		while (i < len) {
			char ch = text.charAt(i);
			if ((stopAtDot && ch == '.') || (stopAtExp && (ch == 'e' || ch == 'E'))) {
				if (prevUnderscore) throw failAt(ErrorKind.INVALID_NUMBER, "underscore before delimiter: " + text, l, c, p);
				return i;
			}
			if (ch == '_') {
				if (prevUnderscore) throw failAt(ErrorKind.INVALID_NUMBER, "consecutive underscores in number: " + text, l, c, p);
				prevUnderscore = true;
			} else if (isRadixDigit(ch, radix)) {
				prevUnderscore = false;
				sb.append(ch);
			} else {
				throw failAt(ErrorKind.INVALID_NUMBER, "invalid number: " + text, l, c, p);
			}
			i++;
		}
		if (prevUnderscore) throw failAt(ErrorKind.INVALID_NUMBER, "trailing underscore in number: " + text, l, c, p);
		return i;
	}

	private static boolean isDigit(int c) {
		return c >= '0' && c <= '9';
	}

	private static boolean isRadixDigit(char c, int radix) {
		if (radix == 10) return c >= '0' && c <= '9';
		if (radix == 2) return c == '0' || c == '1';
		if (radix == 8) return c >= '0' && c <= '7';
		return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
	}

	private static ParseFailure failAt(ErrorKind kind, String message, int line, int col, int byteOffset) {
		return new ParseFailure(kind, message, line, col, byteOffset);
	}
}
