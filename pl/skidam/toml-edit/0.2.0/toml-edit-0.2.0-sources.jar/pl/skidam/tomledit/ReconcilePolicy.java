package pl.skidam.tomledit;

/** Controls how {@code Document.reconcile} aligns existing arrays with the target model. */
public enum ReconcilePolicy {
	/** Full LCS diff: inserts missing model elements and removes elements absent from the model while preserving kept elements' layout and comments. */
	SYNC,
	/** Insert-only LCS diff: inserts missing model elements and leaves extra document elements untouched. */
	INSERT_ONLY
}
