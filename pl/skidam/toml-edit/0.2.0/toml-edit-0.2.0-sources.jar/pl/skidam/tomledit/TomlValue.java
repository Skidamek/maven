package pl.skidam.tomledit;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Semantic TOML 1.1.0 value tree.
 *
 * <p>Numeric and temporal values retain their original source literal as metadata when parsed,
 * while {@link Object#equals(Object)} and {@link Object#hashCode()} compare exact semantic values.
 * Offset datetimes use {@link OffsetDateTime}, whose {@link java.time.ZoneOffset} covers the
 * standard {@code -18:00..+18:00} range.
 */
public sealed interface TomlValue
		permits TomlValue.Table, TomlValue.Array, TomlValue.Str, TomlValue.Int, TomlValue.Float, TomlValue.Bool,
				TomlValue.OffsetDateTimeVal, TomlValue.LocalDateTimeVal, TomlValue.LocalDateVal, TomlValue.LocalTimeVal {

	/** Ordered mutable TOML table preserving insertion order. */
	final class Table implements TomlValue {
		private final LinkedHashMap<String, TomlValue> entries = new LinkedHashMap<>();

		/** Creates an empty table. */
		public Table() {}

		/**
		 * Inserts or replaces {@code key} with {@code value}.
		 *
		 * @param key non-null member key
		 * @param value non-null member value
		 * @return this table for chaining
		 */
		public Table put(String key, TomlValue value) {
			Objects.requireNonNull(key, "key");
			Objects.requireNonNull(value, "value");
			entries.put(key, value);
			return this;
		}

		/**
		 * Returns an unmodifiable insertion-ordered view of this table's entries.
		 *
		 * @return unmodifiable map of members
		 */
		public Map<String, TomlValue> members() {
			return Collections.unmodifiableMap(entries);
		}

		/**
		 * Returns the value associated with {@code key}, or {@code null} if absent.
		 *
		 * @param key member key
		 * @return member value or {@code null}
		 */
		public TomlValue get(String key) {
			return entries.get(key);
		}

		/**
		 * Returns {@code true} if this table contains {@code key}.
		 *
		 * @param key member key
		 * @return {@code true} when present
		 */
		public boolean containsKey(String key) {
			return entries.containsKey(key);
		}

		/**
		 * Returns the number of direct entries in this table.
		 *
		 * @return entry count
		 */
		public int size() {
			return entries.size();
		}

		/**
		 * Returns {@code true} if this table has no entries.
		 *
		 * @return {@code true} when empty
		 */
		public boolean isEmpty() {
			return entries.isEmpty();
		}

		/**
		 * Returns the string value at {@code key}, or empty if absent or of another type.
		 *
		 * @param key member key
		 * @return optional string value
		 */
		public Optional<String> getString(String key) {
			return entries.get(key) instanceof Str s ? Optional.of(s.value()) : Optional.empty();
		}

		/**
		 * Returns the 64-bit integer value at {@code key}, or empty if absent or of another type.
		 *
		 * @param key member key
		 * @return optional integer value
		 */
		public Optional<Long> getLong(String key) {
			return entries.get(key) instanceof Int i ? Optional.of(i.value()) : Optional.empty();
		}

		/**
		 * Returns the double value at {@code key}, or empty if absent or of another type.
		 *
		 * @param key member key
		 * @return optional floating-point value
		 */
		public Optional<Double> getDouble(String key) {
			return entries.get(key) instanceof Float f ? Optional.of(f.value()) : Optional.empty();
		}

		/**
		 * Returns the boolean value at {@code key}, or empty if absent or of another type.
		 *
		 * @param key member key
		 * @return optional boolean value
		 */
		public Optional<Boolean> getBoolean(String key) {
			return entries.get(key) instanceof Bool b ? Optional.of(b.value()) : Optional.empty();
		}

		/**
		 * Returns the array value at {@code key}, or empty if absent or of another type.
		 *
		 * @param key member key
		 * @return optional array value
		 */
		public Optional<Array> getArray(String key) {
			return entries.get(key) instanceof Array a ? Optional.of(a) : Optional.empty();
		}

		/**
		 * Returns the nested table value at {@code key}, or empty if absent or of another type.
		 *
		 * @param key member key
		 * @return optional table value
		 */
		public Optional<Table> getTable(String key) {
			return entries.get(key) instanceof Table t ? Optional.of(t) : Optional.empty();
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Table other && entries.equals(other.entries);
		}

		@Override
		public int hashCode() {
			return entries.hashCode();
		}

		@Override
		public String toString() {
			return entries.toString();
		}
	}

	/** Mutable ordered TOML array. */
	final class Array implements TomlValue {
		private final List<TomlValue> items = new ArrayList<>();

		/** Creates an empty array. */
		public Array() {}

		/**
		 * Appends {@code value} to this array.
		 *
		 * @param value non-null element
		 * @return this array for chaining
		 */
		public Array add(TomlValue value) {
			Objects.requireNonNull(value, "value");
			items.add(value);
			return this;
		}

		/**
		 * Returns an unmodifiable view of this array's elements.
		 *
		 * @return unmodifiable list of elements
		 */
		public List<TomlValue> elements() {
			return Collections.unmodifiableList(items);
		}

		/**
		 * Returns the element at {@code index}.
		 *
		 * @param index 0-based element index
		 * @return element at {@code index}
		 */
		public TomlValue get(int index) {
			return items.get(index);
		}

		/**
		 * Returns the number of elements in this array.
		 *
		 * @return element count
		 */
		public int size() {
			return items.size();
		}

		/**
		 * Returns {@code true} if this array has no elements.
		 *
		 * @return {@code true} when empty
		 */
		public boolean isEmpty() {
			return items.isEmpty();
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Array other && items.equals(other.items);
		}

		@Override
		public int hashCode() {
			return items.hashCode();
		}

		@Override
		public String toString() {
			return items.toString();
		}
	}

	/**
	 * TOML string value.
	 *
	 * @param value decoded string content
	 */
	record Str(String value) implements TomlValue {
		/**
		 * Validates that {@code value} is non-null.
		 *
		 * @param value decoded string content
		 */
		public Str {
			Objects.requireNonNull(value, "value");
		}
	}

	/** Signed 64-bit TOML integer value with optional source literal metadata. */
	final class Int implements TomlValue {
		private final long value;
		private final String literal;

		/**
		 * Creates an integer value with decimal canonical literal metadata.
		 *
		 * @param value 64-bit integer value
		 */
		public Int(long value) {
			this(value, Long.toString(value));
		}

		/**
		 * Creates an integer value preserving its source literal.
		 *
		 * @param value 64-bit integer value
		 * @param literal original source literal metadata
		 */
		public Int(long value, String literal) {
			this.value = value;
			this.literal = Objects.requireNonNull(literal, "literal");
		}

		/**
		 * Returns the numeric value.
		 *
		 * @return 64-bit integer value
		 */
		public long value() {
			return value;
		}

		/**
		 * Returns the preserved source literal metadata.
		 *
		 * @return source literal string
		 */
		public String literal() {
			return literal;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Int other && value == other.value;
		}

		@Override
		public int hashCode() {
			return Long.hashCode(value);
		}

		@Override
		public String toString() {
			return literal;
		}
	}

	/** IEEE 754 64-bit TOML floating-point value with optional source literal metadata. */
	final class Float implements TomlValue {
		private final double value;
		private final String literal;

		/**
		 * Creates a floating-point value with canonical literal metadata.
		 *
		 * @param value double value
		 */
		public Float(double value) {
			this(value, formatCanonical(value));
		}

		/**
		 * Creates a floating-point value preserving its source literal.
		 *
		 * @param value double value
		 * @param literal original source literal metadata
		 */
		public Float(double value, String literal) {
			this.value = value;
			this.literal = Objects.requireNonNull(literal, "literal");
		}

		/**
		 * Returns the numeric value.
		 *
		 * @return double value
		 */
		public double value() {
			return value;
		}

		/**
		 * Returns the preserved source literal metadata.
		 *
		 * @return source literal string
		 */
		public String literal() {
			return literal;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof Float other && Double.compare(value, other.value) == 0;
		}

		@Override
		public int hashCode() {
			return Double.hashCode(value);
		}

		@Override
		public String toString() {
			return literal;
		}

		static String formatCanonical(double value) {
			if (Double.isNaN(value)) return "nan";
			if (Double.isInfinite(value)) return value > 0 ? "inf" : "-inf";
			return Double.toString(value);
		}
	}

	/**
	 * TOML boolean value.
	 *
	 * @param value boolean value
	 */
	record Bool(boolean value) implements TomlValue {
		/** Singleton {@code true} instance. */
		public static final Bool TRUE = new Bool(true);
		/** Singleton {@code false} instance. */
		public static final Bool FALSE = new Bool(false);
	}

	/** TOML offset date-time value (RFC 3339) with optional source literal metadata. */
	final class OffsetDateTimeVal implements TomlValue {
		private final OffsetDateTime value;
		private final String literal;

		/**
		 * Creates an offset date-time value, validating 4-digit year and minute-precision offset.
		 *
		 * @param value non-null {@link OffsetDateTime}
		 */
		public OffsetDateTimeVal(OffsetDateTime value) {
			this(value, CanonicalWriter.formatOffsetDateTime(Objects.requireNonNull(value, "value")));
		}

		/**
		 * Creates an offset date-time value preserving its source literal.
		 *
		 * @param value non-null {@link OffsetDateTime}
		 * @param literal original source literal metadata
		 */
		public OffsetDateTimeVal(OffsetDateTime value, String literal) {
			this.value = Objects.requireNonNull(value, "value");
			CanonicalWriter.validateOffset(value.getOffset());
			CanonicalWriter.validateYear(value.getYear());
			this.literal = Objects.requireNonNull(literal, "literal");
		}

		/**
		 * Returns the {@link OffsetDateTime} value.
		 *
		 * @return offset date-time
		 */
		public OffsetDateTime value() {
			return value;
		}

		/**
		 * Returns the preserved source literal metadata.
		 *
		 * @return source literal string
		 */
		public String literal() {
			return literal;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof OffsetDateTimeVal other && value.equals(other.value);
		}

		@Override
		public int hashCode() {
			return value.hashCode();
		}

		@Override
		public String toString() {
			return literal;
		}
	}

	/** TOML local date-time value with optional source literal metadata. */
	final class LocalDateTimeVal implements TomlValue {
		private final LocalDateTime value;
		private final String literal;

		/**
		 * Creates a local date-time value, validating 4-digit year.
		 *
		 * @param value non-null {@link LocalDateTime}
		 */
		public LocalDateTimeVal(LocalDateTime value) {
			this(value, CanonicalWriter.formatLocalDateTime(Objects.requireNonNull(value, "value")));
		}

		/**
		 * Creates a local date-time value preserving its source literal.
		 *
		 * @param value non-null {@link LocalDateTime}
		 * @param literal original source literal metadata
		 */
		public LocalDateTimeVal(LocalDateTime value, String literal) {
			this.value = Objects.requireNonNull(value, "value");
			CanonicalWriter.validateYear(value.getYear());
			this.literal = Objects.requireNonNull(literal, "literal");
		}

		/**
		 * Returns the {@link LocalDateTime} value.
		 *
		 * @return local date-time
		 */
		public LocalDateTime value() {
			return value;
		}

		/**
		 * Returns the preserved source literal metadata.
		 *
		 * @return source literal string
		 */
		public String literal() {
			return literal;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof LocalDateTimeVal other && value.equals(other.value);
		}

		@Override
		public int hashCode() {
			return value.hashCode();
		}

		@Override
		public String toString() {
			return literal;
		}
	}

	/** TOML local date value with optional source literal metadata. */
	final class LocalDateVal implements TomlValue {
		private final LocalDate value;
		private final String literal;

		/**
		 * Creates a local date value, validating 4-digit year {@code 0000..9999}.
		 *
		 * @param value non-null {@link LocalDate}
		 */
		public LocalDateVal(LocalDate value) {
			this(value, CanonicalWriter.formatLocalDate(Objects.requireNonNull(value, "value")));
		}

		/**
		 * Creates a local date value preserving its source literal.
		 *
		 * @param value non-null {@link LocalDate}
		 * @param literal original source literal metadata
		 */
		public LocalDateVal(LocalDate value, String literal) {
			this.value = Objects.requireNonNull(value, "value");
			CanonicalWriter.validateYear(value.getYear());
			this.literal = Objects.requireNonNull(literal, "literal");
		}

		/**
		 * Returns the {@link LocalDate} value.
		 *
		 * @return local date
		 */
		public LocalDate value() {
			return value;
		}

		/**
		 * Returns the preserved source literal metadata.
		 *
		 * @return source literal string
		 */
		public String literal() {
			return literal;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof LocalDateVal other && value.equals(other.value);
		}

		@Override
		public int hashCode() {
			return value.hashCode();
		}

		@Override
		public String toString() {
			return literal;
		}
	}

	/** TOML local time value with optional source literal metadata. */
	final class LocalTimeVal implements TomlValue {
		private final LocalTime value;
		private final String literal;

		/**
		 * Creates a local time value with explicit-seconds canonical literal metadata.
		 *
		 * @param value non-null {@link LocalTime}
		 */
		public LocalTimeVal(LocalTime value) {
			this(value, CanonicalWriter.formatLocalTime(Objects.requireNonNull(value, "value")));
		}

		/**
		 * Creates a local time value preserving its source literal.
		 *
		 * @param value non-null {@link LocalTime}
		 * @param literal original source literal metadata
		 */
		public LocalTimeVal(LocalTime value, String literal) {
			this.value = Objects.requireNonNull(value, "value");
			this.literal = Objects.requireNonNull(literal, "literal");
		}

		/**
		 * Returns the {@link LocalTime} value.
		 *
		 * @return local time
		 */
		public LocalTime value() {
			return value;
		}

		/**
		 * Returns the preserved source literal metadata.
		 *
		 * @return source literal string
		 */
		public String literal() {
			return literal;
		}

		@Override
		public boolean equals(Object o) {
			return o instanceof LocalTimeVal other && value.equals(other.value);
		}

		@Override
		public int hashCode() {
			return value.hashCode();
		}

		@Override
		public String toString() {
			return literal;
		}
	}

	/**
	 * Creates an empty {@link Table}.
	 *
	 * @return new table
	 */
	static Table table() {
		return new Table();
	}

	/**
	 * Creates an empty {@link Array}.
	 *
	 * @return new array
	 */
	static Array array() {
		return new Array();
	}

	/**
	 * Creates an {@link Array} populated with {@code elements}.
	 *
	 * @param elements initial elements
	 * @return new array
	 */
	static Array array(TomlValue... elements) {
		Array out = new Array();
		for (TomlValue element : elements) out.add(element);
		return out;
	}

	/**
	 * Creates a {@link Str} value.
	 *
	 * @param value string content
	 * @return string value
	 */
	static Str str(String value) {
		return new Str(value);
	}

	/**
	 * Creates an {@link Int} value.
	 *
	 * @param value 64-bit integer
	 * @return integer value
	 */
	static Int integer(long value) {
		return new Int(value);
	}

	/**
	 * Creates an {@link Int} value with source literal metadata.
	 *
	 * @param value 64-bit integer
	 * @param literal source literal string
	 * @return integer value
	 */
	static Int integer(long value, String literal) {
		return new Int(value, literal);
	}

	/**
	 * Creates a {@link Float} value.
	 *
	 * @param value double value
	 * @return floating-point value
	 */
	static Float floating(double value) {
		return new Float(value);
	}

	/**
	 * Creates a {@link Float} value with source literal metadata.
	 *
	 * @param value double value
	 * @param literal source literal string
	 * @return floating-point value
	 */
	static Float floating(double value, String literal) {
		return new Float(value, literal);
	}

	/**
	 * Returns a {@link Bool} value.
	 *
	 * @param value boolean value
	 * @return {@link Bool#TRUE} or {@link Bool#FALSE}
	 */
	static Bool bool(boolean value) {
		return value ? Bool.TRUE : Bool.FALSE;
	}

	/**
	 * Creates an {@link OffsetDateTimeVal} value.
	 *
	 * @param value offset date-time
	 * @return offset date-time value
	 */
	static OffsetDateTimeVal offsetDateTime(OffsetDateTime value) {
		return new OffsetDateTimeVal(value);
	}

	/**
	 * Creates an {@link OffsetDateTimeVal} value with source literal metadata.
	 *
	 * @param value offset date-time
	 * @param literal source literal string
	 * @return offset date-time value
	 */
	static OffsetDateTimeVal offsetDateTime(OffsetDateTime value, String literal) {
		return new OffsetDateTimeVal(value, literal);
	}

	/**
	 * Creates a {@link LocalDateTimeVal} value.
	 *
	 * @param value local date-time
	 * @return local date-time value
	 */
	static LocalDateTimeVal localDateTime(LocalDateTime value) {
		return new LocalDateTimeVal(value);
	}

	/**
	 * Creates a {@link LocalDateTimeVal} value with source literal metadata.
	 *
	 * @param value local date-time
	 * @param literal source literal string
	 * @return local date-time value
	 */
	static LocalDateTimeVal localDateTime(LocalDateTime value, String literal) {
		return new LocalDateTimeVal(value, literal);
	}

	/**
	 * Creates a {@link LocalDateVal} value.
	 *
	 * @param value local date
	 * @return local date value
	 */
	static LocalDateVal localDate(LocalDate value) {
		return new LocalDateVal(value);
	}

	/**
	 * Creates a {@link LocalDateVal} value with source literal metadata.
	 *
	 * @param value local date
	 * @param literal source literal string
	 * @return local date value
	 */
	static LocalDateVal localDate(LocalDate value, String literal) {
		return new LocalDateVal(value, literal);
	}

	/**
	 * Creates a {@link LocalTimeVal} value.
	 *
	 * @param value local time
	 * @return local time value
	 */
	static LocalTimeVal localTime(LocalTime value) {
		return new LocalTimeVal(value);
	}

	/**
	 * Creates a {@link LocalTimeVal} value with source literal metadata.
	 *
	 * @param value local time
	 * @param literal source literal string
	 * @return local time value
	 */
	static LocalTimeVal localTime(LocalTime value, String literal) {
		return new LocalTimeVal(value, literal);
	}
}
