package pl.skidam.tomledit;

import java.util.Optional;

/**
 * Parsed TOML 1.1.0 document holding the lossless concrete syntax tree.
 *
 * <p>Every mutating operation is atomic (INV-5): if an invalid argument or path throws
 * {@link TomlEditException}, the document's bytes and tree remain unchanged. Not thread-safe.
 */
public final class Document implements ParseResult {
	private Cst.Doc cst;
	private byte[] textCache;

	Document(Cst.Doc cst, byte[] originalBytes) {
		this.cst = cst;
		this.textCache = originalBytes;
	}

	@Override
	public boolean isOk() {
		return true;
	}

	@Override
	public Document document() {
		return this;
	}

	@Override
	public ParseError error() {
		throw new IllegalStateException("this document parsed successfully");
	}

	/**
	 * Returns the current document bytes, exact.
	 *
	 * @return UTF-8 document bytes
	 */
	public byte[] text() {
		if (textCache == null) textCache = Cst.render(cst);
		return textCache.clone();
	}

	/**
	 * Returns the semantic TOML table derived directly from the CST. Returns a fresh copy so caller
	 * mutations cannot desync the CST.
	 *
	 * @return semantic root {@link TomlValue.Table}
	 */
	public TomlValue.Table tree() {
		return Cst.toTable(cst);
	}

	Cst.Doc cst() {
		return cst;
	}

	// ------------------------------------------------------------------ surgical edits

	/**
	 * Replaces the value at {@code path}. Preserves surrounding formatting and trailing comments.
	 *
	 * @param path existing target path (non-root)
	 * @param value replacement value
	 */
	public void set(ConfigPath path, TomlValue value) {
		requireArg(path, "path");
		requireArg(value, "value");
		atomicEdit(() -> CstEntryEditor.set(cst, path, value));
	}

	/**
	 * Inserts {@code value} into the array (or {@code [[array-of-tables]]}) at {@code path} before
	 * {@code index} ({@code index == size} appends).
	 *
	 * @param path path to an existing array or array-of-tables
	 * @param index insertion index in {@code [0, size]}
	 * @param value element to insert
	 */
	public void arrayInsert(ConfigPath path, int index, TomlValue value) {
		requireArg(path, "path");
		requireArg(value, "value");
		atomicEdit(() -> {
			CstNavigator.Target target = CstNavigator.requireTarget(cst, path);
			if (target instanceof CstNavigator.ArrayOfTablesTarget aot) {
				CstSectionEditor.arrayOfTablesInsert(cst, aot, index, value);
				return;
			}
			Cst.Arr arr = asArray(target, path);
			CstArrayEditor.arrayInsert(arr, index, value, CstEntryEditor.detectDocNewline(cst));
		});
	}

	/**
	 * Removes the element at {@code index} from the array (or {@code [[array-of-tables]]}) at {@code path}.
	 *
	 * @param path path to an existing array or array-of-tables
	 * @param index element index in {@code [0, size)}
	 */
	public void arrayRemove(ConfigPath path, int index) {
		requireArg(path, "path");
		atomicEdit(() -> {
			CstNavigator.Target target = CstNavigator.requireTarget(cst, path);
			if (target instanceof CstNavigator.ArrayOfTablesTarget aot) {
				CstSectionEditor.arrayOfTablesRemove(cst, aot, index);
				return;
			}
			Cst.Arr arr = asArray(target, path);
			CstArrayEditor.arrayRemove(arr, index);
		});
	}

	/**
	 * Reads the contiguous attached comment lines above an entry, section header, array-of-tables,
	 * inline entry, or array element.
	 *
	 * @param path existing target path
	 * @return optional comment text (stripped of leading {@code #} markers)
	 */
	public Optional<String> attachedComment(ConfigPath path) {
		requireArg(path, "path");
		return CstEntryEditor.attachedComment(cst, path);
	}

	/**
	 * Sets or removes ({@code comment == null}) the attached comment block above an entry, table
	 * header, or array-of-tables.
	 *
	 * @param path existing target path
	 * @param comment new comment text, or {@code null} to remove
	 */
	public void setComment(ConfigPath path, String comment) {
		requireArg(path, "path");
		atomicEdit(() -> CstEntryEditor.setComment(cst, path, comment));
	}

	/**
	 * Inserts a new member into {@code parentPath} with an optional attached comment.
	 * When {@code parentPath} targets a single-line inline table, {@code comment} is omitted to
	 * preserve TOML 1.0.0 compatibility.
	 *
	 * @param parentPath path to an existing table (or {@link ConfigPath#root()})
	 * @param key member key name
	 * @param value member value
	 * @param comment optional attached comment text, or {@code null}
	 */
	public void insertMember(ConfigPath parentPath, String key, TomlValue value, String comment) {
		requireArg(parentPath, "parentPath");
		requireArg(key, "key");
		requireArg(value, "value");
		atomicEdit(() -> CstEntryEditor.insertMember(cst, parentPath, key, value, comment, null));
	}

	/**
	 * Removes an existing table member or section at {@code path}.
	 *
	 * @param path existing member or section path
	 */
	public void removeMember(ConfigPath path) {
		requireArg(path, "path");
		atomicEdit(() -> CstEntryEditor.removeMember(cst, path));
	}

	// ------------------------------------------------------------------ reconcile & migration verbs

	/**
	 * Aligns existing document members with {@code model}. Unknown keys stay untouched; absent keys
	 * are not added.
	 *
	 * @param model target semantic table
	 * @param policy array reconciliation strategy
	 */
	public void reconcile(TomlValue.Table model, ReconcilePolicy policy) {
		requireArg(model, "model");
		requireArg(policy, "policy");
		atomicEdit(() -> DocumentEditor.reconcile(cst, model, policy));
	}

	/**
	 * Materializes {@code path} with {@code defaultValue} and optional {@code comment} if absent;
	 * no-op if present.
	 *
	 * @param path target member path
	 * @param defaultValue value to insert when absent
	 * @param comment optional attached comment text, or {@code null}
	 */
	public void ensure(ConfigPath path, TomlValue defaultValue, String comment) {
		requireArg(path, "path");
		requireArg(defaultValue, "defaultValue");
		atomicEdit(() -> DocumentEditor.ensure(cst, path, defaultValue, comment));
	}

	/**
	 * Moves or renames a member or table subtree from {@code from} to {@code to}, preserving its
	 * CST layout, comments, and trailing notes.
	 *
	 * @param from source member path (no-op if absent)
	 * @param to destination member path (if already present, drops {@code from} and keeps {@code to})
	 */
	public void rename(ConfigPath from, ConfigPath to) {
		requireArg(from, "from");
		requireArg(to, "to");
		atomicEdit(() -> DocumentEditor.rename(cst, from, to));
	}

	/**
	 * Idempotent removal of a member or section at {@code path}; no-op if absent.
	 *
	 * @param path target member path
	 */
	public void remove(ConfigPath path) {
		requireArg(path, "path");
		atomicEdit(() -> DocumentEditor.remove(cst, path));
	}

	// ------------------------------------------------------------------ atomicity & helpers

	void atomicEdit(Runnable action) {
		byte[] snapshot = textCache != null ? textCache : Cst.render(cst);
		try {
			action.run();
			Cst.validateDepth(cst, TomlParser.MAX_DEPTH);
			textCache = null;
		} catch (RuntimeException e) {
			this.cst = TomlParser.parse(snapshot);
			this.textCache = snapshot;
			throw e;
		}
	}

	private static Cst.Arr asArray(CstNavigator.Target target, ConfigPath path) {
		Cst.Arr arr = target.asArray();
		if (arr != null) return arr;
		throw new TomlEditException("path is not an array: " + path, path);
	}

	private static void requireArg(Object arg, String name) {
		if (arg == null) throw new TomlEditException(name + " must not be null");
	}
}
