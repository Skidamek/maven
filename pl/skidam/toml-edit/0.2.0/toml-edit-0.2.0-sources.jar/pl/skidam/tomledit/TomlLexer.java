package pl.skidam.tomledit;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * Low-level UTF-8 byte scanner for TOML 1.1.0 with forward line/column tracking.
 *
 * <p>Every input buffer is validated as UTF-8 before scanning starts. Line and column numbers are
 * tracked forward in code points so error positions are always exact without backward scans.
 */
final class TomlLexer {
	final byte[] b;
	int pos;
	int line = 1;
	int col = 1;

	TomlLexer(byte[] bytes) {
		this.b = bytes;
	}

	static int[] computeLineCol(byte[] bytes, int targetOffset) {
		int l = 1;
		int c = 1;
		int i = 0;
		while (i < targetOffset && i < bytes.length) {
			byte ch = bytes[i];
			if (ch == '\n') {
				l++;
				c = 1;
				i++;
			} else if (ch == '\r') {
				if (i + 1 < bytes.length && bytes[i + 1] == '\n') {
					if (i + 1 < targetOffset) {
						l++;
						c = 1;
						i += 2;
					} else {
						c++;
						i++;
					}
				} else {
					l++;
					c = 1;
					i++;
				}
			} else {
				int len = Math.max(Utf8.sequenceLength(ch), 1);
				i += len;
				c++;
			}
		}
		return new int[] {l, c};
	}

	boolean eof() {
		return pos >= b.length;
	}

	int peek() {
		return pos < b.length ? (b[pos] & 0xFF) : -1;
	}

	int peek(int offset) {
		int idx = pos + offset;
		return idx < b.length ? (b[idx] & 0xFF) : -1;
	}

	void advanceAscii() {
		byte c = b[pos++];
		if (c == '\n') {
			line++;
			col = 1;
		} else {
			col++;
		}
	}

	/** Advances one validated UTF-8 code point and returns it. */
	int nextCodePoint() {
		byte lead = b[pos];
		if (lead >= 0) {
			pos++;
			if (lead == '\n') {
				line++;
				col = 1;
			} else {
				col++;
			}
			return lead;
		}
		int cp = Utf8.decode(b, pos);
		pos += Utf8.sequenceLength(lead);
		col++;
		return cp;
	}

	byte[] slice(int start, int end) {
		return Arrays.copyOfRange(b, start, end);
	}

	ParseFailure fail(ErrorKind kind, String message) {
		return new ParseFailure(kind, message, line, col, pos);
	}

	ParseFailure failAt(ErrorKind kind, String message, int l, int c, int offset) {
		return new ParseFailure(kind, message, l, c, offset);
	}

	/** Consumes horizontal whitespace (' ' and '\t'), or returns null if none. */
	Cst.Tok readWs() {
		int start = pos;
		while (pos < b.length && (b[pos] == ' ' || b[pos] == '\t')) {
			pos++;
			col++;
		}
		return pos > start ? new Cst.Tok(Cst.TokKind.WS, slice(start, pos)) : null;
	}

	/** Consumes a single newline (\n or \r\n). Rejects bare \r. Returns null if not at newline. */
	Cst.Tok readNewline() {
		if (pos >= b.length) return null;
		int start = pos;
		if (b[pos] == '\n') {
			pos++;
			line++;
			col = 1;
			return new Cst.Tok(Cst.TokKind.NL, slice(start, pos));
		}
		if (b[pos] == '\r') {
			if (pos + 1 < b.length && b[pos + 1] == '\n') {
				pos += 2;
				line++;
				col = 1;
				return new Cst.Tok(Cst.TokKind.NL, slice(start, pos));
			}
			throw fail(ErrorKind.CONTROL_CHARACTER, "bare carriage return is not allowed in TOML");
		}
		return null;
	}

	/** Consumes a # comment up to (excluding) the line terminator. Rejects illegal control chars. */
	Cst.Tok readComment() {
		if (pos >= b.length || b[pos] != '#') return null;
		int start = pos;
		pos++;
		col++;
		while (pos < b.length) {
			byte lead = b[pos];
			if (lead == '\n') break;
			if (lead == '\r') {
				if (pos + 1 < b.length && b[pos + 1] == '\n') break;
				throw fail(ErrorKind.CONTROL_CHARACTER, "bare carriage return inside comment");
			}
			int cp = lead >= 0 ? lead : Utf8.decode(b, pos);
			if (isIllegalControlChar(cp)) {
				throw fail(ErrorKind.CONTROL_CHARACTER, "control character U+" + String.format("%04X", cp) + " is not allowed in a comment");
			}
			nextCodePoint();
		}
		return new Cst.Tok(Cst.TokKind.COMMENT, slice(start, pos));
	}

	static boolean isIllegalControlChar(int cp) {
		return (cp <= 0x08) || (cp >= 0x0A && cp <= 0x1F) || cp == 0x7F;
	}

	static boolean isBareKeyByte(int c) {
		return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-';
	}

	/** Reads a bare key token. */
	Cst.Tok readBareKey() {
		int start = pos;
		while (pos < b.length && isBareKeyByte(b[pos] & 0xFF)) {
			pos++;
			col++;
		}
		if (pos == start) throw fail(ErrorKind.UNEXPECTED_TOKEN, "expected a key");
		return new Cst.Tok(Cst.TokKind.BARE_KEY, slice(start, pos));
	}

	record StringTok(Cst.Tok token, String decoded) {}

	/** Reads a single-line basic string "...". */
	StringTok readBasicString() {
		int startPos = pos, startLine = line, startCol = col;
		advanceAscii(); // opening "
		StringBuilder sb = new StringBuilder();
		while (true) {
			if (eof()) throw failAt(ErrorKind.UNTERMINATED_STRING, "unterminated basic string", startLine, startCol, startPos);
			int c = peek();
			if (c == '"') {
				advanceAscii();
				return new StringTok(new Cst.Tok(Cst.TokKind.BASIC_STR, slice(startPos, pos)), sb.toString());
			}
			if (c == '\n' || c == '\r') {
				throw failAt(ErrorKind.UNTERMINATED_STRING, "newline inside single-line basic string", line, col, pos);
			}
			if (c == '\\') {
				readEscape(sb, false);
				continue;
			}
			int charLine = line, charCol = col, charPos = pos;
			int cp = nextCodePoint();
			if (isIllegalControlChar(cp)) {
				throw failAt(ErrorKind.CONTROL_CHARACTER, "unescaped control character in string", charLine, charCol, charPos);
			}
			sb.appendCodePoint(cp);
		}
	}

	/** Reads a multiline basic string """...""". */
	StringTok readMultilineBasicString() {
		return readMultilineString('"', true, Cst.TokKind.ML_BASIC_STR, "multiline basic string");
	}

	/** Reads a multiline literal string '''...'''. */
	StringTok readMultilineLiteralString() {
		return readMultilineString('\'', false, Cst.TokKind.ML_LITERAL_STR, "multiline literal string");
	}

	private StringTok readMultilineString(char quoteChar, boolean allowEscapes, Cst.TokKind kind, String label) {
		int startPos = pos, startLine = line, startCol = col;
		advanceAscii();
		advanceAscii();
		advanceAscii();
		if (peek() == '\n') {
			advanceAscii();
		} else if (peek() == '\r' && peek(1) == '\n') {
			pos += 2;
			line++;
			col = 1;
		}
		StringBuilder sb = new StringBuilder();
		while (true) {
			if (eof()) throw failAt(ErrorKind.UNTERMINATED_STRING, "unterminated " + label, startLine, startCol, startPos);
			int c = peek();
			if (c == quoteChar) {
				int quotes = 0;
				while (peek(quotes) == quoteChar) quotes++;
				if (quotes >= 3) {
					if (quotes > 5) {
						throw fail(ErrorKind.UNEXPECTED_TOKEN, "too many consecutive quotes at end of " + label);
					}
					for (int i = 0; i < quotes - 3; i++) sb.append(quoteChar);
					for (int i = 0; i < quotes; i++) advanceAscii();
					return new StringTok(new Cst.Tok(kind, slice(startPos, pos)), sb.toString());
				}
				for (int i = 0; i < quotes; i++) {
					sb.append(quoteChar);
					advanceAscii();
				}
				continue;
			}
			if (allowEscapes && c == '\\') {
				readEscape(sb, true);
				continue;
			}
			if (c == '\r') {
				if (peek(1) == '\n') {
					pos += 2;
					line++;
					col = 1;
					sb.append('\n');
					continue;
				}
				throw fail(ErrorKind.CONTROL_CHARACTER, "bare carriage return in " + label);
			}
			if (c == '\n') {
				advanceAscii();
				sb.append('\n');
				continue;
			}
			int charLine = line, charCol = col, charPos = pos;
			int cp = nextCodePoint();
			if (isIllegalControlChar(cp)) {
				throw failAt(ErrorKind.CONTROL_CHARACTER, "control character in " + label, charLine, charCol, charPos);
			}
			sb.appendCodePoint(cp);
		}
	}

	private void readEscape(StringBuilder sb, boolean multiline) {
		int escPos = pos, escLine = line, escCol = col;
		advanceAscii(); // consume '\'
		if (eof()) throw failAt(ErrorKind.BAD_ESCAPE, "incomplete escape sequence", escLine, escCol, escPos);
		int c = peek();
		if (multiline && (c == ' ' || c == '\t' || c == '\n' || c == '\r')) {
			// Line-ending backslash: optional WS before newline, then at least one newline, then any WS/newlines
			while (peek() == ' ' || peek() == '\t') advanceAscii();
			if (readNewline() == null) {
				throw failAt(ErrorKind.BAD_ESCAPE, "line-ending backslash must be followed by a newline", escLine, escCol, escPos);
			}
			while (!eof()) {
				if (peek() == ' ' || peek() == '\t') {
					advanceAscii();
				} else if (peek() == '\n' || peek() == '\r') {
					readNewline();
				} else {
					break;
				}
			}
			return;
		}
		advanceAscii();
		switch (c) {
			case 'b' -> sb.append('\b');
			case 't' -> sb.append('\t');
			case 'n' -> sb.append('\n');
			case 'f' -> sb.append('\f');
			case 'r' -> sb.append('\r');
			case 'e' -> sb.append((char) 0x1B); // TOML 1.1.0
			case '"' -> sb.append('"');
			case '\\' -> sb.append('\\');
			case 'x' -> sb.appendCodePoint(readHexScalar(2, escLine, escCol, escPos)); // TOML 1.1.0
			case 'u' -> sb.appendCodePoint(readHexScalar(4, escLine, escCol, escPos));
			case 'U' -> sb.appendCodePoint(readHexScalar(8, escLine, escCol, escPos));
			default -> throw failAt(ErrorKind.BAD_ESCAPE, "unknown escape sequence '\\" + (char) c + "'", escLine, escCol, escPos);
		}
	}

	private int readHexScalar(int digits, int escLine, int escCol, int escPos) {
		if (pos + digits > b.length) {
			throw failAt(ErrorKind.BAD_ESCAPE, "incomplete hex escape", escLine, escCol, escPos);
		}
		int value = 0;
		for (int i = 0; i < digits; i++) {
			byte h = b[pos];
			if (!Utf8.isHex(h)) {
				throw failAt(ErrorKind.BAD_ESCAPE, "invalid hex digit in escape", line, col, pos);
			}
			value = (value << 4) | Utf8.hexValue(h);
			advanceAscii();
		}
		if (value < 0 || value > 0x10FFFF || (value >= 0xD800 && value <= 0xDFFF)) {
			throw failAt(ErrorKind.BAD_ESCAPE, "invalid Unicode scalar value U+" + Integer.toHexString(value), escLine, escCol, escPos);
		}
		return value;
	}

	/** Reads a single-line literal string '...'. */
	StringTok readLiteralString() {
		int startPos = pos, startLine = line, startCol = col;
		advanceAscii(); // opening '
		int contentStart = pos;
		while (true) {
			if (eof()) throw failAt(ErrorKind.UNTERMINATED_STRING, "unterminated literal string", startLine, startCol, startPos);
			int c = peek();
			if (c == '\'') {
				String decoded = new String(b, contentStart, pos - contentStart, StandardCharsets.UTF_8);
				advanceAscii();
				return new StringTok(new Cst.Tok(Cst.TokKind.LITERAL_STR, slice(startPos, pos)), decoded);
			}
			if (c == '\n' || c == '\r') {
				throw failAt(ErrorKind.UNTERMINATED_STRING, "newline inside single-line literal string", line, col, pos);
			}
			int charLine = line, charCol = col, charPos = pos;
			int cp = nextCodePoint();
			if (isIllegalControlChar(cp)) {
				throw failAt(ErrorKind.CONTROL_CHARACTER, "control character in literal string", charLine, charCol, charPos);
			}
		}
	}

	/** Reads a scalar value (boolean, datetime/date/time, float, or integer). */
	Cst.Scalar readBareValue() {
		int startPos = pos, startLine = line, startCol = col;
		while (!eof()) {
			int c = peek();
			if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '#' || c == ',' || c == ']' || c == '}') {
				break;
			}
			nextCodePoint();
		}
		// Special case: RFC 3339 datetime with a single space separator: YYYY-MM-DD HH:MM...
		int firstEnd = pos;
		if (firstEnd - startPos == 10 && TomlScalarParser.looksLikeDate(b, startPos) && peek() == ' ' && peek(1) >= '0' && peek(1) <= '9') {
			advanceAscii(); // space
			while (!eof()) {
				int c = peek();
				if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '#' || c == ',' || c == ']' || c == '}') {
					break;
				}
				nextCodePoint();
			}
		}
		if (pos == startPos) {
			throw failAt(ErrorKind.UNEXPECTED_TOKEN, "expected a value", startLine, startCol, startPos);
		}
		byte[] raw = slice(startPos, pos);
		String text = new String(raw, StandardCharsets.UTF_8);
		return TomlScalarParser.parse(text, raw, startLine, startCol, startPos);
	}
}
