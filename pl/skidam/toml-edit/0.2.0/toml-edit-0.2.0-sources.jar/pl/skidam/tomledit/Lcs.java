package pl.skidam.tomledit;

import java.util.ArrayList;
import java.util.List;

/**
 * Longest common subsequence over semantic equality for array reconciliation.
 *
 * <p>Returns {@code null} when the DP matrix would exceed {@link #MAX_CELLS} so callers can take an
 * explicit, idempotent fallback instead of confusing budget overflow with zero matches.
 */
final class Lcs {
	static final long MAX_CELLS = 1_000_000L;

	private Lcs() {}

	/** Returns matched index pairs {@code (docIdx, modelIdx)} in increasing order, or {@code null} if over budget. */
	static List<int[]> matches(List<TomlValue> doc, List<TomlValue> model) {
		int n = doc.size();
		int m = model.size();
		if ((long) (n + 1) * (m + 1) > MAX_CELLS) {
			return null;
		}
		int[][] dp = new int[n + 1][m + 1];
		for (int i = n - 1; i >= 0; i--) {
			for (int j = m - 1; j >= 0; j--) {
				if (doc.get(i).equals(model.get(j))) {
					dp[i][j] = dp[i + 1][j + 1] + 1;
				} else {
					dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
				}
			}
		}
		List<int[]> out = new ArrayList<>();
		int i = 0;
		int j = 0;
		while (i < n && j < m) {
			if (doc.get(i).equals(model.get(j))) {
				out.add(new int[] {i, j});
				i++;
				j++;
			} else if (dp[i + 1][j] >= dp[i][j + 1]) {
				i++;
			} else {
				j++;
			}
		}
		return out;
	}
}
