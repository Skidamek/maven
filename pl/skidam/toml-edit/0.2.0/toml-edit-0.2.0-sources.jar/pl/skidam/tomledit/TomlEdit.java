package pl.skidam.tomledit;

/** Public entry point for parsing and canonical TOML writing. */
public final class TomlEdit {
	private TomlEdit() {}

	/**
	 * Parses a UTF-8 TOML 1.1.0 document. Fail-fast; returns either a {@link Document} or a {@link ParseError}.
	 *
	 * @param bytes raw UTF-8 TOML bytes
	 * @return a {@link Document} on success or a positioned {@link ParseError} on syntax/UTF-8 failure
	 */
	public static ParseResult parse(byte[] bytes) {
		if (bytes == null) throw new IllegalArgumentException("bytes must not be null");
		try {
			byte[] copy = bytes.clone();
			Cst.Doc doc = TomlParser.parse(copy);
			return new Document(doc, copy);
		} catch (ParseFailure failure) {
			return failure.toParseError();
		}
	}

	/**
	 * Canonical TOML serialization (1.0.0-compatible subset, UTF-8, no BOM, LF).
	 *
	 * @param root root table to serialize
	 * @return UTF-8 canonical TOML bytes
	 */
	public static byte[] canonical(TomlValue.Table root) {
		return CanonicalWriter.write(root, Comments.NONE);
	}

	/**
	 * Canonical TOML serialization with banner and per-path comments at any depth.
	 *
	 * @param root root table to serialize
	 * @param comments banner and per-path comment declarations
	 * @return UTF-8 canonical TOML bytes
	 */
	public static byte[] canonical(TomlValue.Table root, Comments comments) {
		return CanonicalWriter.write(root, comments);
	}
}
